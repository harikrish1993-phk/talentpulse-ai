// src/app/dashboard/[role]/page.tsx - DASHBOARD WITH ACTIVITY TRACKING
'use client';
import { useState, useEffect } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { 
  Activity, Users, Briefcase, Send, Calendar, Clock, TrendingUp, 
  BarChart3, DollarSign, AlertCircle, CheckCircle, FileText, 
  Target, Building2, UserPlus, Award, RefreshCw
} from 'lucide-react';
import Header from '@/components/layout/Header';
import PageContainer from '@/components/layout/PageContainer';
import { Card, Badge, Alert, Button, Select } from '@/components/ui';

// Activity feed item component
const ActivityItem = ({ activity }: any) => {
  const getIcon = (type: string) => {
    switch (type) {
      case 'candidate_added':
        return <UserPlus className="w-5 h-5 text-blue-600" />;
      case 'job_created':
        return <Briefcase className="w-5 h-5 text-purple-600" />;
      case 'match_found':
        return <Target className="w-5 h-5 text-green-600" />;
      case 'submission_created':
        return <Send className="w-5 h-5 text-orange-600" />;
      case 'placement':
        return <Award className="w-5 h-5 text-yellow-600" />;
      default:
        return <Activity className="w-5 h-5 text-gray-600" />;
    }
  };

  const getTimeAgo = (timestamp: string) => {
    const now = new Date();
    const then = new Date(timestamp);
    const diffMinutes = Math.floor((now.getTime() - then.getTime()) / 60000);
    
    if (diffMinutes < 1) return 'just now';
    if (diffMinutes < 60) return `${diffMinutes} min ago`;
    if (diffMinutes < 1440) return `${Math.floor(diffMinutes / 60)} hr ago`;
    return then.toLocaleDateString();
  };

  return (
    <div className="flex items-start gap-3 p-3 hover:bg-gray-50 rounded-lg">
      <div className="mt-1">
        {getIcon(activity.type)}
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-medium text-gray-900">
          {activity.title}
          {activity.metadata?.score && (
            <Badge variant="success" size="sm" className="ml-2">
              {activity.metadata.score}% match
            </Badge>
          )}
        </p>
        <p className="text-sm text-gray-600 line-clamp-2">{activity.description}</p>
        <div className="flex items-center gap-2 mt-1 text-xs text-gray-500">
          <span>{activity.user || 'System'}</span>
          <span>•</span>
          <span>{getTimeAgo(activity.timestamp)}</span>
        </div>
      </div>
    </div>
  );
};

export default function DashboardPage() {
  const router = useRouter();
  const pathname = usePathname();
  const role = pathname.split('/')[2] || 'recruiter';
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [timeRange, setTimeRange] = useState('today');
  
  const [stats, setStats] = useState({
    activeJobs: 0,
    candidates: 0,
    submissions: 0,
    placements: 0,
    revenue: 0,
    avgTimeToFill: 0,
    conversionRate: 0
  });
  
  const [activities, setActivities] = useState<any[]>([]);
  const [chartData, setChartData] = useState({
    labels: [],
    datasets: [{ data: [] }]
  });
  
  useEffect(() => {
    loadData();
  }, [timeRange]);
  
  async function loadData() {
    try {
      setLoading(true);
      setError(null);
      
      // Load stats
      const statsRes = await fetch(`/api/dashboard?role=${role}&timeRange=${timeRange}`);
      if (!statsRes.ok) throw new Error('Failed to load dashboard stats');
      const statsData = await statsRes.json();
      setStats(statsData.data);
      
      // Load activities
      const activitiesRes = await fetch(`/api/activities?limit=15&role=${role}`);
      if (!activitiesRes.ok) throw new Error('Failed to load activities');
      const activitiesData = await activitiesRes.json();
      setActivities(activitiesData.data);
      
      // Load chart data
      const chartRes = await fetch(`/api/dashboard/charts?role=${role}&timeRange=${timeRange}`);
      if (!chartRes.ok) throw new Error('Failed to load chart data');
      const chartData = await chartRes.json();
      setChartData(chartData.data);
      
    } catch (err: any) {
      setError(err.message || 'Failed to load dashboard data');
      console.error('Dashboard error:', err);
    } finally {
      setLoading(false);
    }
  }
  
  const tabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'activity', label: 'Activity Feed' },
    { id: 'performance', label: 'Performance' },
    { id: 'pipeline', label: 'Pipeline' }
  ];
  
  const timeRanges = [
    { value: 'today', label: 'Today' },
    { value: 'week', label: 'This Week' },
    { value: 'month', label: 'This Month' },
    { value: 'quarter', label: 'This Quarter' }
  ];
  
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }
  
  return (
    <>
      <Header
        title={`${role.charAt(0).toUpperCase() + role.slice(1)} Dashboard`}
        subtitle="Track your recruitment performance and activities"
        actions={
          <div className="flex gap-3">
            <Select
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value)}
              options={timeRanges}
              className="w-40"
            />
            <Button variant="outline" onClick={loadData}>
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </Button>
          </div>
        }
      />
      
      <PageContainer maxWidth="xl">
        {error && (
          <Alert variant="danger" className="mb-6" onClose={() => setError(null)}>
            {error}
          </Alert>
        )}
        
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <StatCard 
            title="Active Jobs" 
            value={stats.activeJobs} 
            trend={2.5} 
            icon={Briefcase}
            color="blue"
          />
          <StatCard 
            title="Candidates" 
            value={stats.candidates} 
            trend={5.2} 
            icon={Users}
            color="green"
          />
          <StatCard 
            title="Submissions" 
            value={stats.submissions} 
            trend={-1.3} 
            icon={Send}
            color="purple"
          />
          <StatCard 
            title="This Month's Revenue" 
            value={`$${formatCurrency(stats.revenue)}`} 
            trend={8.7} 
            icon={DollarSign}
            color="orange"
          />
        </div>
        
        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-6">
            {/* Tabs Navigation */}
            <div className="flex border-b border-gray-200">
              {tabs.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-4 py-2 font-medium text-sm border-b-2 ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
            
            {/* Overview Tab */}
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* Performance Chart */}
                <Card>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold">Performance Overview</h3>
                    <Select
                      value={timeRange}
                      onChange={(e) => setTimeRange(e.target.value)}
                      options={timeRanges}
                      className="w-32"
                    />
                  </div>
                  <div className="h-80">
                    <PerformanceChart data={chartData} />
                  </div>
                </Card>
                
                {/* Quick Actions */}
                <Card>
                  <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <QuickAction 
                      label="New Job" 
                      icon={Briefcase} 
                      color="blue" 
                      onClick={() => router.push('/jobs/new')}
                    />
                    <QuickAction 
                      label="Add Candidate" 
                      icon={UserPlus} 
                      color="green" 
                      onClick={() => router.push('/library/upload')}
                    />
                    <QuickAction 
                      label="Match Candidates" 
                      icon={Target} 
                      color="purple" 
                      onClick={() => router.push('/match')}
                    />
                    <QuickAction 
                      label="New Client" 
                      icon={Building2} 
                      color="orange" 
                      onClick={() => router.push('/clients/new')}
                    />
                  </div>
                </Card>
              </div>
            )}
            
            {/* Activity Feed Tab */}
            {activeTab === 'activity' && (
              <Card>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">Recent Activity</h3>
                  <Button variant="outline" size="sm">
                    View All
                  </Button>
                </div>
                <div className="divide-y divide-gray-200 max-h-[600px] overflow-y-auto">
                  {activities.map(activity => (
                    <ActivityItem key={activity.id} activity={activity} />
                  ))}
                </div>
                {activities.length === 0 && (
                  <div className="text-center py-12">
                    <Activity className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                    <p className="text-gray-600">No recent activity</p>
                  </div>
                )}
              </Card>
            )}
            
            {/* Performance Tab */}
            {activeTab === 'performance' && (
              <div className="space-y-6">
                <Card>
                  <h3 className="text-lg font-semibold mb-4">Key Metrics</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <MetricCard 
                      title="Avg Time to Fill" 
                      value={`${stats.avgTimeToFill} days`} 
                      description="Industry average: 36 days"
                      trend={-5.2}
                    />
                    <MetricCard 
                      title="Conversion Rate" 
                      value={`${stats.conversionRate}%`} 
                      description="Submission to placement success rate"
                      trend={2.1}
                    />
                  </div>
                </Card>
                
                <Card>
                  <h3 className="text-lg font-semibold mb-4">Team Performance</h3>
                  <TeamPerformance />
                </Card>
              </div>
            )}
            
            {/* Pipeline Tab */}
            {activeTab === 'pipeline' && (
              <Card>
                <h3 className="text-lg font-semibold mb-4">Pipeline Overview</h3>
                <PipelineVisualization />
              </Card>
            )}
          </div>
          
          {/* Right Column */}
          <div className="space-y-6">
            {/* Upcoming Interviews */}
            <Card>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-purple-600" />
                  Upcoming Interviews
                </h3>
                <Button variant="outline" size="sm">
                  View All
                </Button>
              </div>
              <UpcomingInterviews />
            </Card>
            
            {/* Job Alerts */}
            <Card>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-orange-600" />
                  Job Alerts
                </h3>
                <Button variant="outline" size="sm">
                  Manage
                </Button>
              </div>
              <JobAlerts />
            </Card>
            
            {/* Time Tracking */}
            {role !== 'owner' && (
              <Card>
                <h3 className="text-lg font-semibold flex items-center gap-2 mb-4">
                  <Clock className="w-5 h-5 text-blue-600" />
                  Time Tracking
                </h3>
                <TimeTracking />
              </Card>
            )}
            
            {/* AI Insights */}
            <Card>
              <h3 className="text-lg font-semibold flex items-center gap-2 mb-4">
                <BarChart3 className="w-5 h-5 text-indigo-600" />
                AI Insights
              </h3>
              <AIInsights />
            </Card>
          </div>
        </div>
      </PageContainer>
    </>
  );
}

// Helper Components
function StatCard({ title, value, trend, icon: Icon, color }: any) {
  return (
    <Card className="p-5">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-gray-600">{title}</p>
          <p className="text-2xl font-bold text-gray-900 mt-1">{value}</p>
        </div>
        <div className={`p-3 rounded-lg bg-${color}-50`}>
          <Icon className={`w-6 h-6 text-${color}-600`} />
        </div>
      </div>
      {trend !== undefined && (
        <div className="flex items-center mt-2 text-sm">
          <span className={`flex items-center ${
            trend > 0 ? 'text-green-600' : 'text-red-600'
          }`}>
            {trend > 0 ? (
              <TrendingUp className="w-4 h-4 mr-1" />
            ) : (
              <TrendingUp className="w-4 h-4 mr-1 rotate-180" />
            )}
            {Math.abs(trend)}%
          </span>
          <span className="text-gray-600 ml-2">{trend > 0 ? 'increase' : 'decrease'} this week</span>
        </div>
      )}
    </Card>
  );
}

function QuickAction({ label, icon: Icon, color, onClick }: any) {
  return (
    <button 
      onClick={onClick}
      className={`p-4 rounded-lg border-2 border-dashed border-${color}-300 hover:border-${color}-500 hover:bg-${color}-50 transition-colors`}
    >
      <div className={`w-8 h-8 rounded-full bg-${color}-100 flex items-center justify-center mb-2 mx-auto`}>
        <Icon className={`w-5 h-5 text-${color}-600`} />
      </div>
      <p className="text-sm font-medium text-gray-700">{label}</p>
    </button>
  );
}

function MetricCard({ title, value, description, trend }: any) {
  return (
    <div className="p-4 bg-gray-50 rounded-lg">
      <div className="flex justify-between items-start mb-2">
        <h4 className="font-medium text-gray-900">{title}</h4>
        {trend !== undefined && (
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
            trend > 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
          }`}>
            {trend > 0 ? '+' : ''}{trend}%
          </span>
        )}
      </div>
      <p className="text-2xl font-bold text-gray-900 mb-1">{value}</p>
      <p className="text-xs text-gray-600">{description}</p>
    </div>
  );
}

function PerformanceChart({ data }: any) {
  return (
    <div className="w-full h-full">
      <div className="h-full bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg border border-gray-200 flex items-center justify-center">
        <p className="text-gray-500">Performance chart would be displayed here with real data</p>
      </div>
    </div>
  );
}

function UpcomingInterviews() {
  return (
    <div className="space-y-3">
      {[1, 2, 3].map((_, i) => (
        <div key={i} className="p-3 border border-gray-200 rounded-lg hover:border-purple-300 transition">
          <div className="flex items-center justify-between mb-1">
            <div>
              <p className="font-medium text-gray-900">John Doe</p>
              <p className="text-sm text-gray-600">Senior Full Stack Developer</p>
            </div>
            <Badge variant="purple">Technical</Badge>
          </div>
          <div className="flex items-center text-sm text-gray-600 mt-2">
            <Calendar className="w-4 h-4 mr-2" />
            <span>Today, 2:30 PM</span>
            <span className="mx-2">•</span>
            <span className="flex items-center">
              <Clock className="w-4 h-4 mr-1" />
              60 min
            </span>
          </div>
        </div>
      ))}
      {Math.random() > 0.5 && (
        <Alert variant="info" className="mt-3">
          <p className="font-medium">No interviews scheduled for today</p>
          <p className="text-sm mt-1">Use quick match to find candidates for your active jobs</p>
        </Alert>
      )}
    </div>
  );
}

function JobAlerts() {
  return (
    <div className="space-y-3">
      {[1].map((_, i) => (
        <div key={i} className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-medium text-gray-900">High Priority Job Alert</p>
              <p className="text-sm text-gray-700 mt-1">
                The job "Senior DevOps Engineer" has been open for 14 days with only 2 submissions. 
                Consider external search or adjusting requirements.
              </p>
            </div>
          </div>
        </div>
      ))}
      {Math.random() > 0.5 && (
        <Alert variant="success" className="mt-3">
          <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
          <span>Your job pipeline looks healthy today!</span>
        </Alert>
      )}
    </div>
  );
}

function TimeTracking() {
  return (
    <div className="text-center">
      <div className="w-24 h-24 mx-auto mb-4">
        <svg viewBox="0 0 40 40" className="w-full h-full">
          <circle 
            cx="20" 
            cy="20" 
            r="15.915" 
            fill="transparent" 
            stroke="#e5e7eb" 
            strokeWidth="2"
          />
          <circle 
            cx="20" 
            cy="20" 
            r="15.915" 
            fill="transparent" 
            stroke="#3b82f6" 
            strokeWidth="2" 
            strokeDasharray="100" 
            strokeDashoffset="25"
            strokeLinecap="round"
            transform="rotate(-90 20 20)"
          />
          <text 
            x="50%" 
            y="50%" 
            textAnchor="middle" 
            dominantBaseline="middle" 
            className="text-2xl font-bold text-gray-900"
          >
            3.2h
          </text>
        </svg>
      </div>
      <p className="font-medium text-gray-900 mb-1">Today's Activity</p>
      <p className="text-sm text-gray-600 mb-4">
        {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}
      </p>
      <div className="grid grid-cols-3 gap-3 max-w-xs mx-auto">
        <StatItem label="Calls" value="12" icon={Phone} />
        <StatItem label="Matches" value="3" icon={Target} />
        <StatItem label="Submissions" value="2" icon={Send} />
      </div>
    </div>
  );
}

function StatItem({ label, value, icon: Icon }: any) {
  return (
    <div className="text-center">
      <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-1">
        <Icon className="w-4 h-4" />
      </div>
      <p className="font-semibold text-gray-900">{value}</p>
      <p className="text-xs text-gray-600">{label}</p>
    </div>
  );
}

function AIInsights() {
  return (
    <div className="space-y-3">
      <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
        <div className="flex items-start gap-3">
          <BarChart3 className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
          <div>
            <p className="font-medium text-gray-900">Top Performing Source</p>
            <p className="text-sm text-gray-700 mt-1">
              LinkedIn is your best source for Senior DevOps candidates this month (35% placement rate).
            </p>
          </div>
        </div>
      </div>
      <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
        <div className="flex items-start gap-3">
          <Target className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
          <div>
            <p className="font-medium text-gray-900">Skill Gap Alert</p>
            <p className="text-sm text-gray-700 mt-1">
              Cloud certifications (AWS/Azure) increase placement chances by 42% for infrastructure roles.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function TeamPerformance() {
  return (
    <div className="space-y-3">
      {[1, 2, 3].map((_, i) => (
        <div key={i} className="p-3 border border-gray-200 rounded-lg">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center font-bold text-blue-700">
                {['SK', 'AJ', 'TL'][i]}
              </div>
              <div>
                <p className="font-medium text-gray-900">{['Sarah Kim', 'Alex Johnson', 'Tom Lee'][i]}</p>
                <div className="flex gap-1 mt-1">
                  <span className="px-2 py-0.5 bg-green-100 text-green-700 rounded-full text-xs">Active</span>
                  <span className="px-2 py-0.5 bg-gray-100 text-gray-700 rounded-full text-xs">Senior</span>
                </div>
              </div>
            </div>
            <div className="text-right">
              <p className="font-semibold text-gray-900">{[7, 5, 8][i]} placements</p>
              <p className="text-sm text-gray-600">${[45000, 38000, 52000][i].toLocaleString()} revenue</p>
            </div>
          </div>
          <div className="mt-2">
            <div className="flex items-center gap-2 text-sm">
              <span className="text-gray-600">Avg. time to fill:</span>
              <span className="font-medium text-gray-900">{[18, 21, 16][i]} days</span>
              <span className="text-green-600 flex items-center">
                <TrendingUp className="w-4 h-4 mr-0.5" />
                {[-2, -5, -3][i]}% vs target
              </span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function PipelineVisualization() {
  return (
    <div className="space-y-4">
      {[1, 2, 3, 4].map((stage, i) => {
        const stageName = ['Screening', 'Internal Review', 'Client Submission', 'Interview'][i];
        const count = [12, 8, 5, 3][i];
        const percentage = [100, 67, 42, 25][i];
        
        return (
          <div key={stage} className="space-y-2">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <div className={`w-6 h-6 rounded-full bg-blue-${(i+1)*100} flex items-center justify-center text-white text-xs font-bold`}>
                  {i+1}
                </div>
                <span className="font-medium text-gray-900">{stageName}</span>
              </div>
              <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs font-medium">
                {count} candidates
              </span>
            </div>
            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-blue-600 rounded-full transition-all duration-500"
                style={{ width: `${percentage}%` }}
              ></div>
            </div>
          </div>
        );
      })}
      <div className="flex justify-between text-xs text-gray-600 mt-4">
        <span>100% start rate</span>
        <span>25% close rate</span>
      </div>
    </div>
  );
}

function formatCurrency(amount: number): string {
  return amount.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}