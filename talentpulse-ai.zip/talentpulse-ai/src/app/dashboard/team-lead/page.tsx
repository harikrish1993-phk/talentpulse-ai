'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { 
  Users, Briefcase, AlertCircle, Award, Clock, 
  PieChart, ClipboardCheck, TrendingUp, Send, FileText
} from 'lucide-react';
import Header from '@/components/layout/Header';
import PageContainer from '@/components/layout/PageContainer';
import { Card, Badge, Chart, Button, Alert } from '@/components/ui';

export default function TeamLeadDashboard() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [teamStats, setTeamStats] = useState({
    teamName: 'IT Recruitment Team',
    totalJobs: 24,
    teamSubmissions: 45,
    pendingReviews: 8,
    teamPlacements: 5,
    avgTimeToFill: 18,
    teamRevenue: 125000
  });
  const [teamMembers, setTeamMembers] = useState([]);
  const [pendingApprovals, setPendingApprovals] = useState([]);
  const [jobsNeedingAttention, setJobsNeedingAttention] = useState([]);
  
  useEffect(() => {
    // Fetch dashboard data
    loadDashboardData();
  }, []);

  async function loadDashboardData() {
    // In production, this would fetch from API
    // For now, we'll simulate data
    try {
      setTeamMembers([
        { id: '1', name: 'Sarah Johnson', jobs: 8, submissions: 12, placements: 3, trend: 'up' },
        { id: '2', name: 'Tom Wilson', jobs: 6, submissions: 8, placements: 2, trend: 'down' },
        { id: '3', name: 'Lisa Chen', jobs: 10, submissions: 15, placements: 4, trend: 'up' }
      ]);

      setPendingApprovals([
        {
          id: '1',
          recruiter: 'Sarah Johnson',
          candidate: 'Mike Chen',
          job: 'Java Developer',
          client: 'TechCorp',
          submitted: '2 hours ago',
          screeningComplete: true,
          rateConfirmed: true,
          availabilityOk: true
        },
        {
          id: '2',
          recruiter: 'Tom Wilson',
          candidate: 'Jane Doe',
          job: 'DevOps Engineer',
          client: 'DataFlow',
          submitted: '5 hours ago',
          screeningComplete: false,
          rateConfirmed: true,
          availabilityOk: true
        }
      ]);

      setJobsNeedingAttention([
        { id: 'JOB-045', title: 'Java Developer', daysOpen: 15, submissions: 0, assignedTo: 'Sarah Johnson' },
        { id: 'JOB-038', title: 'Product Manager', daysOpen: 3, submissions: 5, assignedTo: 'Team A' }
      ]);

      setLoading(false);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      setLoading(false);
    }
  }

  return (
    <>
      <Header
        title="Team Lead Dashboard"
        subtitle={teamStats.teamName}
      />
      <PageContainer maxWidth="xl">
        {/* Key Metrics Row */}
        <div className="grid grid-cols-1 md:grid-cols-6 gap-4 mb-6">
          <MetricCard 
            icon={Briefcase} 
            label="Team Jobs" 
            value={teamStats.totalJobs} 
            color="blue"
          />
          <MetricCard 
            icon={Send} 
            label="Submissions" 
            value={teamStats.teamSubmissions} 
            subtitle="last 30 days"
            color="green"
          />
          <MetricCard 
            icon={AlertCircle} 
            label="Pending Reviews" 
            value={teamStats.pendingReviews} 
            color="yellow"
            alert={teamStats.pendingReviews > 0}
          />
          <MetricCard 
            icon={Award} 
            label="Placements" 
            value={teamStats.teamPlacements} 
            subtitle="this month"
            color="purple"
          />
          <MetricCard 
            icon={Clock} 
            label="Avg Time to Fill" 
            value={`${teamStats.avgTimeToFill}d`} 
            color="orange"
          />
          <MetricCard 
            icon={DollarSign} 
            label="Revenue" 
            value={`$${(teamStats.teamRevenue / 1000).toFixed(0)}K`} 
            color="green"
          />
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Pending Approvals */}
          <div className="lg:col-span-2 space-y-6">
            {/* Pending Approvals */}
            <Card>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <ClipboardCheck className="w-5 h-5 text-yellow-600" />
                  Pending Submission Approvals ({teamStats.pendingReviews})
                </h2>
                <Button variant="primary" size="sm" onClick={() => router.push('/submissions?status=pending_review')}>
                  View All Submissions
                </Button>
              </div>
              <div className="divide-y divide-gray-200">
                {pendingApprovals.map(approval => (
                  <div key={approval.id} className="p-4 hover:bg-gray-50">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <div className="font-semibold">{approval.candidate} → {approval.job}</div>
                        <div className="text-sm text-gray-600">
                          Client: {approval.client} • Submitted by: {approval.recruiter}
                        </div>
                        <div className="text-xs text-gray-500 mt-1">
                          {approval.submitted}
                        </div>
                      </div>
                      <Badge variant={approval.screeningComplete ? 'success' : 'warning'}>
                        {approval.screeningComplete ? 'Screening Complete' : 'Screening Pending'}
                      </Badge>
                    </div>
                    {/* Checklist Status */}
                    <div className="grid grid-cols-3 gap-2 mb-3">
                      <CheckStatus label="Screening" complete={approval.screeningComplete} />
                      <CheckStatus label="Rate OK" complete={approval.rateConfirmed} />
                      <CheckStatus label="Available" complete={approval.availabilityOk} />
                    </div>
                    <div className="flex gap-2">
                      <Button variant="success" size="sm">
                        Approve
                      </Button>
                      <Button variant="danger" size="sm">
                        Reject
                      </Button>
                      <Button variant="outline" size="sm">
                        View Details
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            {/* Team Performance */}
            <Card>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <Users className="w-5 h-5 text-blue-600" />
                  Team Performance
                </h2>
                <Button variant="outline" size="sm" onClick={() => router.push('/reports/team')}>
                  Team Report
                </Button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 text-left">
                    <tr>
                      <th className="py-3 px-4 font-semibold text-gray-600">Recruiter</th>
                      <th className="py-3 px-4 font-semibold text-gray-600">Jobs</th>
                      <th className="py-3 px-4 font-semibold text-gray-600">Submissions</th>
                      <th className="py-3 px-4 font-semibold text-gray-600">Placements</th>
                      <th className="py-3 px-4 font-semibold text-gray-600">Trend</th>
                    </tr>
                  </thead>
                  <tbody>
                    {teamMembers.map(member => (
                      <tr key={member.id} className="border-b border-gray-200 hover:bg-gray-50">
                        <td className="py-3 px-4 font-medium text-gray-900">{member.name}</td>
                        <td className="py-3 px-4 text-gray-600">{member.jobs}</td>
                        <td className="py-3 px-4 text-gray-600">{member.submissions}</td>
                        <td className="py-3 px-4 text-gray-600">{member.placements}</td>
                        <td className="py-3 px-4">
                          {member.trend === 'up' ? (
                            <span className="text-green-600 flex items-center gap-1">
                              <ArrowUp className="w-4 h-4" />
                              <span className="text-xs font-medium">Up</span>
                            </span>
                          ) : (
                            <span className="text-red-600 flex items-center gap-1">
                              <ArrowDown className="w-4 h-4" />
                              <span className="text-xs font-medium">Down</span>
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Jobs Needing Attention */}
            <Card>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-red-600" />
                  Needs Attention
                </h2>
              </div>
              <div className="space-y-3">
                {jobsNeedingAttention.map(job => (
                  <AlertJobCard key={job.id} job={job} />
                ))}
              </div>
            </Card>

            {/* Placement Progress */}
            <Card>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-green-600" />
                  Placement Progress
                </h2>
              </div>
              <Chart
                type="doughnut"
                data={{
                  labels: ['Placed', 'In Progress', 'Not Started'],
                  datasets: [
                    {
                      data: [5, 12, 7],
                      backgroundColor: ['#10b981', '#3b82f6', '#9ca3af'],
                      borderWidth: 0
                    }
                  ]
                }}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      position: 'bottom',
                      labels: {
                        padding: 20,
                        usePointStyle: true,
                        pointStyle: 'circle'
                      }
                    },
                    tooltip: {
                      callbacks: {
                        label: (context) => {
                          const total = context.dataset.data.reduce((a, b) => a + (b as number), 0);
                          const value = context.raw as number;
                          const percentage = Math.round((value / total) * 100);
                          return `${context.label as string}: ${value} (${percentage}%)`;
                        }
                      }
                    }
                  }
                }}
                height={250}
              />
            </Card>

            {/* Quick Actions */}
            <Card className="bg-gradient-to-br from-purple-600 to-blue-600 text-white">
              <h3 className="text-lg font-semibold mb-4">Team Actions</h3>
              <div className="space-y-2">
                <Button variant="white" fullWidth onClick={() => router.push('/reports/team')}>
                  📊 Generate Team Report
                </Button>
                <Button variant="white" fullWidth onClick={() => router.push('/jobs/assign')}>
                  👥 Assign Jobs to Team
                </Button>
                <Button variant="white" fullWidth onClick={() => router.push('/submissions/internal-review')}>
                  ✅ Review Submissions
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </PageContainer>
    </>
  );
}

function MetricCard({ icon: Icon, label, value, subtitle, color, alert }) {
  const colorClasses = {
    blue: 'bg-blue-50 text-blue-600 border-blue-200',
    green: 'bg-green-50 text-green-600 border-green-200',
    purple: 'bg-purple-50 text-purple-600 border-purple-200',
    orange: 'bg-orange-50 text-orange-600 border-orange-200',
    yellow: 'bg-yellow-50 text-yellow-600 border-yellow-200',
    gray: 'bg-gray-50 text-gray-600 border-gray-200'
  };

  return (
    <Card className={`${colorClasses[color]} ${alert ? 'ring-2 ring-yellow-500' : ''}`}>
      <div className="flex items-center">
        <div className="p-3 bg-white rounded-lg mr-3">
          <Icon className="w-6 h-6" />
        </div>
        <div>
          <div className="text-lg font-semibold">{value}</div>
          <div className="text-xs opacity-80">{label}</div>
          {subtitle && <div className="text-xs opacity-60">{subtitle}</div>}
        </div>
      </div>
    </Card>
  );
}

function CheckStatus({ label, complete }) {
  return (
    <div className={`p-2 rounded text-center text-xs font-medium ${
      complete ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'
    }`}>
      {complete ? '✓' : '○'} {label}
    </div>
  );
}

function AlertJobCard({ job }) {
  return (
    <div className="p-3 border border-red-200 bg-red-50 rounded-lg">
      <div className="flex items-center gap-2 mb-2">
        <AlertCircle className="w-4 h-4 text-red-600" />
        <span className="font-medium text-red-900">{job.id}</span>
      </div>
      <div className="text-sm text-gray-900 font-medium mb-1">{job.title}</div>
      <div className="text-xs text-gray-600 mb-2">
        {job.daysOpen} days open • {job.submissions} submissions
      </div>
      <div className="text-xs text-gray-500">
        Assigned: {job.assignedTo}
      </div>
    </div>
  );
}