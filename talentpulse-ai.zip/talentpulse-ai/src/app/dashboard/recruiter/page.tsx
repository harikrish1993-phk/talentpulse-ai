'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { 
  Briefcase, Users, DollarSign, TrendingUp, Clock, Target, 
  Calendar, CheckCircle, AlertCircle, Phone, Mail, Video, 
  Send, Eye, Edit2, Filter, Search, Plus, MessageSquare
} from 'lucide-react';
import Header from '@/components/layout/Header';
import PageContainer from '@/components/layout/PageContainer';
import { Card, Badge, Button, Alert } from '@/components/ui';

export default function RecruiterDashboard() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [recruiterData, setRecruiterData] = useState({
    name: "Sarah Johnson",
    metrics: {
      activeJobs: 8,
      submissionsThisWeek: 12,
      interviewsScheduled: 2,
      pendingFollowups: 5,
      screeningCallsToday: 3,
      awaitingReview: 4
    },
    activeJobs: [
      {
        id: 'JOB-045',
        title: 'Senior Java Developer',
        client: 'TechCorp Solutions',
        priority: 'high',
        submissions: 3,
        interviews: 1,
        lastAction: '2 hours ago',
        status: 'active',
        healthScore: 85,
        deadline: '2025-01-20',
        pipeline: { sourced: 8, screening: 3, submitted: 3, interview: 1, offer: 0 }
      },
      {
        id: 'JOB-038',
        title: 'Senior DevOps Engineer',
        client: 'DataFlow Inc',
        priority: 'medium',
        submissions: 0,
        interviews: 0,
        lastAction: '3 days ago',
        status: 'active',
        healthScore: 45,
        deadline: '2025-01-25',
        pipeline: { sourced: 2, screening: 0, submitted: 0, interview: 0, offer: 0 }
      }
    ],
    todayTasks: [
      { id: '1', type: 'call', candidate: 'Mike Chen', action: 'Rate confirmation', priority: 'high', time: '10:00 AM', done: false },
      { id: '2', type: 'email', candidate: 'Jane Doe', action: 'Interview feedback follow-up', priority: 'medium', time: '2:00 PM', done: false },
      { id: '3', type: 'submit', candidate: 'Tom Wilson', action: 'Submit to Acme Corp', priority: 'high', time: '4:00 PM', done: false },
      { id: '4', type: 'screen', candidate: 'Lisa Park', action: 'Initial phone screen', priority: 'medium', time: '11:00 AM', done: true }
    ],
    upcomingInterviews: [
      { id: '1', date: 'Mon 11/18', time: '2:00 PM', candidate: 'John Doe', job: 'Java Developer', client: 'TechCorp' },
      { id: '2', date: 'Tue 11/19', time: '10:00 AM', candidate: 'Jane Smith', job: 'DevOps Engineer', client: 'DataFlow' }
    ],
    pendingReviews: [
      { id: '1', candidate: 'Mike Chen', job: 'Java Developer', submitted: '2 hours ago', status: 'pending_team_review' }
    ]
  });
  
  useEffect(() => {
    // Fetch dashboard data
    loadDashboardData();
  }, []);

  async function loadDashboardData() {
    // In production, this would fetch from API
    // For now, we'll simulate data
    try {
      setLoading(false);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      setLoading(false);
    }
  }

  return (
    <>
      <Header
        title="My Dashboard"
        subtitle={`Welcome back, ${recruiterData.name}`}
      />
      <PageContainer maxWidth="xl">
        {/* Key Metrics Row */}
        <div className="grid grid-cols-1 md:grid-cols-6 gap-4 mb-6">
          <MetricCard 
            icon={Briefcase} 
            label="Active Jobs" 
            value={recruiterData.metrics.activeJobs} 
            color="blue"
          />
          <MetricCard 
            icon={Send} 
            label="Submissions" 
            value={recruiterData.metrics.submissionsThisWeek} 
            subtitle="this week"
            color="green"
          />
          <MetricCard 
            icon={Video} 
            label="Interviews" 
            value={recruiterData.metrics.interviewsScheduled} 
            subtitle="scheduled"
            color="purple"
          />
          <MetricCard 
            icon={Clock} 
            label="Follow-ups" 
            value={recruiterData.metrics.pendingFollowups} 
            color="orange"
            alert={recruiterData.metrics.pendingFollowups > 3}
          />
          <MetricCard 
            icon={Phone} 
            label="Screens Today" 
            value={recruiterData.metrics.screeningCallsToday} 
            color="teal"
          />
          <MetricCard 
            icon={AlertCircle} 
            label="Awaiting Review" 
            value={recruiterData.metrics.awaitingReview} 
            color="yellow"
            alert={recruiterData.metrics.awaitingReview > 0}
          />
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Jobs & Tasks */}
          <div className="lg:col-span-2 space-y-6">
            {/* Active Jobs */}
            <Card>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <Briefcase className="w-5 h-5 text-blue-600" />
                  My Active Jobs
                </h2>
                <Button variant="outline" size="sm" onClick={() => router.push('/jobs')}>
                  View All →
                </Button>
              </div>
              <div className="space-y-4">
                {recruiterData.activeJobs.map(job => (
                  <RecruiterJobCard key={job.id} job={job} />
                ))}
              </div>
            </Card>

            {/* Today's Tasks */}
            <Card>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  Today's Follow-Ups
                </h2>
                <span className="text-sm text-gray-500">
                  {recruiterData.todayTasks.filter(t => !t.done).length} pending
                </span>
              </div>
              <div className="space-y-3">
                {recruiterData.todayTasks.map(task => (
                  <TaskItem key={task.id} task={task} />
                ))}
              </div>
            </Card>
          </div>

          {/* Right Column - Interviews & Pending */}
          <div className="space-y-6">
            {/* Upcoming Interviews */}
            <Card>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-purple-600" />
                  Upcoming Interviews
                </h2>
              </div>
              <div className="space-y-3">
                {recruiterData.upcomingInterviews.map(interview => (
                  <InterviewCard key={interview.id} interview={interview} />
                ))}
              </div>
            </Card>

            {/* Pending Reviews */}
            <Card>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-yellow-600" />
                  Pending Reviews
                </h2>
              </div>
              <div className="space-y-3">
                {recruiterData.pendingReviews.map(review => (
                  <PendingReviewCard key={review.id} review={review} />
                ))}
              </div>
            </Card>

            {/* Quick Actions */}
            <Card className="bg-gradient-to-br from-blue-600 to-purple-600 text-white">
              <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
              <div className="space-y-2">
                <Button variant="white" fullWidth onClick={() => router.push('/match')}>
                  📋 Match Candidates to Jobs
                </Button>
                <Button variant="white" fullWidth onClick={() => router.push('/reports/weekly')}>
                  📊 My Weekly Report
                </Button>
                <Button variant="white" fullWidth onClick={() => router.push('/library')}>
                  👥 Add New Candidate
                </Button>
              </div>
            </Card>

            {/* Match Tips */}
            <Card className="bg-blue-50">
              <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                <Target className="w-5 h-5 text-blue-600" />
                Today's Match Tip
              </h3>
              <p className="text-gray-700 text-sm">
                For your Java Developer role, focus on candidates with Spring Framework experience and cloud deployment skills. Our AI has identified 12 strong matches in your library.
              </p>
              <Button variant="outline" size="sm" className="mt-3" onClick={() => router.push('/match')}>
                Find Matches Now
              </Button>
            </Card>
          </div>
        </div>
      </PageContainer>
    </>
  );
}

function MetricCard({ icon: Icon, label, value, color, subtitle, alert }) {
  const colorClasses = {
    blue: 'bg-blue-50 text-blue-600 border-blue-200',
    green: 'bg-green-50 text-green-600 border-green-200',
    purple: 'bg-purple-50 text-purple-600 border-purple-200',
    orange: 'bg-orange-50 text-orange-600 border-orange-200',
    teal: 'bg-teal-50 text-teal-600 border-teal-200',
    yellow: 'bg-yellow-50 text-yellow-600 border-yellow-200'
  };

  return (
    <Card className={`${colorClasses[color]} ${alert ? 'ring-2 ring-red-500/50' : ''}`}>
      <div className="flex items-center">
        <div className="p-3 bg-white rounded-lg mr-3">
          <Icon className="w-6 h-6" />
        </div>
        <div>
          <div className="text-lg font-semibold">{value}</div>
          <div className="text-xs opacity-80">{label}</div>
          {subtitle && <div className="text-xs opacity-60">{subtitle}</div>}
        </div>
      </div>
    </Card>
  );
}

function RecruiterJobCard({ job }) {
  return (
    <div className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50">
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <span className="font-semibold text-gray-900">{job.id}</span>
            <span className="text-gray-400">•</span>
            <h3 className="font-semibold text-gray-900">{job.title}</h3>
            {job.priority === 'high' && (
              <span className="px-2 py-0.5 bg-red-100 text-red-700 rounded-full text-xs font-medium">
                High Priority
              </span>
            )}
          </div>
          <p className="text-sm text-gray-600">{job.client}</p>
        </div>
        <div className="flex items-center gap-1">
          <TrendingUp className={`w-5 h-5 ${
            job.healthScore >= 70 ? 'text-green-600' :
            job.healthScore >= 40 ? 'text-yellow-600' : 'text-red-600'
          }`} />
          <span className="text-sm font-semibold text-gray-900">{job.healthScore}%</span>
        </div>
      </div>
      {/* Pipeline Mini */}
      <div className="mb-3">
        <div className="flex gap-1 mb-1">
          {Object.entries(job.pipeline).map(([stage, count], idx) => (
            <div
              key={stage}
              className="flex-1 h-2 rounded bg-blue-600"
              style={{ 
                opacity: count > 0 ? 1 : 0.2,
                backgroundColor: idx === 0 ? '#3b82f6' : idx === 1 ? '#8b5cf6' : idx === 2 ? '#ec4899' : '#10b981'
              }}
              title={`${stage}: ${count}`}
            />
          ))}
        </div>
        <div className="text-xs text-gray-600">
          {job.submissions} submissions • {job.interviews} interviews • Last: {job.lastAction}
        </div>
      </div>
      <div className="flex gap-2">
        <Button variant="primary" size="sm" className="flex-1" onClick={() => router.push(`/jobs/${job.id}/match`)}>
          Match Candidates
        </Button>
        <Button variant="outline" size="sm" onClick={() => router.push(`/jobs/${job.id}`)}>
          View Details
        </Button>
      </div>
    </div>
  );
}

function TaskItem({ task }) {
  const icons = {
    call: Phone,
    email: Mail,
    submit: Send,
    screen: Users
  };
  const Icon = icons[task.type as keyof typeof icons];

  return (
    <div className={`p-3 border ${task.done ? 'border-gray-200 bg-gray-50' : 'border-blue-200 bg-blue-50'} rounded-lg`}>
      <div className="flex items-center gap-3">
        <input
          type="checkbox"
          checked={task.done}
          className="w-5 h-5 text-blue-600 rounded"
        />
        <div className={`p-2 rounded-lg ${task.done ? 'bg-gray-100' : 'bg-blue-100'}`}>
          <Icon className={`w-4 h-4 ${task.done ? 'text-gray-400' : 'text-blue-600'}`} />
        </div>
        <div className="flex-1">
          <div className={`font-medium ${task.done ? 'text-gray-400 line-through' : 'text-gray-900'}`}>
            {task.action}
          </div>
          <div className="text-sm text-gray-600">{task.candidate} • {task.time}</div>
        </div>
        {task.priority === 'high' && !task.done && (
          <div className="flex items-center justify-center w-8 h-8 bg-red-50 border border-red-200 rounded-full">
            <Flag className="w-4 h-4 text-red-600" />
          </div>
        )}
      </div>
    </div>
  );
}

function InterviewCard({ interview }) {
  return (
    <div className="p-3 border border-gray-200 rounded-lg hover:border-purple-300 transition-colors">
      <div className="flex items-center gap-3 mb-2">
        <div className="p-2 bg-purple-50 rounded-lg">
          <Video className="w-4 h-4 text-purple-600" />
        </div>
        <div className="flex-1">
          <div className="font-medium text-gray-900">{interview.candidate}</div>
          <div className="text-sm text-gray-600">{interview.job}</div>
        </div>
      </div>
      <div className="text-sm text-gray-600">
        {interview.date} • {interview.time}
      </div>
      <div className="text-xs text-gray-500 mt-1">Client: {interview.client}</div>
    </div>
  );
}

function PendingReviewCard({ review }) {
  return (
    <div className="p-3 border border-yellow-200 bg-yellow-50 rounded-lg">
      <div className="font-medium text-gray-900 mb-1">{review.candidate}</div>
      <div className="text-sm text-gray-600 mb-2">{review.job}</div>
      <div className="text-xs text-gray-500 mb-2">Submitted {review.submitted}</div>
      <div className="flex gap-2">
        <Button variant="success" size="sm" className="flex-1">
          View Submission
        </Button>
      </div>
    </div>
  );
}

function Flag() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"></path>
      <line x1="4" y1="22" x2="4" y2="15"></line>
    </svg>
  );
}