'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { 
  BarChart3, DollarSign, Users, Briefcase, TrendingUp, 
  Clock, AlertCircle, Award, PieChart, Building2 
} from 'lucide-react';
import Header from '@/components/layout/Header';
import PageContainer from '@/components/layout/PageContainer';
import { Card, Badge, Chart, Button, Alert } from '@/components/ui';
import { formatCurrency } from '@/lib/utils';

export default function OwnerDashboard() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalJobs: 45,
    totalPlacements: 23,
    monthlyRevenue: 125000,
    activeRecruiters: 12,
    avgTimeToFill: 21,
    totalCandidates: 345,
    highMatchRate: 0
  });
  const [clientMetrics, setClientMetrics] = useState([]);
  const [topPerformers, setTopPerformers] = useState([]);
  const [revenueData, setRevenueData] = useState([]);
  
  useEffect(() => {
    // Fetch dashboard data
    loadDashboardData();
  }, []);

  async function loadDashboardData() {
    // In production, this would fetch from API
    // For now, we'll simulate data
    try {
      // Simulated API calls
      setClientMetrics([
        { id: '1', name: 'TechCorp Solutions', jobs: 12, placements: 5, revenue: 62000, status: 'excellent' },
        { id: '2', name: 'DataFlow Inc', jobs: 8, placements: 3, revenue: 28000, status: 'good' },
        { id: '3', name: 'StartupX', jobs: 5, placements: 2, revenue: 18000, status: 'fair' },
        { id: '4', name: 'GlobalTech', jobs: 3, placements: 1, revenue: 12000, status: 'poor' }
      ]);

      setTopPerformers([
        { id: '1', name: 'Lisa Chen', placements: 8, revenue: 45000 },
        { id: '2', name: 'Sarah Johnson', placements: 6, revenue: 32000 },
        { id: '3', name: 'Tom Wilson', placements: 5, revenue: 28000 }
      ]);

      setRevenueData([
        { month: 'Jul', revenue: 95000 },
        { month: 'Aug', revenue: 110000 },
        { month: 'Sep', revenue: 105000 },
        { month: 'Oct', revenue: 120000 },
        { month: 'Nov', revenue: 125000 }
      ]);

      setLoading(false);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      setLoading(false);
    }
  }

  return (
    <>
      <Header
        title="Executive Dashboard"
        subtitle="Company Overview & Performance Insights"
      />
      <PageContainer maxWidth="xl">
        {/* Key Metrics Row */}
        <div className="grid grid-cols-1 md:grid-cols-6 gap-4 mb-6">
          <MetricCard 
            icon={Briefcase} 
            label="Open Jobs" 
            value={stats.totalJobs} 
            subtitle="Last 30 days"
            color="blue"
          />
          <MetricCard 
            icon={Award} 
            label="Placements" 
            value={stats.totalPlacements} 
            subtitle="This month"
            color="green"
          />
          <MetricCard 
            icon={DollarSign} 
            label="Revenue" 
            value={`$${(stats.monthlyRevenue / 1000).toFixed(0)}K`} 
            subtitle="This month"
            color="purple"
          />
          <MetricCard 
            icon={Users} 
            label="Active Recruiters" 
            value={stats.activeRecruiters} 
            subtitle="Team size"
            color="indigo"
          />
          <MetricCard 
            icon={Clock} 
            label="Avg Fill Time" 
            value={`${stats.avgTimeToFill}d`} 
            subtitle="Time to fill"
            color="orange"
          />
          <MetricCard 
            icon={BarChart3} 
            label="Match Quality" 
            value={`${stats.highMatchRate}%`} 
            subtitle="A/B tier matches"
            color="teal"
          />
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Revenue Trend Chart */}
          <Card>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-green-600" />
                Revenue Trend (Last 5 Months)
              </h2>
              <button className="text-sm text-blue-600 hover:text-blue-700">
                View detailed report →
              </button>
            </div>
            <Chart
              type="line"
              data={{
                labels: revenueData.map(item => item.month),
                datasets: [
                  {
                    label: 'Revenue',
                    data: revenueData.map(item => item.revenue),
                    borderColor: '#6366f1',
                    backgroundColor: 'rgba(99, 102, 241, 0.1)',
                    tension: 0.3,
                    fill: true
                  }
                ]
              }}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: { display: false },
                  tooltip: {
                    callbacks: {
                      label: (context) => `$${(context.raw as number).toLocaleString()}`
                    }
                  }
                },
                scales: {
                  y: {
                    beginAtZero: false,
                    ticks: {
                      callback: (value) => `$${(value as number / 1000).toFixed(0)}K`
                    }
                  }
                }
              }}
              height={250}
            />
          </Card>

          {/* Placements by Client Chart */}
          <Card>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <Building2 className="w-5 h-5 text-blue-600" />
                Placements by Client
              </h2>
              <button className="text-sm text-blue-600 hover:text-blue-700">
                View all clients →
              </button>
            </div>
            <Chart
              type="bar"
              data={{
                labels: clientMetrics.map(client => client.name),
                datasets: [
                  {
                    label: 'Placements',
                    data: clientMetrics.map(client => client.placements),
                    backgroundColor: clientMetrics.map(client => 
                      client.status === 'excellent' ? '#10b981' :
                      client.status === 'good' ? '#3b82f6' :
                      client.status === 'fair' ? '#f59e0b' : '#ef4444'
                    )
                  }
                ]
              }}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: { display: false }
                },
                scales: {
                  y: { beginAtZero: true }
                }
              }}
              height={250}
            />
          </Card>
        </div>

        {/* Bottom Row - Tables */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Top Clients Performance */}
          <Card>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <Building2 className="w-5 h-5 text-blue-600" />
                Top Clients Performance
              </h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 text-left">
                  <tr>
                    <th className="py-3 px-4 font-semibold text-gray-600">Client</th>
                    <th className="py-3 px-4 font-semibold text-gray-600">Jobs</th>
                    <th className="py-3 px-4 font-semibold text-gray-600">Placements</th>
                    <th className="py-3 px-4 font-semibold text-gray-600">Revenue</th>
                    <th className="py-3 px-4 font-semibold text-gray-600">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {clientMetrics.map((client, idx) => (
                    <tr key={idx} className="border-b border-gray-200 hover:bg-gray-50">
                      <td className="py-3 px-4 font-medium">{client.name}</td>
                      <td className="py-3 px-4">{client.jobs}</td>
                      <td className="py-3 px-4">{client.placements}</td>
                      <td className="py-3 px-4 font-semibold text-gray-900">
                        ${formatCurrency(client.revenue)}
                      </td>
                      <td className="py-3 px-4">
                        <Badge 
                          variant={
                            client.status === 'excellent' ? 'success' :
                            client.status === 'good' ? 'primary' :
                            client.status === 'fair' ? 'warning' : 'danger'
                          }
                        >
                          {client.status.charAt(0).toUpperCase() + client.status.slice(1)}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>

          {/* Top Performers */}
          <Card>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <Users className="w-5 h-5 text-indigo-600" />
                Top Performers
              </h2>
              <button className="text-sm text-blue-600 hover:text-blue-700">
                View team details →
              </button>
            </div>
            <div className="space-y-3">
              {topPerformers.map((performer, idx) => (
                <div key={idx} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-white ${
                      idx === 0 ? 'bg-yellow-500' : idx === 1 ? 'bg-gray-400' : 'bg-orange-600'
                    }`}>
                      {idx + 1}
                    </div>
                    <div>
                      <div className="font-medium text-gray-900">{performer.name}</div>
                      <div className="text-xs text-gray-500">{performer.placements} placements</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-gray-900">
                      ${formatCurrency(performer.revenue)}
                    </div>
                    <div className="text-xs text-gray-500">Revenue generated</div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </PageContainer>
    </>
  );
}

function MetricCard({ icon: Icon, label, value, subtitle, color }) {
  const colorClasses = {
    blue: 'bg-blue-50 text-blue-600 border-blue-200',
    green: 'bg-green-50 text-green-600 border-green-200',
    purple: 'bg-purple-50 text-purple-600 border-purple-200',
    indigo: 'bg-indigo-50 text-indigo-600 border-indigo-200',
    orange: 'bg-orange-50 text-orange-600 border-orange-200',
    teal: 'bg-teal-50 text-teal-600 border-teal-200'
  };

  return (
    <Card className={`${colorClasses[color]}`}>
      <div className="flex items-center">
        <div className="p-3 bg-white rounded-lg mr-3">
          <Icon className="w-6 h-6" />
        </div>
        <div>
          <div className="text-lg font-semibold">{value}</div>
          <div className="text-xs opacity-80">{label}</div>
          {subtitle && <div className="text-xs opacity-60">{subtitle}</div>}
        </div>
      </div>
    </Card>
  );
}