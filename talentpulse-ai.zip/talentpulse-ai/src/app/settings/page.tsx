// src/app/settings/page.tsx - USER-FRIENDLY VERSION
'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Header from '@/components/layout/Header';
import PageContainer from '@/components/layout/PageContainer';
import { Button, Input, Select, Textarea, Card, Alert } from '@/components/ui';
import { 
  Key, CheckCircle, AlertCircle, Save, FileText, Users, Filter, 
  Bell, Calendar, TrendingUp, Shield, Clock, Download
} from 'lucide-react';

export default function UserSettingsPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const [settings, setSettings] = useState({
    // Profile
    fullName: '',
    email: '',
    department: '',
    notificationPreferences: {
      email: true,
      push: true,
      dailyDigest: true,
      matchAlerts: true
    },
    // Matching
    minMatchScore: 70,
    preferredSkills: [],
    locationPreferences: '',
    // Export
    defaultExportFormat: 'csv',
    exportFields: ['name', 'email', 'phone', 'skills', 'experience', 'score', 'location', 'availability'],
    // Workflow
    defaultJobStatus: 'draft',
    autoRefreshInterval: 30,
    dashboardMetrics: ['active_jobs', 'submissions', 'placements', 'time_to_fill']
  });

  const [apiStatus, setApiStatus] = useState({
    openai: { configured: false, valid: false },
    apollo: { configured: false, valid: false },
    supabase: { configured: false, valid: false }
  });

  useEffect(() => {
    loadSettings();
    checkAPIStatus();
  }, []);

  async function loadSettings() {
    try {
      setLoading(true);
      const res = await fetch('/api/settings');
      const { data } = await res.json();
      
      if (data) {
        // Merge with defaults
        setSettings(prev => ({
          ...prev,
          ...data,
          notificationPreferences: {
            ...prev.notificationPreferences,
            ...(data.notificationPreferences || {})
          }
        }));
      }
    } catch (err) {
      console.error('Failed to load settings:', err);
      setError('Failed to load settings. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  async function checkAPIStatus() {
    try {
      // OpenAI check
      const openaiRes = await fetch('/api/match/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ description: 'Test job description' })
      });
      setApiStatus(prev => ({
        ...prev,
        openai: { configured: true, valid: openaiRes.ok }
      }));

      // Supabase check
      const dbRes = await fetch('/api/candidates?limit=1');
      setApiStatus(prev => ({
        ...prev,
        supabase: { configured: true, valid: dbRes.ok }
      }));

      // Apollo check (if configured)
      try {
        const apolloRes = await fetch('/api/external-search');
        if (apolloRes.ok) {
          const apolloData = await apolloRes.json();
          setApiStatus(prev => ({
            ...prev,
            apollo: { configured: true, valid: apolloData.success }
          }));
        }
      } catch (apolloError) {
        // Apollo not configured - that's fine
      }
    } catch (err) {
      console.error('Failed to check API status:', err);
    }
  }

  async function handleSave() {
    try {
      setSaving(true);
      setError(null);
      
      const response = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings)
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to save settings');
      }
      
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (err: any) {
      setError(err.message || 'Failed to save settings');
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading settings...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <Header
        title="My Settings"
        subtitle="Personalize your TalentPlus experience"
      />
      <PageContainer maxWidth="xl">
        {/* Success/Error Messages */}
        {saved && (
          <Alert variant="success" className="mb-6" onClose={() => setSaved(false)}>
            Settings saved successfully!
          </Alert>
        )}
        
        {error && (
          <Alert variant="danger" className="mb-6" onClose={() => setError(null)}>
            {error}
          </Alert>
        )}

        {/* System Status Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <Key className="w-5 h-5 text-blue-600" />
                AI Services
              </h3>
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">Resume Parsing</p>
                  <p className="text-xs text-gray-600">OpenAI integration</p>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                  apiStatus.openai.valid ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                }`}>
                  {apiStatus.openai.valid ? 'Active' : 'Degraded'}
                </span>
              </div>
              <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">External Search</p>
                  <p className="text-xs text-gray-600">Apollo.io integration</p>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                  apiStatus.apollo.configured && apiStatus.apollo.valid 
                    ? 'bg-green-100 text-green-700' 
                    : apiStatus.apollo.configured 
                    ? 'bg-yellow-100 text-yellow-700' 
                    : 'bg-gray-100 text-gray-700'
                }`}>
                  {apiStatus.apollo.configured && apiStatus.apollo.valid 
                    ? 'Active' 
                    : apiStatus.apollo.configured 
                    ? 'Setup Required' 
                    : 'Not Configured'}
                </span>
              </div>
              <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">Database</p>
                  <p className="text-xs text-gray-600">Candidate storage</p>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                  apiStatus.supabase.valid ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                }`}>
                  {apiStatus.supabase.valid ? 'Connected' : 'Offline'}
                </span>
              </div>
            </div>
          </Card>

          <Card>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <Users className="w-5 h-5 text-purple-600" />
                My Profile
              </h3>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Full Name
                </label>
                <Input
                  value={settings.fullName}
                  onChange={(e) => setSettings({...settings, fullName: e.target.value})}
                  placeholder="John Doe"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email Address
                </label>
                <Input
                  type="email"
                  value={settings.email}
                  onChange={(e) => setSettings({...settings, email: e.target.value})}
                  placeholder="john.doe@company.com"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Department/Team
                </label>
                <Select
                  value={settings.department}
                  onChange={(e) => setSettings({...settings, department: e.target.value})}
                  options={[
                    { value: 'it_recruitment', label: 'IT Recruitment' },
                    { value: 'finance_recruitment', label: 'Finance Recruitment' },
                    { value: 'executive_search', label: 'Executive Search' },
                    { value: 'general', label: 'General Recruitment' }
                  ]}
                />
              </div>
            </div>
          </Card>

          <Card>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <Bell className="w-5 h-5 text-green-600" />
                Notifications
              </h3>
            </div>
            <div className="space-y-3">
              {[
                { key: 'email', label: 'Email Notifications' },
                { key: 'push', label: 'Push Notifications' },
                { key: 'dailyDigest', label: 'Daily Summary Digest' },
                { key: 'matchAlerts', label: 'New Match Alerts' }
              ].map(pref => (
                <label 
                  key={pref.key} 
                  className="flex items-center p-3 border rounded-lg hover:bg-gray-50 cursor-pointer"
                >
                  <input
                    type="checkbox"
                    checked={settings.notificationPreferences[pref.key as keyof typeof settings.notificationPreferences]}
                    onChange={(e) => setSettings({
                      ...settings,
                      notificationPreferences: {
                        ...settings.notificationPreferences,
                        [pref.key]: e.target.checked
                      }
                    })}
                    className="mr-3 w-4 h-4 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
                  />
                  <div>
                    <p className="font-medium text-gray-900">{pref.label}</p>
                    <p className="text-xs text-gray-600">
                      {pref.key === 'email' ? 'Get emails for important updates' :
                       pref.key === 'push' ? 'Browser notifications for urgent items' :
                       pref.key === 'dailyDigest' ? 'End-of-day summary of activities' :
                       'Instant alerts when new candidates match your jobs'}
                    </p>
                  </div>
                </label>
              ))}
            </div>
          </Card>
        </div>

        {/* Matching Preferences */}
        <Card className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <TrendingUp className="w-6 h-6 text-indigo-600" />
              Matching Preferences
            </h2>
            <Button variant="outline" size="sm" onClick={checkAPIStatus}>
              Refresh Status
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Minimum Match Score
                <span className="text-blue-600 font-bold ml-2">{settings.minMatchScore}%</span>
              </label>
              <input
                type="range"
                min="40"
                max="90"
                step="5"
                value={settings.minMatchScore}
                onChange={(e) => setSettings({...settings, minMatchScore: Number(e.target.value)})}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>40% (All Matches)</span>
                <span>70% (Good Matches)</span>
                <span>90% (Perfect Matches)</span>
              </div>
              <p className="text-xs text-gray-600 mt-2">
                Only show candidates scoring at least this percentage on job matches
              </p>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Preferred Skills
              </label>
              <Select
                multiple
                value={settings.preferredSkills}
                onChange={(value) => setSettings({...settings, preferredSkills: value as string[]})}
                options={[
                  { value: 'react', label: 'React' },
                  { value: 'nodejs', label: 'Node.js' },
                  { value: 'python', label: 'Python' },
                  { value: 'java', label: 'Java' },
                  { value: 'aws', label: 'AWS' },
                  { value: 'docker', label: 'Docker' },
                  { value: 'kubernetes', label: 'Kubernetes' },
                  { value: 'typescript', label: 'TypeScript' }
                ]}
                placeholder="Select your preferred skills..."
              />
              <p className="text-xs text-gray-600 mt-1">
                Candidates with these skills will be ranked higher in matches
              </p>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Location Preferences
              </label>
              <Select
                value={settings.locationPreferences}
                onChange={(e) => setSettings({...settings, locationPreferences: e.target.value})}
                options={[
                  { value: 'remote', label: 'Remote Only' },
                  { value: 'hybrid', label: 'Hybrid (Remote + Office)' },
                  { value: 'onsite', label: 'Onsite Only' },
                  { value: 'any', label: 'Any Location' }
                ]}
              />
              <p className="text-xs text-gray-600 mt-1">
                Filter matches by preferred work arrangement
              </p>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Default Job Status
              </label>
              <Select
                value={settings.defaultJobStatus}
                onChange={(e) => setSettings({...settings, defaultJobStatus: e.target.value})}
                options={[
                  { value: 'draft', label: 'Draft (review before publishing)' },
                  { value: 'open', label: 'Open (immediately active)' }
                ]}
              />
              <p className="text-xs text-gray-600 mt-1">
                Default status when creating new jobs
              </p>
            </div>
          </div>
        </Card>

        {/* Export Settings */}
        <Card className="mb-8">
          <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
            <FileText className="w-6 h-6 text-green-600" />
            Export Settings
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Default Export Format
              </label>
              <Select
                value={settings.defaultExportFormat}
                onChange={(e) => setSettings({...settings, defaultExportFormat: e.target.value})}
                options={[
                  { value: 'csv', label: 'CSV (Excel compatible)' },
                  { value: 'pdf', label: 'PDF (Printable reports)' },
                  { value: 'json', label: 'JSON (Developer format)' }
                ]}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Default Export Fields
              </label>
              <div className="space-y-2 max-h-60 overflow-y-auto p-2 border rounded-lg">
                {[
                  { id: 'name', label: 'Candidate Name' },
                  { id: 'email', label: 'Email Address' },
                  { id: 'phone', label: 'Phone Number' },
                  { id: 'skills', label: 'Skills & Technologies' },
                  { id: 'experience', label: 'Years of Experience' },
                  { id: 'score', label: 'Match Score', required: true },
                  { id: 'location', label: 'Location' },
                  { id: 'availability', label: 'Availability' },
                  { id: 'education', label: 'Education Background' }
                ].map(field => (
                  <label key={field.id} className="flex items-center p-2 hover:bg-gray-50 rounded">
                    <input
                      type="checkbox"
                      checked={settings.exportFields.includes(field.id)}
                      disabled={field.required}
                      onChange={(e) => {
                        const newFields = [...settings.exportFields];
                        if (e.target.checked) {
                          newFields.push(field.id);
                        } else {
                          const index = newFields.indexOf(field.id);
                          if (index > -1) newFields.splice(index, 1);
                        }
                        setSettings({...settings, exportFields: newFields});
                      }}
                      className="mr-3 w-4 h-4 text-green-600 rounded focus:ring-2 focus:ring-green-500"
                    />
                    <span className={field.required ? 'font-medium' : ''}>
                      {field.label}
                      {field.required && <span className="ml-1 text-xs text-green-600">(always included)</span>}
                    </span>
                  </label>
                ))}
              </div>
            </div>
          </div>
        </Card>

        {/* Workflow Preferences */}
        <Card className="mb-8">
          <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
            <Clock className="w-6 h-6 text-yellow-600" />
            Workflow Preferences
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Auto-Refresh Interval
              </label>
              <Select
                value={settings.autoRefreshInterval.toString()}
                onChange={(e) => setSettings({...settings, autoRefreshInterval: Number(e.target.value)})}
                options={[
                  { value: '0', label: 'Never (manual refresh only)' },
                  { value: '30', label: 'Every 30 seconds' },
                  { value: '60', label: 'Every minute' },
                  { value: '300', label: 'Every 5 minutes' }
                ]}
              />
              <p className="text-xs text-gray-600 mt-1">
                How often to automatically refresh your dashboard and lists
              </p>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Default Dashboard Metrics
              </label>
              <Select
                multiple
                value={settings.dashboardMetrics}
                onChange={(value) => setSettings({...settings, dashboardMetrics: value as string[]})}
                options={[
                  { value: 'active_jobs', label: 'Active Jobs' },
                  { value: 'submissions', label: 'Submissions' },
                  { value: 'placements', label: 'Placements This Month' },
                  { value: 'time_to_fill', label: 'Avg. Time to Fill' },
                  { value: 'conversion_rate', label: 'Submission to Placement Rate' },
                  { value: 'revenue', label: 'Revenue Tracked' }
                ]}
                placeholder="Select your preferred metrics..."
              />
            </div>
          </div>
        </Card>

        {/* Save Actions */}
        <div className="flex items-center justify-end gap-4 pt-6 border-t border-gray-200">
          <Button variant="outline" size="lg" onClick={() => router.push('/dashboard')}>
            Cancel
          </Button>
          <Button 
            size="lg" 
            onClick={handleSave} 
            isLoading={saving}
            leftIcon={<Save className="w-5 h-5" />}
          >
            Save Settings
          </Button>
        </div>
      </PageContainer>
    </>
  );
}