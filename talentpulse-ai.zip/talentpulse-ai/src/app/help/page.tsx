// app/help/page.tsx
'use client';

import { useState } from 'react';
import { PageContainer } from '@/components/layout/PageContainer';
import { Card } from '@/components/ui';
import { useAuth } from '@/lib/auth/AuthContext';

export default function HelpPage() {
  const { userProfile } = useAuth();
  const [activeSection, setActiveSection] = useState('getting-started');

  const sections = {
    'getting-started': {
      title: 'Getting Started',
      content: (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Welcome to TalentPlus!</h3>
          <p>TalentPlus is your all-in-one recruitment management system designed for consultancies.</p>
          
          <h4 className="font-semibold mt-6">Quick Start Guide:</h4>
          <ol className="list-decimal list-inside space-y-2">
            <li>Add your first client in the Clients module</li>
            <li>Create a job requirement for that client</li>
            <li>Search for candidates in the Library or upload resumes</li>
            <li>Use AI Match to find the best candidates</li>
            <li>Submit candidates through the workflow</li>
            <li>Track progress in Submissions</li>
          </ol>
        </div>
      ),
    },
    'admin-guide': {
      title: 'Admin Guide',
      content: (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Admin Responsibilities</h3>
          
          <h4 className="font-semibold mt-4">1. Client Management</h4>
          <ul className="list-disc list-inside space-y-1 ml-4">
            <li>Add new clients with complete details</li>
            <li>Set payment terms and billing information</li>
            <li>Maintain client relationships</li>
          </ul>

          <h4 className="font-semibold mt-4">2. Job Creation</h4>
          <ul className="list-disc list-inside space-y-1 ml-4">
            <li>Create jobs from client requirements</li>
            <li>Set client rate, pay rate, and margins</li>
            <li>Assign jobs to recruiters or teams</li>
            <li>Set priorities and deadlines</li>
          </ul>

          <h4 className="font-semibold mt-4">3. Team Management</h4>
          <ul className="list-disc list-inside space-y-1 ml-4">
            <li>Create and manage teams</li>
            <li>Assign team leads</li>
            <li>Monitor team performance</li>
          </ul>

          <h4 className="font-semibold mt-4">4. Reporting</h4>
          <ul className="list-disc list-inside space-y-1 ml-4">
            <li>Generate client reports</li>
            <li>Track placements and revenue</li>
            <li>Monitor recruiter performance</li>
          </ul>
        </div>
      ),
    },
    'recruiter-guide': {
      title: 'Recruiter Guide',
      content: (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Daily Workflow</h3>
          
          <h4 className="font-semibold mt-4">1. Check Assigned Jobs</h4>
          <p>Go to Jobs → Filter by "Assigned to Me" to see your active jobs.</p>

          <h4 className="font-semibold mt-4">2. Search for Candidates</h4>
          <ul className="list-disc list-inside space-y-1 ml-4">
            <li><strong>Internal Search:</strong> Use Library with advanced filters</li>
            <li><strong>LinkedIn Search:</strong> Use Match page → Search LinkedIn</li>
            <li><strong>Upload Resume:</strong> Library → Upload → AI auto-parses</li>
          </ul>

          <h4 className="font-semibold mt-4">3. Pre-Screening (MANDATORY)</h4>
          <p>Before submitting any candidate:</p>
          <ul className="list-disc list-inside space-y-1 ml-4">
            <li>Call the candidate</li>
            <li>Verify rate, RTR, availability, visa status</li>
            <li>Record screening in system</li>
            <li>Check for other submissions</li>
          </ul>

          <h4 className="font-semibold mt-4">4. Submit for Review</h4>
          <ul className="list-disc list-inside space-y-1 ml-4">
            <li>Use AI Match to get match score</li>
            <li>Submit to Team Lead for internal review</li>
            <li>Wait for approval</li>
          </ul>

          <h4 className="font-semibold mt-4">5. Client Submission</h4>
          <ul className="list-disc list-inside space-y-1 ml-4">
            <li>After approval, submit to client</li>
            <li>Track status in Submissions</li>
            <li>Update as client responds</li>
          </ul>

          <h4 className="font-semibold mt-4">6. Interview Coordination</h4>
          <ul className="list-disc list-inside space-y-1 ml-4">
            <li>Schedule interviews in system</li>
            <li>Prepare candidate with notes</li>
            <li>Collect feedback after each round</li>
          </ul>
        </div>
      ),
    },
    'features': {
      title: 'Key Features',
      content: (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">AI-Powered Features</h3>
          
          <div className="space-y-4">
            <div>
              <h4 className="font-semibold">Resume Parsing</h4>
              <p>Upload PDF/DOCX resumes and AI automatically extracts:</p>
              <ul className="list-disc list-inside ml-4">
                <li>Contact information</li>
                <li>Skills and experience</li>
                <li>Education and certifications</li>
                <li>Work history with dates</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold">AI Matching</h4>
              <p>Multi-factor matching algorithm considers:</p>
              <ul className="list-disc list-inside ml-4">
                <li>Skills match (40% weight)</li>
                <li>Experience level (30% weight)</li>
                <li>Location (20% weight)</li>
                <li>Education (10% weight)</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold">Fraud Detection</h4>
              <p>AI analyzes resumes for authenticity, checking:</p>
              <ul className="list-disc list-inside ml-4">
                <li>Timeline consistency</li>
                <li>Realistic career progression</li>
                <li>Appropriate skill levels</li>
                <li>Grammar and professionalism</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold">Multi-LLM Fallback</h4>
              <p>System tries multiple AI providers automatically:</p>
              <ul className="list-disc list-inside ml-4">
                <li>Primary: OpenAI GPT-4</li>
                <li>Fallback 1: Claude</li>
                <li>Fallback 2: Gemini</li>
              </ul>
              <p className="text-sm text-gray-600 mt-2">
                This ensures AI features ALWAYS work, even if one provider is down.
              </p>
            </div>
          </div>
        </div>
      ),
    },
  };

  return (
    <PageContainer
      title="Help & Documentation"
      description="Learn how to use TalentPlus effectively"
    >
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar */}
        <div className="lg:col-span-1">
          <Card className="p-4">
            <h3 className="font-semibold mb-4">Topics</h3>
            <nav className="space-y-2">
              {Object.entries(sections).map(([key, section]) => (
                <button
                  key={key}
                  onClick={() => setActiveSection(key)}
                  className={`w-full text-left px-3 py-2 rounded transition-colors ${
                    activeSection === key
                      ? 'bg-blue-50 text-blue-600 font-medium'
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  {section.title}
                </button>
              ))}
            </nav>
          </Card>
        </div>

        {/* Content */}
        <div className="lg:col-span-3">
          <Card className="p-6">
            {sections[activeSection as keyof typeof sections].content}
          </Card>
        </div>
      </div>
    </PageContainer>
  );
}