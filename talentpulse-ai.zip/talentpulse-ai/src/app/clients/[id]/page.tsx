'use client';

import { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import Header from '@/components/layout/Header';
import PageContainer from '@/components/layout/PageContainer';
import { Button, Card, Badge, Alert, Loading, Modal } from '@/components/ui';
import {
  Edit,
  Trash2,
  Mail,
  Phone,
  Globe,
  MapPin,
  Briefcase,
  Send,
  Plus,
} from 'lucide-react';
import { Client, Job } from '@/lib/types';
import { formatRelativeDate } from '@/lib/utils';

// Mock data
const mockClient: Client = {
  id: '1',
  company_name: 'Tech Innovations Inc',
  industry: 'Technology',
  website: 'https://techinnovations.com',
  contact_name: 'John Smith',
  contact_email: 'john@techinnovations.com',
  contact_phone: '+1 (555) 123-4567',
  address: '123 Tech Street, Suite 100',
  city: 'San Francisco',
  state: 'CA',
  zip_code: '94105',
  country: 'USA',
  notes: 'Great long-term client with multiple ongoing projects. Prefers candidates with startup experience and modern tech stack knowledge.',
  created_at: '2024-01-15T10:00:00Z',
  updated_at: '2024-11-28T15:30:00Z',
  active_jobs_count: 3,
  total_submissions: 45,
};

const mockJobs: Job[] = [
  {
    id: '1',
    title: 'Senior Full Stack Developer',
    description: 'Looking for experienced developer',
    requirements: [],
    skills_required: ['React', 'Node.js', 'TypeScript'],
    location: 'San Francisco, CA',
    employment_type: 'full-time',
    experience_level: 'senior',
    status: 'open',
    client_id: '1',
    created_at: '2024-11-20T10:00:00Z',
    updated_at: '2024-11-20T10:00:00Z',
    submissions_count: 12,
  },
  {
    id: '3',
    title: 'DevOps Engineer',
    description: 'Need skilled DevOps professional',
    requirements: [],
    skills_required: ['Kubernetes', 'AWS', 'Docker'],
    location: 'Austin, TX',
    employment_type: 'full-time',
    experience_level: 'senior',
    status: 'open',
    client_id: '1',
    created_at: '2024-11-28T09:15:00Z',
    updated_at: '2024-11-28T09:15:00Z',
    submissions_count: 5,
  },
];

export default function ClientDetailPage() {
  const router = useRouter();
  const params = useParams();
  const clientId = params.id as string;

  const [client, setClient] = useState<Client | null>(null);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    // TODO: Fetch client and jobs from API
    setTimeout(() => {
      setClient(mockClient);
      setJobs(mockJobs);
      setIsLoading(false);
    }, 500);
  }, [clientId]);

  const handleEdit = () => {
    router.push(`/clients/${clientId}/edit`);
  };

  const handleDelete = async () => {
    setIsDeleting(true);
    try {
      // TODO: API call to delete client
      await new Promise((resolve) => setTimeout(resolve, 1000));
      router.push('/clients');
    } catch (error) {
      console.error('Failed to delete client:', error);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleCreateJob = () => {
    router.push(`/jobs/new?client=${clientId}`);
  };

  if (isLoading) {
    return (
      <>
        <Header title="Client Details" />
        <PageContainer>
          <Loading size="lg" text="Loading client details..." />
        </PageContainer>
      </>
    );
  }

  if (!client) {
    return (
      <>
        <Header title="Client Not Found" />
        <PageContainer>
          <Alert variant="danger">Client not found</Alert>
        </PageContainer>
      </>
    );
  }

  return (
    <>
      <Header
        title={client.company_name}
        subtitle={client.industry}
        actions={
          <div className="flex gap-3">
            <Button variant="outline" leftIcon={<Plus className="w-4 h-4" />} onClick={handleCreateJob}>
              Create Job
            </Button>
            <Button variant="outline" leftIcon={<Edit className="w-4 h-4" />} onClick={handleEdit}>
              Edit
            </Button>
            <Button variant="danger" leftIcon={<Trash2 className="w-4 h-4" />} onClick={() => setShowDeleteModal(true)}>
              Delete
            </Button>
          </div>
        }
      />

      <PageContainer maxWidth="xl">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Company Overview */}
            <Card>
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-2">{client.company_name}</h2>
                  <Badge variant="primary" size="lg">
                    {client.industry}
                  </Badge>
                </div>
              </div>

              <div className="space-y-3">
                {client.website && (
                  <div className="flex items-center text-gray-700">
                    <Globe className="w-5 h-5 mr-3 text-gray-400" />
                    <a
                      href={client.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary-600 hover:underline"
                    >
                      {client.website}
                    </a>
                  </div>
                )}

                {(client.address || client.city || client.state) && (
                  <div className="flex items-start text-gray-700">
                    <MapPin className="w-5 h-5 mr-3 text-gray-400 mt-0.5" />
                    <div>
                      {client.address && <p>{client.address}</p>}
                      <p>
                        {[client.city, client.state, client.zip_code].filter(Boolean).join(', ')}
                      </p>
                      {client.country && <p>{client.country}</p>}
                    </div>
                  </div>
                )}
              </div>

              {client.notes && (
                <div className="mt-6 pt-6 border-t border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Notes</h3>
                  <p className="text-gray-700 leading-relaxed">{client.notes}</p>
                </div>
              )}
            </Card>

            {/* Active Jobs */}
            <Card>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-gray-900">
                  Active Jobs ({jobs.length})
                </h3>
                <Button size="sm" leftIcon={<Plus className="w-4 h-4" />} onClick={handleCreateJob}>
                  Create Job
                </Button>
              </div>

              {jobs.length === 0 ? (
                <div className="text-center py-8">
                  <Briefcase className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-600 mb-4">No active jobs for this client</p>
                  <Button size="sm" onClick={handleCreateJob}>
                    Create First Job
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {jobs.map((job) => (
                    <div
                      key={job.id}
                      className="p-4 border border-gray-200 rounded-lg hover:border-primary-300 transition-colors cursor-pointer"
                      onClick={() => router.push(`/jobs/${job.id}`)}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-semibold text-gray-900">{job.title}</h4>
                        <Badge variant={job.status === 'open' ? 'success' : 'warning'}>
                          {job.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-3">{job.location}</p>
                      <div className="flex flex-wrap gap-2 mb-3">
                        {job.skills_required.slice(0, 5).map((skill, index) => (
                          <Badge key={index} size="sm" variant="gray">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                      <div className="flex items-center justify-between text-sm text-gray-500">
                        <div className="flex items-center">
                          <Send className="w-4 h-4 mr-1" />
                          {job.submissions_count} submissions
                        </div>
                        <div>{formatRelativeDate(job.created_at)}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Contact Information */}
            <Card>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Contact Information</h3>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Contact Person</p>
                  <p className="font-semibold text-gray-900">{client.contact_name}</p>
                </div>

                <div>
                  <p className="text-sm text-gray-600 mb-1">Email</p>
                  <a
                    href={`mailto:${client.contact_email}`}
                    className="flex items-center text-primary-600 hover:underline"
                  >
                    <Mail className="w-4 h-4 mr-2" />
                    {client.contact_email}
                  </a>
                </div>

                <div>
                  <p className="text-sm text-gray-600 mb-1">Phone</p>
                  <a
                    href={`tel:${client.contact_phone}`}
                    className="flex items-center text-primary-600 hover:underline"
                  >
                    <Phone className="w-4 h-4 mr-2" />
                    {client.contact_phone}
                  </a>
                </div>
              </div>
            </Card>

            {/* Statistics */}
            <Card>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Statistics</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center text-gray-600">
                    <Briefcase className="w-5 h-5 mr-2" />
                    <span>Active Jobs</span>
                  </div>
                  <span className="text-2xl font-bold text-gray-900">
                    {client.active_jobs_count}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center text-gray-600">
                    <Send className="w-5 h-5 mr-2" />
                    <span>Total Submissions</span>
                  </div>
                  <span className="text-2xl font-bold text-gray-900">
                    {client.total_submissions}
                  </span>
                </div>
              </div>
            </Card>

            {/* Timeline */}
            <Card>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Timeline</h3>
              <div className="space-y-3">
                <div>
                  <p className="text-sm text-gray-600">Client Since</p>
                  <p className="font-semibold text-gray-900">
                    {new Date(client.created_at).toLocaleDateString('en-US', {
                      month: 'long',
                      day: 'numeric',
                      year: 'numeric',
                    })}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Last Updated</p>
                  <p className="font-semibold text-gray-900">
                    {formatRelativeDate(client.updated_at)}
                  </p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </PageContainer>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={showDeleteModal}
        onClose={() => setShowDeleteModal(false)}
        title="Delete Client"
        description="Are you sure you want to delete this client? This action cannot be undone."
        footer={
          <>
            <Button variant="outline" onClick={() => setShowDeleteModal(false)} disabled={isDeleting}>
              Cancel
            </Button>
            <Button variant="danger" onClick={handleDelete} isLoading={isDeleting}>
              Delete Client
            </Button>
          </>
        }
      >
        <Alert variant="warning">
          <p className="font-semibold mb-2">This will permanently delete:</p>
          <ul className="list-disc list-inside space-y-1 text-sm">
            <li>The client: {client.company_name}</li>
            <li>All associated jobs ({client.active_jobs_count})</li>
            <li>All submission records ({client.total_submissions})</li>
          </ul>
        </Alert>
      </Modal>
    </>
  );
}