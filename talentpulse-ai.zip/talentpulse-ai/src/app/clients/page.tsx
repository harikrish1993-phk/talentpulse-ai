// src/app/clients/page.tsx - COMPLETE PRODUCTION VERSION
'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import {
  Building2, Users, FilePlus, Search, Filter, Plus, Eye,
  Edit2, Trash2, ArrowLeft, Save, X, ChevronDown, ChevronUp,
  Tag, TrendingUp, CheckCircle, Activity, AlertCircle
} from 'lucide-react';
import ClientCard from './components/ClientCard';
import { Client } from '@/lib/types';

const initialClients: Client[] = [
  {
    id: '1',
    name: 'TechCorp Solutions',
    type: 'direct',
    status: 'active',
    primary_contact_name: 'John Smith',
    primary_contact_email: 'john@techcorp.com',
    primary_contact_phone: '+32 2 123 4567',
    primary_contact_title: 'HR Director',
    industry: 'Technology',
    company_size: '201-500',
    website: 'https://techcorp.com',
    city: 'Brussels',
    country: 'Belgium',
    total_jobs: 15,
    active_jobs: 5,
    total_placements: 8,
    total_revenue: 125000,
    created_at: '2024-03-15T10:00:00Z',
    last_contact: '2024-11-15T14:30:00Z',
    notes: 'Key strategic account - enterprise client',
    tags: ['Key Account', 'IT Sector', 'High Priority'],
    is_favorite: true,
    relationship_score: 85,
    contact_frequency: 'weekly'
  },
  {
    id: '2',
    name: 'DataFlow Inc',
    type: 'direct',
    status: 'active',
    primary_contact_name: 'Sarah Lee',
    primary_contact_email: 'sarah@dataflow.com',
    primary_contact_phone: '+31 20 345 6789',
    primary_contact_title: 'Talent Manager',
    industry: 'Data Analytics',
    company_size: '51-200',
    website: 'https://dataflow.com',
    city: 'Amsterdam',
    country: 'Netherlands',
    total_jobs: 8,
    active_jobs: 3,
    total_placements: 5,
    total_revenue: 78000,
    created_at: '2024-06-20T14:30:00Z',
    last_contact: '2024-11-17T09:15:00Z',
    notes: 'Growing client with expanding needs',
    tags: ['Data Science', 'Growth Client'],
    is_favorite: false,
    relationship_score: 72,
    contact_frequency: 'monthly'
  },
  {
    id: '3',
    name: 'Randstad Belgium',
    type: 'agency',
    status: 'active',
    primary_contact_name: 'Anna Wilson',
    primary_contact_email: 'anna@randstad.be',
    primary_contact_phone: '+32 2 987 6543',
    primary_contact_title: 'Senior Account Manager',
    industry: 'Staffing & Recruiting',
    company_size: '501+',
    website: 'https://randstad.be',
    city: 'Antwerp',
    country: 'Belgium',
    total_jobs: 22,
    active_jobs: 8,
    total_placements: 12,
    total_revenue: 95000,
    created_at: '2024-01-10T09:00:00Z',
    last_contact: '2024-11-14T11:45:00Z',
    notes: 'High-volume agency partner with consistent workflow',
    tags: ['Agency Partner', 'Volume'],
    is_favorite: true,
    relationship_score: 90,
    contact_frequency: 'bi-weekly'
  }
];

export default function ClientManagement() {
  const router = useRouter();
  const [clients, setClients] = useState<Client[]>(initialClients);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive' | 'prospect'>('all');
  const [typeFilter, setTypeFilter] = useState<'all' | 'direct' | 'agency'>('all');
  const [sortField, setSortField] = useState<'name' | 'created_at' | 'total_revenue' | 'relationship_score'>('created_at');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [showModal, setShowModal] = useState<'add' | 'edit' | 'delete' | null>(null);
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    totalRevenue: 0,
    avgRelationship: 0,
    newThisMonth: 0
  });

  useEffect(() => {
    loadClients();
  }, []);

  useEffect(() => {
    calculateStats();
  }, [clients]);

  async function loadClients() {
    try {
      setLoading(true);
      // In a real app, this would fetch from your API
      // const res = await fetch('/api/clients');
      // const data = await res.json();
      // setClients(data.data || []);
      
      // For now, use mock data but simulate loading
      await new Promise(resolve => setTimeout(resolve, 500));
      setClients(initialClients);
    } catch (error) {
      console.error('Failed to load clients:', error);
    } finally {
      setLoading(false);
    }
  }

  function calculateStats() {
    setStats({
      total: clients.length,
      active: clients.filter(c => c.status === 'active').length,
      totalRevenue: clients.reduce((sum, c) => sum + (c.total_revenue || 0), 0),
      avgRelationship: clients.length > 0 
        ? Math.round(clients.reduce((sum, c) => sum + (c.relationship_score || 0), 0) / clients.length)
        : 0,
      newThisMonth: clients.filter(c => {
        const created = new Date(c.created_at);
        const now = new Date();
        return created.getMonth() === now.getMonth() && created.getFullYear() === now.getFullYear();
      }).length
    });
  }

  const filteredClients = clients
    .filter(client => {
      const matchesSearch = searchQuery === '' || 
        client.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        client.primary_contact_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        client.primary_contact_email.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesStatus = statusFilter === 'all' || client.status === statusFilter;
      const matchesType = typeFilter === 'all' || client.type === typeFilter;
      
      return matchesSearch && matchesStatus && matchesType;
    })
    .sort((a, b) => {
      let comparison = 0;
      
      switch (sortField) {
        case 'name':
          comparison = a.name.localeCompare(b.name);
          break;
        case 'created_at':
          comparison = new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
          break;
        case 'total_revenue':
          comparison = (a.total_revenue || 0) - (b.total_revenue || 0);
          break;
        case 'relationship_score':
          comparison = (a.relationship_score || 0) - (b.relationship_score || 0);
          break;
      }
      
      return sortDirection === 'asc' ? comparison : -comparison;
    });

  const handleDeleteClient = (client: Client) => {
    setSelectedClient(client);
    setShowModal('delete');
  };

  const confirmDelete = () => {
    if (selectedClient) {
      setClients(clients.filter(c => c.id !== selectedClient.id));
      setShowModal(null);
      setSelectedClient(null);
    }
  };

  const handleAddClient = () => {
    setSelectedClient(null);
    setShowModal('add');
  };

  const handleEditClient = (client: Client) => {
    setSelectedClient(client);
    setShowModal('edit');
  };

  const handleSaveClient = (clientData: Partial<Client>) => {
    if (selectedClient) {
      // Edit existing
      setClients(clients.map(c => c.id === selectedClient.id ? { ...c, ...clientData } : c));
    } else {
      // Add new
      const newClient: Client = {
        id: (Date.now().toString()),
        created_at: new Date().toISOString(),
        relationship_score: 50,
        is_favorite: false,
        contact_frequency: 'monthly',
        ...clientData
      } as Client;
      
      setClients([...clients, newClient]);
    }
    setShowModal(null);
    setSelectedClient(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading clients...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Client Management
              </h1>
              <p className="text-gray-600 mt-2">
                Manage your client relationships and track engagement
              </p>
            </div>
            <button
              onClick={handleAddClient}
              className="flex items-center px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 shadow-md transition"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add New Client
            </button>
          </div>
          
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
            <StatCard 
              label="Total Clients" 
              value={stats.total} 
              icon={Building2} 
              color="blue"
            />
            <StatCard 
              label="Active Clients" 
              value={stats.active} 
              icon={CheckCircle} 
              color="green"
            />
            <StatCard 
              label="Monthly Revenue" 
              value={`€${formatCurrency(stats.totalRevenue / 12)}`} 
              icon={TrendingUp} 
              color="purple"
            />
            <StatCard 
              label="Avg. Relationship" 
              value={`${stats.avgRelationship}%`} 
              icon={Users} 
              color="orange"
            />
            <StatCard 
              label="New This Month" 
              value={stats.newThisMonth} 
              icon={FilePlus} 
              color="teal"
            />
          </div>
        </div>
        
        {/* Search & Filters */}
        <div className="bg-white rounded-2xl shadow-lg border p-6 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by name, contact, or email..."
                className="w-full pl-10 pr-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            </div>
            
            {/* Filters */}
            <div className="flex gap-3">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Statuses</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
                <option value="prospect">Prospects</option>
              </select>
              
              <select
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value as any)}
                className="px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Types</option>
                <option value="direct">Direct Clients</option>
                <option value="agency">Agency Partners</option>
              </select>
            </div>
          </div>
          
          {/* Sorting */}
          <div className="mt-4 flex items-center justify-end gap-4">
            <span className="text-sm text-gray-600">Sort by:</span>
            <select
              value={sortField}
              onChange={(e) => setSortField(e.target.value as any)}
              className="px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 text-sm"
            >
              <option value="name">Name</option>
              <option value="created_at">Date Created</option>
              <option value="total_revenue">Revenue</option>
              <option value="relationship_score">Relationship Score</option>
            </select>
            
            <button
              onClick={() => setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc')}
              className="p-2 border rounded-lg hover:bg-gray-50"
            >
              {sortDirection === 'asc' ? (
                <ChevronUp className="w-5 h-5" />
              ) : (
                <ChevronDown className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>
        
        {/* Client List */}
        {filteredClients.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-lg border p-16 text-center">
            <Building2 className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            {searchQuery || statusFilter !== 'all' || typeFilter !== 'all' ? (
              <>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">No clients match your filters</h3>
                <p className="text-gray-600 mb-6">Try adjusting your search criteria or filters</p>
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setStatusFilter('all');
                    setTypeFilter('all');
                  }}
                  className="px-6 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200"
                >
                  Clear Filters
                </button>
              </>
            ) : (
              <>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">No clients yet</h3>
                <p className="text-gray-600 mb-6">Add your first client to start tracking relationships</p>
                <button
                  onClick={handleAddClient}
                  className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  <Plus className="w-5 h-5 mr-2" />
                  Add First Client
                </button>
              </>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredClients.map(client => (
              <ClientCard
                key={client.id}
                client={client}
                onEdit={handleEditClient}
                onDelete={handleDeleteClient}
                onView={() => router.push(`/clients/${client.id}`)}
              />
            ))}
          </div>
        )}
      </div>
      
      {/* Modals */}
      {(showModal === 'add' || showModal === 'edit') && selectedClient && (
        <ClientFormModal
          client={selectedClient}
          onClose={() => {
            setShowModal(null);
            setSelectedClient(null);
          }}
          onSave={handleSaveClient}
        />
      )}
      
      {showModal === 'add' && !selectedClient && (
        <ClientFormModal
          onClose={() => {
            setShowModal(null);
            setSelectedClient(null);
          }}
          onSave={handleSaveClient}
        />
      )}
      
      {showModal === 'delete' && selectedClient && (
        <DeleteConfirmationModal
          title="Delete Client"
          message={`Are you sure you want to delete ${selectedClient.name}? This will remove all associated data.`}
          onConfirm={confirmDelete}
          onCancel={() => {
            setShowModal(null);
            setSelectedClient(null);
          }}
        />
      )}
    </div>
  );
}

// Helper Components
function StatCard({ label, value, icon: Icon, color }: any) {
  const colorClasses = {
    blue: 'bg-blue-50 text-blue-600 border-blue-200',
    green: 'bg-green-50 text-green-600 border-green-200',
    purple: 'bg-purple-50 text-purple-600 border-purple-200',
    orange: 'bg-orange-50 text-orange-600 border-orange-200',
    teal: 'bg-teal-50 text-teal-600 border-teal-200'
  };
  
  return (
    <div className="bg-white rounded-xl p-4 border shadow-sm hover:shadow-md transition">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-gray-600">{label}</p>
          <p className="text-2xl font-bold text-gray-900">{value}</p>
        </div>
        <div className={`p-3 rounded-lg ${colorClasses[color]}`}>
          <Icon className="w-6 h-6" />
        </div>
      </div>
    </div>
  );
}

function DeleteConfirmationModal({ title, message, onConfirm, onCancel }: any) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md">
        <div className="p-6">
          <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertCircle className="w-6 h-6 text-red-600" />
          </div>
          <h3 className="text-xl font-bold text-center mb-2">{title}</h3>
          <p className="text-center text-gray-600 mb-6">{message}</p>
          <div className="flex gap-4">
            <button
              onClick={onCancel}
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 font-medium"
            >
              Cancel
            </button>
            <button
              onClick={onConfirm}
              className="flex-1 px-4 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 font-medium"
            >
              Delete
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function ClientFormModal({ client, onClose, onSave }: { client?: Client; onClose: () => void; onSave: (data: Partial<Client>) => void }) {
  const [formData, setFormData] = useState<Partial<Client>>(client || {
    name: '',
    type: 'direct',
    status: 'active',
    primary_contact_name: '',
    primary_contact_email: '',
    industry: '',
    website: '',
    city: '',
    country: 'Belgium'
  });
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Basic validation
    if (!formData.name || !formData.primary_contact_name || !formData.primary_contact_email) {
      alert('Please fill in all required fields');
      return;
    }
    onSave(formData);
  };
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200 flex justify-between items-center">
          <h3 className="text-xl font-bold">
            {client ? 'Edit Client' : 'Add New Client'}
          </h3>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Basic Info */}
          <section>
            <h4 className="text-lg font-semibold mb-4">Basic Information</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Company Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.name || ''}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Client Type <span className="text-red-500">*</span>
                </label>
                <select
                  value={formData.type || 'direct'}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  required
                >
                  <option value="direct">Direct Client</option>
                  <option value="agency">Agency/Consultancy</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Status <span className="text-red-500">*</span>
                </label>
                <select
                  value={formData.status || 'active'}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  required
                >
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                  <option value="prospect">Prospect</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Industry
                </label>
                <input
                  type="text"
                  value={formData.industry || ''}
                  onChange={(e) => setFormData({ ...formData, industry: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="Technology, Finance, Healthcare, etc."
                />
              </div>
            </div>
          </section>
          
          {/* Contact Info */}
          <section className="pt-4 border-t border-gray-200">
            <h4 className="text-lg font-semibold mb-4">Primary Contact</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Contact Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.primary_contact_name || ''}
                  onChange={(e) => setFormData({ ...formData, primary_contact_name: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Title/Position
                </label>
                <input
                  type="text"
                  value={formData.primary_contact_title || ''}
                  onChange={(e) => setFormData({ ...formData, primary_contact_title: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="HR Director, Talent Manager, etc."
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  value={formData.primary_contact_email || ''}
                  onChange={(e) => setFormData({ ...formData, primary_contact_email: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Phone
                </label>
                <input
                  type="tel"
                  value={formData.primary_contact_phone || ''}
                  onChange={(e) => setFormData({ ...formData, primary_contact_phone: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="+32 2 123 4567"
                />
              </div>
            </div>
          </section>
          
          {/* Company Details */}
          <section className="pt-4 border-t border-gray-200">
            <h4 className="text-lg font-semibold mb-4">Company Details</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Website
                </label>
                <input
                  type="url"
                  value={formData.website || ''}
                  onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="https://company.com"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Company Size
                </label>
                <select
                  value={formData.company_size || ''}
                  onChange={(e) => setFormData({ ...formData, company_size: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select size</option>
                  <option value="1-10">1-10 employees</option>
                  <option value="11-50">11-50 employees</option>
                  <option value="51-200">51-200 employees</option>
                  <option value="201-500">201-500 employees</option>
                  <option value="501+">501+ employees</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  City
                </label>
                <input
                  type="text"
                  value={formData.city || ''}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="Brussels, Antwerp, Ghent"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Country
                </label>
                <select
                  value={formData.country || 'Belgium'}
                  onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Belgium">Belgium</option>
                  <option value="Netherlands">Netherlands</option>
                  <option value="France">France</option>
                  <option value="Germany">Germany</option>
                  <option value="Luxembourg">Luxembourg</option>
                </select>
              </div>
              
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Address
                </label>
                <textarea
                  value={formData.address || ''}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  rows={3}
                  placeholder="Street address, building, floor"
                />
              </div>
            </div>
          </section>
          
          {/* Relationship Details */}
          <section className="pt-4 border-t border-gray-200">
            <h4 className="text-lg font-semibold mb-4">Relationship Details</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Relationship Score (1-100)
                </label>
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={formData.relationship_score || 50}
                  onChange={(e) => setFormData({ 
                    ...formData, 
                    relationship_score: Math.min(100, Math.max(1, Number(e.target.value))) 
                  })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Contact Frequency
                </label>
                <select
                  value={formData.contact_frequency || 'monthly'}
                  onChange={(e) => setFormData({ ...formData, contact_frequency: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                >
                  <option value="weekly">Weekly</option>
                  <option value="bi-weekly">Bi-weekly</option>
                  <option value="monthly">Monthly</option>
                  <option value="quarterly">Quarterly</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Notes
                </label>
                <textarea
                  value={formData.notes || ''}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  rows={3}
                  placeholder="Special preferences, key information, or notes about this client"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Tags (comma-separated)
                </label>
                <input
                  type="text"
                  value={formData.tags?.join(', ') || ''}
                  onChange={(e) => setFormData({ 
                    ...formData, 
                    tags: e.target.value.split(',').map(tag => tag.trim()).filter(tag => tag.length > 0)
                  })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="Key Account, IT Sector, High Priority"
                />
              </div>
            </div>
          </section>
          
          <div className="flex gap-3 pt-6 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 font-medium"
            >
              <Save className="w-5 h-5 mr-2 inline" />
              {client ? 'Update Client' : 'Add Client'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}