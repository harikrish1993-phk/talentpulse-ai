'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Header from '@/components/layout/Header';
import PageContainer from '@/components/layout/PageContainer';
import { Button, Input, Select, Textarea, Card, Alert } from '@/components/ui';
import { Save, X } from 'lucide-react';
import { ClientFormData } from '@/lib/types';

export default function NewClientPage() {
  const router = useRouter();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const [formData, setFormData] = useState<ClientFormData>({
    company_name: '',
    industry: '',
    website: '',
    contact_name: '',
    contact_email: '',
    contact_phone: '',
    address: '',
    city: '',
    state: '',
    zip_code: '',
    country: 'USA',
    notes: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleInputChange = (field: keyof ClientFormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    // Clear error for this field
    if (errors[field]) {
      setErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.company_name.trim()) {
      newErrors.company_name = 'Company name is required';
    }

    if (!formData.industry.trim()) {
      newErrors.industry = 'Industry is required';
    }

    if (!formData.contact_name.trim()) {
      newErrors.contact_name = 'Contact name is required';
    }

    if (!formData.contact_email.trim()) {
      newErrors.contact_email = 'Contact email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.contact_email)) {
      newErrors.contact_email = 'Invalid email format';
    }

    if (!formData.contact_phone.trim()) {
      newErrors.contact_phone = 'Contact phone is required';
    }

    if (formData.website && !/^https?:\/\/.+/.test(formData.website)) {
      newErrors.website = 'Website must start with http:// or https://';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    setError(null);
    setSuccess(false);

    if (!validateForm()) {
      setError('Please fix the errors in the form');
      return;
    }

    setIsSubmitting(true);

    try {
      // TODO: API call to create client
      console.log('Creating client:', formData);

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000));

      setSuccess(true);
      setTimeout(() => {
        router.push('/clients');
      }, 1500);
    } catch (err) {
      setError('Failed to create client. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <Header
        title="Add New Client"
        subtitle="Fill in the details to add a new client to your database"
      />

      <PageContainer maxWidth="lg">
        {error && (
          <Alert variant="danger" className="mb-6" onClose={() => setError(null)}>
            {error}
          </Alert>
        )}

        {success && (
          <Alert variant="success" className="mb-6">
            Client added successfully! Redirecting...
          </Alert>
        )}

        <form onSubmit={(e) => e.preventDefault()}>
          {/* Company Information */}
          <Card className="mb-6">
            <h2 className="text-xl font-bold text-gray-900 mb-6">Company Information</h2>

            <div className="space-y-4">
              <Input
                label="Company Name"
                placeholder="e.g., Tech Innovations Inc"
                value={formData.company_name}
                onChange={(e) => handleInputChange('company_name', e.target.value)}
                error={errors.company_name}
                required
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Select
                  label="Industry"
                  placeholder="Select industry"
                  value={formData.industry}
                  onChange={(e) => handleInputChange('industry', e.target.value)}
                  error={errors.industry}
                  required
                  options={[
                    { value: 'Technology', label: 'Technology' },
                    { value: 'Finance', label: 'Finance' },
                    { value: 'Healthcare', label: 'Healthcare' },
                    { value: 'Retail', label: 'Retail' },
                    { value: 'Manufacturing', label: 'Manufacturing' },
                    { value: 'Consulting', label: 'Consulting' },
                    { value: 'Education', label: 'Education' },
                    { value: 'Real Estate', label: 'Real Estate' },
                    { value: 'Media', label: 'Media' },
                    { value: 'Other', label: 'Other' },
                  ]}
                />

                <Input
                  label="Website"
                  placeholder="https://example.com"
                  value={formData.website}
                  onChange={(e) => handleInputChange('website', e.target.value)}
                  error={errors.website}
                />
              </div>
            </div>
          </Card>

          {/* Contact Information */}
          <Card className="mb-6">
            <h2 className="text-xl font-bold text-gray-900 mb-6">Contact Information</h2>

            <div className="space-y-4">
              <Input
                label="Contact Person Name"
                placeholder="e.g., John Smith"
                value={formData.contact_name}
                onChange={(e) => handleInputChange('contact_name', e.target.value)}
                error={errors.contact_name}
                required
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  label="Contact Email"
                  type="email"
                  placeholder="john@example.com"
                  value={formData.contact_email}
                  onChange={(e) => handleInputChange('contact_email', e.target.value)}
                  error={errors.contact_email}
                  required
                />

                <Input
                  label="Contact Phone"
                  type="tel"
                  placeholder="+1 (555) 123-4567"
                  value={formData.contact_phone}
                  onChange={(e) => handleInputChange('contact_phone', e.target.value)}
                  error={errors.contact_phone}
                  required
                />
              </div>
            </div>
          </Card>

          {/* Address Information */}
          <Card className="mb-6">
            <h2 className="text-xl font-bold text-gray-900 mb-6">Address (Optional)</h2>

            <div className="space-y-4">
              <Input
                label="Street Address"
                placeholder="123 Main Street"
                value={formData.address}
                onChange={(e) => handleInputChange('address', e.target.value)}
              />

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Input
                  label="City"
                  placeholder="San Francisco"
                  value={formData.city}
                  onChange={(e) => handleInputChange('city', e.target.value)}
                />

                <Input
                  label="State/Province"
                  placeholder="CA"
                  value={formData.state}
                  onChange={(e) => handleInputChange('state', e.target.value)}
                />

                <Input
                  label="Zip/Postal Code"
                  placeholder="94105"
                  value={formData.zip_code}
                  onChange={(e) => handleInputChange('zip_code', e.target.value)}
                />
              </div>

              <Select
                label="Country"
                value={formData.country}
                onChange={(e) => handleInputChange('country', e.target.value)}
                options={[
                  { value: 'USA', label: 'United States' },
                  { value: 'Canada', label: 'Canada' },
                  { value: 'UK', label: 'United Kingdom' },
                  { value: 'Australia', label: 'Australia' },
                  { value: 'Germany', label: 'Germany' },
                  { value: 'France', label: 'France' },
                  { value: 'India', label: 'India' },
                  { value: 'Other', label: 'Other' },
                ]}
              />
            </div>
          </Card>

          {/* Notes */}
          <Card className="mb-6">
            <h2 className="text-xl font-bold text-gray-900 mb-6">Additional Notes (Optional)</h2>

            <Textarea
              label="Notes"
              placeholder="Add any additional information about this client..."
              value={formData.notes}
              onChange={(e) => handleInputChange('notes', e.target.value)}
              rows={4}
            />
          </Card>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={() => router.push('/clients')}
              disabled={isSubmitting}
            >
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>

            <Button
              type="button"
              onClick={handleSubmit}
              isLoading={isSubmitting}
              disabled={isSubmitting}
            >
              <Save className="w-4 h-4 mr-2" />
              Add Client
            </Button>
          </div>
        </form>
      </PageContainer>
    </>
  );
}