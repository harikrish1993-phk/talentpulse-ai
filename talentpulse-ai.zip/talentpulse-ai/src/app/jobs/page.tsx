import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Header from '@/components/layout/Header';
import PageContainer from '@/components/layout/PageContainer';
import { Button, Input, Select, EmptyState, Loading } from '@/components/ui';
import JobCard from '@/components/cards/JobCard';
import { Plus, Search, Filter, Grid3x3, List, LayoutGrid } from 'lucide-react';
import { Job, ViewMode } from '@/lib/types';

// Mock data for demonstration
const mockJobs: Job[] = [
  {
    id: '1',
    title: 'Senior Full Stack Developer',
    description: 'We are looking for an experienced Full Stack Developer to join our growing team. You will be responsible for developing and maintaining web applications using modern technologies.',
    requirements: ['5+ years experience', 'React expertise', 'Node.js proficiency'],
    skills_required: ['React', 'Node.js', 'TypeScript', 'PostgreSQL', 'AWS'],
    location: 'San Francisco, CA',
    employment_type: 'full-time',
    experience_level: 'senior',
    salary_min: 120000,
    salary_max: 180000,
    salary_currency: 'USD',
    status: 'open',
    client_id: '1',
    client: {
      id: '1',
      company_name: 'Tech Innovations Inc',
      industry: 'Technology',
      contact_name: 'John Smith',
      contact_email: 'john@techinnovations.com',
      contact_phone: '+1234567890',
      created_at: '2024-01-15T10:00:00Z',
      updated_at: '2024-01-15T10:00:00Z',
    },
    created_at: '2024-11-20T10:00:00Z',
    updated_at: '2024-11-20T10:00:00Z',
    submissions_count: 12,
    matches_count: 45,
  },
  {
    id: '2',
    title: 'Product Designer',
    description: 'Join our design team to create beautiful and intuitive user experiences. You will work closely with product managers and engineers to bring ideas to life.',
    requirements: ['3+ years experience', 'Figma expertise', 'User research skills'],
    skills_required: ['Figma', 'UI/UX Design', 'Prototyping', 'User Research'],
    location: 'New York, NY',
    employment_type: 'full-time',
    experience_level: 'mid',
    salary_min: 90000,
    salary_max: 130000,
    salary_currency: 'USD',
    status: 'open',
    client_id: '2',
    client: {
      id: '2',
      company_name: 'Design Studio Co',
      industry: 'Design',
      contact_name: 'Sarah Johnson',
      contact_email: 'sarah@designstudio.com',
      contact_phone: '+1234567891',
      created_at: '2024-01-10T10:00:00Z',
      updated_at: '2024-01-10T10:00:00Z',
    },
    created_at: '2024-11-25T14:30:00Z',
    updated_at: '2024-11-25T14:30:00Z',
    submissions_count: 8,
    matches_count: 32,
  },
  {
    id: '3',
    title: 'DevOps Engineer',
    description: 'We need a skilled DevOps Engineer to manage our infrastructure and deployment pipelines. Experience with Kubernetes and CI/CD is essential.',
    requirements: ['4+ years experience', 'Kubernetes expertise', 'CI/CD knowledge'],
    skills_required: ['Kubernetes', 'Docker', 'AWS', 'Terraform', 'Jenkins'],
    location: 'Austin, TX',
    employment_type: 'full-time',
    experience_level: 'senior',
    salary_min: 110000,
    salary_max: 160000,
    salary_currency: 'USD',
    status: 'open',
    client_id: '1',
    client: {
      id: '1',
      company_name: 'Tech Innovations Inc',
      industry: 'Technology',
      contact_name: 'John Smith',
      contact_email: 'john@techinnovations.com',
      contact_phone: '+1234567890',
      created_at: '2024-01-15T10:00:00Z',
      updated_at: '2024-01-15T10:00:00Z',
    },
    created_at: '2024-11-28T09:15:00Z',
    updated_at: '2024-11-28T09:15:00Z',
    submissions_count: 5,
    matches_count: 28,
  },
];

export default function JobsPage() {
  const router = useRouter();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [isLoading, setIsLoading] = useState(false);

  // Filter jobs based on search and filters
  const filteredJobs = mockJobs.filter((job) => {
    const matchesSearch =
      searchQuery === '' ||
      job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.client?.company_name.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === 'all' || job.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const handleCreateJob = () => {
    router.push('/jobs/new');
  };

  return (
    <>
      <Header
        title="Jobs"
        subtitle={`${filteredJobs.length} ${filteredJobs.length === 1 ? 'job' : 'jobs'} found`}
        actions={
          <Button leftIcon={<Plus className="w-4 h-4" />} onClick={handleCreateJob}>
            Create Job
          </Button>
        }
      />

      <PageContainer>
        {/* Filters and View Toggle */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          {/* Search */}
          <div className="flex-1">
            <Input
              type="search"
              placeholder="Search jobs by title, description, or client..."
              leftIcon={<Search className="w-4 h-4" />}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          {/* Status Filter */}
          <div className="w-full md:w-48">
            <Select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              options={[
                { value: 'all', label: 'All Status' },
                { value: 'draft', label: 'Draft' },
                { value: 'open', label: 'Open' },
                { value: 'closed', label: 'Closed' },
                { value: 'on_hold', label: 'On Hold' },
              ]}
            />
          </div>

          {/* View Toggle */}
          <div className="flex gap-2">
            <Button
              variant={viewMode === 'grid' ? 'primary' : 'outline'}
              size="md"
              onClick={() => setViewMode('grid')}
            >
              <Grid3x3 className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === 'list' ? 'primary' : 'outline'}
              size="md"
              onClick={() => setViewMode('list')}
            >
              <List className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Jobs List */}
        {isLoading ? (
          <Loading size="lg" text="Loading jobs..." />
        ) : filteredJobs.length === 0 ? (
          <EmptyState
            icon={<Briefcase className="w-16 h-16" />}
            title="No jobs found"
            description={
              searchQuery || statusFilter !== 'all'
                ? 'Try adjusting your search or filters'
                : 'Get started by creating your first job posting'
            }
            action={
              searchQuery || statusFilter !== 'all'
                ? undefined
                : {
                    label: 'Create Job',
                    onClick: handleCreateJob,
                    icon: <Plus className="w-4 h-4" />,
                  }
            }
          />
        ) : (
          <div
            className={
              viewMode === 'grid'
                ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'
                : 'space-y-4'
            }
          >
            {filteredJobs.map((job) => (
              <JobCard key={job.id} job={job} />
            ))}
          </div>
        )}
      </PageContainer>
    </>
  );
}