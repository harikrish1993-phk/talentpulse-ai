'use client';

import { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import Header from '@/components/layout/Header';
import PageContainer from '@/components/layout/PageContainer';
import { Button, Card, Badge, Alert, Loading, Modal } from '@/components/ui';
import {
  Edit,
  Trash2,
  MapPin,
  DollarSign,
  Briefcase,
  Calendar,
  Building2,
  Users,
  Send,
  GitCompare,
  CheckCircle,
  XCircle,
} from 'lucide-react';
import { Job } from '@/lib/types';
import { formatSalaryRange, formatRelativeDate, formatStatusLabel } from '@/lib/utils';

// Mock data
const mockJob: Job = {
  id: '1',
  title: 'Senior Full Stack Developer',
  description: 'We are looking for an experienced Full Stack Developer to join our growing team. You will be responsible for developing and maintaining web applications using modern technologies. This is an excellent opportunity to work on challenging projects and grow your career.\n\nYou will collaborate with cross-functional teams including designers, product managers, and other engineers to deliver high-quality software solutions. We value clean code, best practices, and continuous learning.',
  requirements: [
    '5+ years of professional software development experience',
    'Strong proficiency in React and Node.js',
    'Experience with TypeScript and modern JavaScript',
    'Solid understanding of RESTful APIs and microservices',
    'Experience with SQL and NoSQL databases',
    'Familiarity with cloud platforms (AWS, Azure, or GCP)',
    'Excellent problem-solving and communication skills',
  ],
  skills_required: ['React', 'Node.js', 'TypeScript', 'PostgreSQL', 'AWS', 'Docker', 'Git'],
  location: 'San Francisco, CA (Hybrid)',
  employment_type: 'full-time',
  experience_level: 'senior',
  salary_min: 120000,
  salary_max: 180000,
  salary_currency: 'USD',
  benefits: [
    'Health, dental, and vision insurance',
    '401(k) with company match',
    'Flexible work schedule',
    'Remote work options',
    'Professional development budget',
    'Unlimited PTO',
  ],
  status: 'open',
  client_id: '1',
  client: {
    id: '1',
    company_name: 'Tech Innovations Inc',
    industry: 'Technology',
    contact_name: 'John Smith',
    contact_email: 'john@techinnovations.com',
    contact_phone: '+1 (555) 123-4567',
    created_at: '2024-01-15T10:00:00Z',
    updated_at: '2024-01-15T10:00:00Z',
  },
  created_at: '2024-11-20T10:00:00Z',
  updated_at: '2024-11-28T15:30:00Z',
  submissions_count: 12,
  matches_count: 45,
};

export default function JobDetailPage() {
  const router = useRouter();
  const params = useParams();
  const jobId = params.id as string;

  const [job, setJob] = useState<Job | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    // TODO: Fetch job from API
    setTimeout(() => {
      setJob(mockJob);
      setIsLoading(false);
    }, 500);
  }, [jobId]);

  const handleEdit = () => {
    router.push(`/jobs/${jobId}/edit`);
  };

  const handleDelete = async () => {
    setIsDeleting(true);
    try {
      // TODO: API call to delete job
      await new Promise((resolve) => setTimeout(resolve, 1000));
      router.push('/jobs');
    } catch (error) {
      console.error('Failed to delete job:', error);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleMatchCandidates = () => {
    router.push(`/match?job=${jobId}`);
  };

  const handleViewSubmissions = () => {
    router.push(`/submissions?job=${jobId}`);
  };

  if (isLoading) {
    return (
      <>
        <Header title="Job Details" />
        <PageContainer>
          <Loading size="lg" text="Loading job details..." />
        </PageContainer>
      </>
    );
  }

  if (!job) {
    return (
      <>
        <Header title="Job Not Found" />
        <PageContainer>
          <Alert variant="danger">Job not found</Alert>
        </PageContainer>
      </>
    );
  }

  return (
    <>
      <Header
        title={job.title}
        subtitle={job.client?.company_name}
        actions={
          <div className="flex gap-3">
            <Button variant="outline" leftIcon={<GitCompare className="w-4 h-4" />} onClick={handleMatchCandidates}>
              Match Candidates
            </Button>
            <Button variant="outline" leftIcon={<Edit className="w-4 h-4" />} onClick={handleEdit}>
              Edit
            </Button>
            <Button variant="danger" leftIcon={<Trash2 className="w-4 h-4" />} onClick={() => setShowDeleteModal(true)}>
              Delete
            </Button>
          </div>
        }
      />

      <PageContainer maxWidth="xl">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Overview */}
            <Card>
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-2">{job.title}</h2>
                  <div className="flex items-center gap-4 text-gray-600">
                    <div className="flex items-center">
                      <Building2 className="w-4 h-4 mr-1" />
                      {job.client?.company_name}
                    </div>
                    <div className="flex items-center">
                      <MapPin className="w-4 h-4 mr-1" />
                      {job.location}
                    </div>
                  </div>
                </div>
                <Badge
                  variant={
                    job.status === 'open'
                      ? 'success'
                      : job.status === 'closed'
                      ? 'danger'
                      : 'warning'
                  }
                  size="lg"
                >
                  {formatStatusLabel(job.status)}
                </Badge>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Employment Type</p>
                  <p className="font-semibold text-gray-900 capitalize">
                    {job.employment_type.replace('-', ' ')}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Experience Level</p>
                  <p className="font-semibold text-gray-900 capitalize">{job.experience_level}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Salary Range</p>
                  <p className="font-semibold text-gray-900">
                    {formatSalaryRange(job.salary_min, job.salary_max, job.salary_currency)}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Posted</p>
                  <p className="font-semibold text-gray-900">{formatRelativeDate(job.created_at)}</p>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Description</h3>
                <div className="text-gray-700 whitespace-pre-line leading-relaxed">
                  {job.description}
                </div>
              </div>
            </Card>

            {/* Requirements */}
            <Card>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Requirements</h3>
              <ul className="space-y-2">
                {job.requirements.map((requirement, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-success-500 mr-3 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">{requirement}</span>
                  </li>
                ))}
              </ul>
            </Card>

            {/* Skills Required */}
            <Card>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Skills Required</h3>
              <div className="flex flex-wrap gap-2">
                {job.skills_required.map((skill, index) => (
                  <Badge key={index} variant="primary" size="lg">
                    {skill}
                  </Badge>
                ))}
              </div>
            </Card>

            {/* Benefits */}
            {job.benefits && job.benefits.length > 0 && (
              <Card>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Benefits</h3>
                <ul className="space-y-2">
                  {job.benefits.map((benefit, index) => (
                    <li key={index} className="flex items-start">
                      <CheckCircle className="w-5 h-5 text-primary-500 mr-3 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">{benefit}</span>
                    </li>
                  ))}
                </ul>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
              <div className="space-y-2">
                <Button
                  variant="primary"
                  className="w-full justify-start"
                  leftIcon={<GitCompare className="w-4 h-4" />}
                  onClick={handleMatchCandidates}
                >
                  Match Candidates
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  leftIcon={<Users className="w-4 h-4" />}
                  onClick={handleViewSubmissions}
                >
                  View Submissions ({job.submissions_count})
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start"
                  leftIcon={<Edit className="w-4 h-4" />}
                  onClick={handleEdit}
                >
                  Edit Job
                </Button>
              </div>
            </Card>

            {/* Statistics */}
            <Card>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Statistics</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center text-gray-600">
                    <Users className="w-5 h-5 mr-2" />
                    <span>Submissions</span>
                  </div>
                  <span className="text-2xl font-bold text-gray-900">{job.submissions_count}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center text-gray-600">
                    <GitCompare className="w-5 h-5 mr-2" />
                    <span>Matches Found</span>
                  </div>
                  <span className="text-2xl font-bold text-gray-900">{job.matches_count}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center text-gray-600">
                    <Calendar className="w-5 h-5 mr-2" />
                    <span>Days Active</span>
                  </div>
                  <span className="text-2xl font-bold text-gray-900">
                    {Math.floor((Date.now() - new Date(job.created_at).getTime()) / (1000 * 60 * 60 * 24))}
                  </span>
                </div>
              </div>
            </Card>

            {/* Client Information */}
            {job.client && (
              <Card>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Client Information</h3>
                <div className="space-y-3">
                  <div>
                    <p className="text-sm text-gray-600">Company</p>
                    <p className="font-semibold text-gray-900">{job.client.company_name}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Industry</p>
                    <p className="font-semibold text-gray-900">{job.client.industry}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Contact Person</p>
                    <p className="font-semibold text-gray-900">{job.client.contact_name}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Email</p>
                    <p className="font-semibold text-gray-900">{job.client.contact_email}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Phone</p>
                    <p className="font-semibold text-gray-900">{job.client.contact_phone}</p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full mt-4"
                    onClick={() => router.push(`/clients/${job.client_id}`)}
                  >
                    View Client Profile
                  </Button>
                </div>
              </Card>
            )}
          </div>
        </div>
      </PageContainer>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={showDeleteModal}
        onClose={() => setShowDeleteModal(false)}
        title="Delete Job"
        description="Are you sure you want to delete this job? This action cannot be undone."
        footer={
          <>
            <Button variant="outline" onClick={() => setShowDeleteModal(false)} disabled={isDeleting}>
              Cancel
            </Button>
            <Button variant="danger" onClick={handleDelete} isLoading={isDeleting}>
              Delete Job
            </Button>
          </>
        }
      >
        <Alert variant="warning">
          <p className="font-semibold mb-2">This will permanently delete:</p>
          <ul className="list-disc list-inside space-y-1 text-sm">
            <li>The job posting: {job.title}</li>
            <li>All associated matches ({job.matches_count})</li>
            <li>All submission records ({job.submissions_count})</li>
          </ul>
        </Alert>
      </Modal>
    </>
  );
}