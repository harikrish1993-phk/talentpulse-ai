'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Header from '@/components/layout/Header';
import PageContainer from '@/components/layout/PageContainer';
import { Button, Input, Select, Textarea, Card, Alert } from '@/components/ui';
import { Save, X, Plus, Trash2 } from 'lucide-react';
import { JobFormData, EmploymentType, ExperienceLevel, JobStatus } from '@/lib/types';

export default function NewJobPage() {
  const router = useRouter();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const [formData, setFormData] = useState<JobFormData>({
    title: '',
    client_id: '',
    description: '',
    requirements: [''],
    skills_required: [''],
    location: '',
    employment_type: 'full-time',
    experience_level: 'mid',
    salary_min: undefined,
    salary_max: undefined,
    salary_currency: 'USD',
    benefits: [''],
    status: 'draft',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleInputChange = (field: keyof JobFormData, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    // Clear error for this field
    if (errors[field]) {
      setErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  const handleArrayFieldChange = (
    field: 'requirements' | 'skills_required' | 'benefits',
    index: number,
    value: string
  ) => {
    const newArray = [...formData[field]];
    newArray[index] = value;
    handleInputChange(field, newArray);
  };

  const handleAddArrayField = (field: 'requirements' | 'skills_required' | 'benefits') => {
    handleInputChange(field, [...formData[field], '']);
  };

  const handleRemoveArrayField = (
    field: 'requirements' | 'skills_required' | 'benefits',
    index: number
  ) => {
    const newArray = formData[field].filter((_, i) => i !== index);
    handleInputChange(field, newArray.length > 0 ? newArray : ['']);
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.title.trim()) {
      newErrors.title = 'Job title is required';
    }

    if (!formData.client_id) {
      newErrors.client_id = 'Client is required';
    }

    if (!formData.description.trim()) {
      newErrors.description = 'Job description is required';
    }

    if (!formData.location.trim()) {
      newErrors.location = 'Location is required';
    }

    const hasValidRequirements = formData.requirements.some((req) => req.trim() !== '');
    if (!hasValidRequirements) {
      newErrors.requirements = 'At least one requirement is needed';
    }

    const hasValidSkills = formData.skills_required.some((skill) => skill.trim() !== '');
    if (!hasValidSkills) {
      newErrors.skills_required = 'At least one skill is required';
    }

    if (formData.salary_min && formData.salary_max && formData.salary_min > formData.salary_max) {
      newErrors.salary_max = 'Maximum salary must be greater than minimum';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (status: JobStatus) => {
    setError(null);
    setSuccess(false);

    if (!validateForm()) {
      setError('Please fix the errors in the form');
      return;
    }

    setIsSubmitting(true);

    try {
      // Filter out empty array values
      const cleanedData = {
        ...formData,
        status,
        requirements: formData.requirements.filter((req) => req.trim() !== ''),
        skills_required: formData.skills_required.filter((skill) => skill.trim() !== ''),
        benefits: formData.benefits.filter((benefit) => benefit.trim() !== ''),
      };

      // TODO: API call to create job
      console.log('Creating job:', cleanedData);

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000));

      setSuccess(true);
      setTimeout(() => {
        router.push('/jobs');
      }, 1500);
    } catch (err) {
      setError('Failed to create job. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <Header
        title="Create New Job"
        subtitle="Fill in the details to create a new job posting"
      />

      <PageContainer maxWidth="lg">
        {error && (
          <Alert variant="danger" className="mb-6" onClose={() => setError(null)}>
            {error}
          </Alert>
        )}

        {success && (
          <Alert variant="success" className="mb-6">
            Job created successfully! Redirecting...
          </Alert>
        )}

        <form onSubmit={(e) => e.preventDefault()}>
          {/* Basic Information */}
          <Card className="mb-6">
            <h2 className="text-xl font-bold text-gray-900 mb-6">Basic Information</h2>

            <div className="space-y-4">
              <Input
                label="Job Title"
                placeholder="e.g., Senior Full Stack Developer"
                value={formData.title}
                onChange={(e) => handleInputChange('title', e.target.value)}
                error={errors.title}
                required
              />

              <Select
                label="Client"
                placeholder="Select a client"
                value={formData.client_id}
                onChange={(e) => handleInputChange('client_id', e.target.value)}
                error={errors.client_id}
                required
                options={[
                  { value: '1', label: 'Tech Innovations Inc' },
                  { value: '2', label: 'Design Studio Co' },
                  { value: '3', label: 'Enterprise Solutions Ltd' },
                ]}
              />

              <Textarea
                label="Job Description"
                placeholder="Describe the role, responsibilities, and what makes this opportunity exciting..."
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                error={errors.description}
                rows={6}
                required
              />

              <Input
                label="Location"
                placeholder="e.g., San Francisco, CA or Remote"
                value={formData.location}
                onChange={(e) => handleInputChange('location', e.target.value)}
                error={errors.location}
                required
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Select
                  label="Employment Type"
                  value={formData.employment_type}
                  onChange={(e) => handleInputChange('employment_type', e.target.value as EmploymentType)}
                  required
                  options={[
                    { value: 'full-time', label: 'Full-time' },
                    { value: 'part-time', label: 'Part-time' },
                    { value: 'contract', label: 'Contract' },
                    { value: 'temporary', label: 'Temporary' },
                    { value: 'internship', label: 'Internship' },
                  ]}
                />

                <Select
                  label="Experience Level"
                  value={formData.experience_level}
                  onChange={(e) => handleInputChange('experience_level', e.target.value as ExperienceLevel)}
                  required
                  options={[
                    { value: 'entry', label: 'Entry Level' },
                    { value: 'mid', label: 'Mid Level' },
                    { value: 'senior', label: 'Senior Level' },
                    { value: 'lead', label: 'Lead' },
                    { value: 'executive', label: 'Executive' },
                  ]}
                />
              </div>
            </div>
          </Card>

          {/* Requirements */}
          <Card className="mb-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Requirements</h2>
              <Button
                type="button"
                variant="outline"
                size="sm"
                leftIcon={<Plus className="w-4 h-4" />}
                onClick={() => handleAddArrayField('requirements')}
              >
                Add Requirement
              </Button>
            </div>

            <div className="space-y-3">
              {formData.requirements.map((requirement, index) => (
                <div key={index} className="flex gap-2">
                  <Input
                    placeholder={`Requirement ${index + 1}`}
                    value={requirement}
                    onChange={(e) => handleArrayFieldChange('requirements', index, e.target.value)}
                  />
                  {formData.requirements.length > 1 && (
                    <Button
                      type="button"
                      variant="outline"
                      size="md"
                      onClick={() => handleRemoveArrayField('requirements', index)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              ))}
              {errors.requirements && (
                <p className="text-sm text-danger-600">{errors.requirements}</p>
              )}
            </div>
          </Card>

          {/* Skills Required */}
          <Card className="mb-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Skills Required</h2>
              <Button
                type="button"
                variant="outline"
                size="sm"
                leftIcon={<Plus className="w-4 h-4" />}
                onClick={() => handleAddArrayField('skills_required')}
              >
                Add Skill
              </Button>
            </div>

            <div className="space-y-3">
              {formData.skills_required.map((skill, index) => (
                <div key={index} className="flex gap-2">
                  <Input
                    placeholder={`Skill ${index + 1}`}
                    value={skill}
                    onChange={(e) => handleArrayFieldChange('skills_required', index, e.target.value)}
                  />
                  {formData.skills_required.length > 1 && (
                    <Button
                      type="button"
                      variant="outline"
                      size="md"
                      onClick={() => handleRemoveArrayField('skills_required', index)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              ))}
              {errors.skills_required && (
                <p className="text-sm text-danger-600">{errors.skills_required}</p>
              )}
            </div>
          </Card>

          {/* Compensation */}
          <Card className="mb-6">
            <h2 className="text-xl font-bold text-gray-900 mb-6">Compensation</h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Input
                label="Minimum Salary"
                type="number"
                placeholder="e.g., 100000"
                value={formData.salary_min || ''}
                onChange={(e) => handleInputChange('salary_min', e.target.value ? Number(e.target.value) : undefined)}
              />

              <Input
                label="Maximum Salary"
                type="number"
                placeholder="e.g., 150000"
                value={formData.salary_max || ''}
                onChange={(e) => handleInputChange('salary_max', e.target.value ? Number(e.target.value) : undefined)}
                error={errors.salary_max}
              />

              <Select
                label="Currency"
                value={formData.salary_currency || 'USD'}
                onChange={(e) => handleInputChange('salary_currency', e.target.value)}
                options={[
                  { value: 'USD', label: 'USD' },
                  { value: 'EUR', label: 'EUR' },
                  { value: 'GBP', label: 'GBP' },
                  { value: 'INR', label: 'INR' },
                ]}
              />
            </div>
          </Card>

          {/* Benefits */}
          <Card className="mb-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Benefits (Optional)</h2>
              <Button
                type="button"
                variant="outline"
                size="sm"
                leftIcon={<Plus className="w-4 h-4" />}
                onClick={() => handleAddArrayField('benefits')}
              >
                Add Benefit
              </Button>
            </div>

            <div className="space-y-3">
              {formData.benefits.map((benefit, index) => (
                <div key={index} className="flex gap-2">
                  <Input
                    placeholder={`Benefit ${index + 1}`}
                    value={benefit}
                    onChange={(e) => handleArrayFieldChange('benefits', index, e.target.value)}
                  />
                  {formData.benefits.length > 1 && (
                    <Button
                      type="button"
                      variant="outline"
                      size="md"
                      onClick={() => handleRemoveArrayField('benefits', index)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </Card>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={() => router.push('/jobs')}
              disabled={isSubmitting}
            >
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>

            <Button
              type="button"
              variant="secondary"
              onClick={() => handleSubmit('draft')}
              isLoading={isSubmitting}
              disabled={isSubmitting}
            >
              <Save className="w-4 h-4 mr-2" />
              Save as Draft
            </Button>

            <Button
              type="button"
              onClick={() => handleSubmit('open')}
              isLoading={isSubmitting}
              disabled={isSubmitting}
            >
              <Save className="w-4 h-4 mr-2" />
              Publish Job
            </Button>
          </div>
        </form>
      </PageContainer>
    </>
  );
}