'use client';

import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Header from '@/components/layout/Header';
import PageContainer from '@/components/layout/PageContainer';
import { Button, Input, Select, EmptyState, Loading, Card, Badge } from '@/components/ui';
import SubmissionCard from '@/components/cards/SubmissionCard';
import { Plus, Search, Filter, Grid3x3, List, Send, TrendingUp, Users, CheckCircle } from 'lucide-react';
import { Submission } from '@/lib/types';

// Mock data
const mockSubmissions: Submission[] = [
  {
    id: '1',
    job_id: '1',
    candidate_id: '1',
    job: {
      id: '1',
      title: 'Senior Full Stack Developer',
      description: 'Looking for experienced developer',
      requirements: [],
      skills_required: ['React', 'Node.js'],
      location: 'San Francisco, CA',
      employment_type: 'full-time',
      experience_level: 'senior',
      status: 'open',
      client_id: '1',
      client: {
        id: '1',
        company_name: 'Tech Innovations Inc',
        industry: 'Technology',
        contact_name: 'John Smith',
        contact_email: 'john@tech.com',
        contact_phone: '+1234567890',
        created_at: '2024-01-01T00:00:00Z',
        updated_at: '2024-01-01T00:00:00Z',
      },
      created_at: '2024-11-20T10:00:00Z',
      updated_at: '2024-11-20T10:00:00Z',
    },
    candidate: {
      id: '1',
      name: 'Alice Johnson',
      email: 'alice@email.com',
      title: 'Senior Full Stack Developer',
      skills: ['React', 'Node.js', 'TypeScript'],
      years_of_experience: 8,
      experience: [],
      education: [],
      parse_confidence: 95,
      source: 'upload',
      status: 'active',
      created_at: '2024-11-15T10:00:00Z',
      updated_at: '2024-11-15T10:00:00Z',
    },
    status: 'interview_scheduled',
    match_score: 92,
    submitted_at: '2024-11-25T10:00:00Z',
    updated_at: '2024-11-28T14:30:00Z',
    notes: 'Great candidate, interview scheduled for next week',
  },
  {
    id: '2',
    job_id: '2',
    candidate_id: '3',
    job: {
      id: '2',
      title: 'Product Designer',
      description: 'Creative designer needed',
      requirements: [],
      skills_required: ['Figma', 'UI/UX'],
      location: 'New York, NY',
      employment_type: 'full-time',
      experience_level: 'mid',
      status: 'open',
      client_id: '2',
      client: {
        id: '2',
        company_name: 'Design Studio Co',
        industry: 'Design',
        contact_name: 'Sarah Johnson',
        contact_email: 'sarah@design.com',
        contact_phone: '+1234567891',
        created_at: '2024-01-10T00:00:00Z',
        updated_at: '2024-01-10T00:00:00Z',
      },
      created_at: '2024-11-25T14:30:00Z',
      updated_at: '2024-11-25T14:30:00Z',
    },
    candidate: {
      id: '3',
      name: 'Carol Chen',
      email: 'carol@email.com',
      title: 'Product Designer',
      skills: ['Figma', 'UI/UX Design'],
      years_of_experience: 5,
      experience: [],
      education: [],
      parse_confidence: 88,
      source: 'referral',
      status: 'active',
      created_at: '2024-11-20T09:15:00Z',
      updated_at: '2024-11-20T09:15:00Z',
    },
    status: 'client_reviewing',
    match_score: 85,
    submitted_at: '2024-11-27T09:00:00Z',
    updated_at: '2024-11-27T09:00:00Z',
  },
];

export default function SubmissionsPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const jobFilter = searchParams.get('job');
  const candidateFilter = searchParams.get('candidate');

  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [isLoading, setIsLoading] = useState(false);

  // Filter submissions
  const filteredSubmissions = mockSubmissions.filter((submission) => {
    const matchesSearch =
      searchQuery === '' ||
      submission.candidate.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      submission.job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      submission.job.client?.company_name.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === 'all' || submission.status === statusFilter;
    const matchesJob = !jobFilter || submission.job_id === jobFilter;
    const matchesCandidate = !candidateFilter || submission.candidate_id === candidateFilter;

    return matchesSearch && matchesStatus && matchesJob && matchesCandidate;
  });

  // Calculate statistics
  const totalSubmissions = filteredSubmissions.length;
  const activeSubmissions = filteredSubmissions.filter(
    (s) => !['offer_accepted', 'offer_rejected', 'rejected', 'withdrawn'].includes(s.status)
  ).length;
  const successfulSubmissions = filteredSubmissions.filter(
    (s) => s.status === 'offer_accepted'
  ).length;

  const handleCreateSubmission = () => {
    router.push('/submissions/new');
  };

  return (
    <>
      <Header
        title="Submissions"
        subtitle={`${filteredSubmissions.length} ${filteredSubmissions.length === 1 ? 'submission' : 'submissions'} found`}
        actions={
          <Button leftIcon={<Plus className="w-4 h-4" />} onClick={handleCreateSubmission}>
            New Submission
          </Button>
        }
      />

      <PageContainer>
        {/* Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Total Submissions</p>
                <p className="text-3xl font-bold text-gray-900">{totalSubmissions}</p>
              </div>
              <Send className="w-10 h-10 text-primary-500" />
            </div>
          </Card>

          <Card>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Active</p>
                <p className="text-3xl font-bold text-gray-900">{activeSubmissions}</p>
              </div>
              <TrendingUp className="w-10 h-10 text-yellow-500" />
            </div>
          </Card>

          <Card>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Successful</p>
                <p className="text-3xl font-bold text-gray-900">{successfulSubmissions}</p>
              </div>
              <CheckCircle className="w-10 h-10 text-success-500" />
            </div>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1">
            <Input
              type="search"
              placeholder="Search by candidate, job, or client..."
              leftIcon={<Search className="w-4 h-4" />}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <div className="w-full md:w-64">
            <Select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              options={[
                { value: 'all', label: 'All Status' },
                { value: 'submitted', label: 'Submitted' },
                { value: 'client_reviewing', label: 'Client Reviewing' },
                { value: 'interview_scheduled', label: 'Interview Scheduled' },
                { value: 'interview_completed', label: 'Interview Completed' },
                { value: 'offer_extended', label: 'Offer Extended' },
                { value: 'offer_accepted', label: 'Offer Accepted' },
                { value: 'offer_rejected', label: 'Offer Rejected' },
                { value: 'rejected', label: 'Rejected' },
                { value: 'withdrawn', label: 'Withdrawn' },
              ]}
            />
          </div>

          <div className="flex gap-2">
            <Button
              variant={viewMode === 'grid' ? 'primary' : 'outline'}
              size="md"
              onClick={() => setViewMode('grid')}
            >
              <Grid3x3 className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === 'list' ? 'primary' : 'outline'}
              size="md"
              onClick={() => setViewMode('list')}
            >
              <List className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Submissions List */}
        {isLoading ? (
          <Loading size="lg" text="Loading submissions..." />
        ) : filteredSubmissions.length === 0 ? (
          <EmptyState
            icon={<Send className="w-16 h-16" />}
            title="No submissions found"
            description={
              searchQuery || statusFilter !== 'all'
                ? 'Try adjusting your search or filters'
                : 'Get started by submitting a candidate to a job'
            }
            action={
              searchQuery || statusFilter !== 'all'
                ? undefined
                : {
                    label: 'New Submission',
                    onClick: handleCreateSubmission,
                    icon: <Plus className="w-4 h-4" />,
                  }
            }
          />
        ) : (
          <div
            className={
              viewMode === 'grid'
                ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'
                : 'space-y-4'
            }
          >
            {filteredSubmissions.map((submission) => (
              <SubmissionCard key={submission.id} submission={submission} />
            ))}
          </div>
        )}
      </PageContainer>
    </>
  );
}