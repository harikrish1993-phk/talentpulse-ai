'use client';
import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { 
  FileText, BarChart3, Users, Briefcase, DollarSign, 
  Download, Filter, Calendar, Search, ChevronDown, ChevronUp,
  Building2, TrendingUp, Award, Clock, Mail
} from 'lucide-react';
import Header from '@/components/layout/Header';
import PageContainer from '@/components/layout/PageContainer';
import { Card, Select, Button, Input, DateRangePicker, Badge, Alert, Modal } from '@/components/ui';
import { formatCurrency, formatDate } from '@/lib/utils';

// Report types available
const REPORT_TYPES = [
  { value: 'placements', label: 'Placement Report' },
  { value: 'revenue', label: 'Revenue Report' },
  { value: 'recruiter_performance', label: 'Recruiter Performance' },
  { value: 'client_report', label: 'Client Report' },
  { value: 'pipeline', label: 'Pipeline Report' },
  { value: 'time_to_fill', label: 'Time to Fill Report' },
  { value: 'conversion', label: 'Conversion Rate Report' }
];

// Metrics for each report
const REPORT_METRICS = {
  placements: ['placed_candidates', 'placement_rate', 'avg_placement_time', 'revenue_generated'],
  revenue: ['total_revenue', 'revenue_by_client', 'revenue_by_job_type', 'commission_earned'],
  recruiter_performance: ['submissions', 'interviews', 'placements', 'avg_time_to_fill', 'revenue_generated'],
  client_report: ['jobs_filled', 'candidates_submitted', 'placement_success_rate', 'revenue_generated', 'avg_time_to_fill'],
  pipeline: ['candidates_at_stage', 'avg_time_per_stage', 'drop_off_rate', 'conversion_rate'],
  time_to_fill: ['avg_days_to_fill', 'time_by_job_type', 'time_by_experience_level', 'fastest_placements'],
  conversion: ['submission_to_interview', 'interview_to_offer', 'offer_to_placement', 'overall_conversion']
};

export default function ReportsPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const initialReportType = searchParams.get('type') || 'placements';
  
  const [selectedReport, setSelectedReport] = useState(initialReportType);
  const [dateRange, setDateRange] = useState({
    from: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // 30 days ago
    to: new Date()
  });
  const [clientFilter, setClientFilter] = useState('all');
  const [recruiterFilter, setRecruiterFilter] = useState('all');
  const [jobTypeFilter, setJobTypeFilter] = useState('all');
  const [reportData, setReportData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [clients, setClients] = useState([]);
  const [recruiters, setRecruiters] = useState([]);
  const [jobTypes, setJobTypes] = useState([]);
  
  useEffect(() => {
    // Load filter options
    loadFilterOptions();
    
    // Load report if a type is selected
    if (selectedReport) {
      loadReportData();
    }
  }, [selectedReport, dateRange]);

  async function loadFilterOptions() {
    try {
      // These would be API calls in production
      setClients([
        { id: 'all', name: 'All Clients' },
        { id: '1', name: 'TechCorp Solutions' },
        { id: '2', name: 'DataFlow Inc' },
        { id: '3', name: 'GlobalTech' },
        { id: '4', name: 'StartupX' }
      ]);
      
      setRecruiters([
        { id: 'all', name: 'All Recruiters' },
        { id: '1', name: 'Sarah Johnson' },
        { id: '2', name: 'Tom Wilson' },
        { id: '3', name: 'Lisa Chen' },
        { id: '4', name: 'Mike Thompson' }
      ]);
      
      setJobTypes([
        { id: 'all', name: 'All Job Types' },
        { id: 'tech', name: 'Technology' },
        { id: 'finance', name: 'Finance' },
        { id: 'healthcare', name: 'Healthcare' },
        { id: 'marketing', name: 'Marketing' }
      ]);
    } catch (error) {
      console.error('Error loading filter options:', error);
    }
  }

  async function loadReportData() {
    setLoading(true);
    setError(null);
    
    try {
      // In production, this would be an API call with filters
      // For now, we'll simulate data based on report type
      
      const reportConfig = REPORT_TYPES.find(r => r.value === selectedReport);
      let data;
      
      switch(selectedReport) {
        case 'placements':
          data = generatePlacementsReport();
          break;
        case 'revenue':
          data = generateRevenueReport();
          break;
        case 'recruiter_performance':
          data = generateRecruiterPerformanceReport();
          break;
        case 'client_report':
          data = generateClientReport();
          break;
        case 'pipeline':
          data = generatePipelineReport();
          break;
        case 'time_to_fill':
          data = generateTimeToFillReport();
          break;
        case 'conversion':
          data = generateConversionReport();
          break;
        default:
          data = generatePlacementsReport();
      }
      
      setReportData(data);
    } catch (error) {
      console.error('Error loading report data:', error);
      setError('Failed to load report data. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  function generatePlacementsReport() {
    return {
      title: 'Placement Report',
      description: `Placements from ${formatDate(dateRange.from)} to ${formatDate(dateRange.to)}`,
      summary: {
        totalPlacements: 23,
        totalRevenue: 125000,
        avgTimeToFill: 21,
        placementRate: 68
      },
      chartData: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [
          {
            label: 'Placements',
            data: [15, 18, 22, 19, 23, 25],
            backgroundColor: 'rgba(59, 130, 246, 0.5)',
            borderColor: '#3b82f6',
            borderWidth: 1
          }
        ]
      },
      details: [
        { id: '1', candidate: 'John Doe', job: 'Senior Java Developer', client: 'TechCorp Solutions', placementDate: '2024-06-15', rate: '$65/hr', revenue: 32500 },
        { id: '2', candidate: 'Jane Smith', job: 'DevOps Engineer', client: 'DataFlow Inc', placementDate: '2024-06-10', rate: '$70/hr', revenue: 28000 },
        { id: '3', candidate: 'Mike Chen', job: 'Data Scientist', client: 'GlobalTech', placementDate: '2024-06-05', rate: '$85/hr', revenue: 42500 },
        { id: '4', candidate: 'Sarah Wilson', job: 'Frontend Developer', client: 'StartupX', placementDate: '2024-06-02', rate: '$60/hr', revenue: 22000 }
      ],
      metrics: {
        byClient: [
          { client: 'TechCorp Solutions', placements: 8, revenue: 62000 },
          { client: 'DataFlow Inc', placements: 6, revenue: 28000 },
          { client: 'GlobalTech', placements: 5, revenue: 25000 },
          { client: 'StartupX', placements: 4, revenue: 10000 }
        ],
        byRole: [
          { role: 'Developer', placements: 12, revenue: 58000 },
          { role: 'Engineer', placements: 7, revenue: 45000 },
          { role: 'Manager', placements: 3, revenue: 18000 },
          { role: 'Designer', placements: 1, revenue: 4000 }
        ],
        byRecruiter: [
          { recruiter: 'Lisa Chen', placements: 8, revenue: 45000 },
          { recruiter: 'Sarah Johnson', placements: 6, revenue: 32000 },
          { recruiter: 'Tom Wilson', placements: 5, revenue: 28000 },
          { recruiter: 'Mike Thompson', placements: 4, revenue: 20000 }
        ]
      }
    };
  }

  function generateRevenueReport() {
    return {
      title: 'Revenue Report',
      description: `Revenue from ${formatDate(dateRange.from)} to ${formatDate(dateRange.to)}`,
      summary: {
        totalRevenue: 125000,
        commissionEarned: 37500,
        avgRevenuePerPlacement: 5435,
        projectedMonthly: 150000
      },
      chartData: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [
          {
            label: 'Revenue',
            data: [95000, 110000, 105000, 120000, 125000, 150000],
            backgroundColor: 'rgba(16, 185, 129, 0.5)',
            borderColor: '#10b981',
            borderWidth: 1
          }
        ]
      },
      details: [
        { id: '1', client: 'TechCorp Solutions', job: 'Senior Java Developer', revenue: 62000, commission: 18600, date: '2024-06-15' },
        { id: '2', client: 'DataFlow Inc', job: 'DevOps Engineer', revenue: 28000, commission: 8400, date: '2024-06-10' },
        { id: '3', client: 'GlobalTech', job: 'Data Scientist', revenue: 25000, commission: 7500, date: '2024-06-05' },
        { id: '4', client: 'StartupX', job: 'Frontend Developer', revenue: 10000, commission: 3000, date: '2024-06-02' }
      ],
      revenueBreakdown: {
        byClient: [
          { client: 'TechCorp Solutions', revenue: 62000, percentage: 50 },
          { client: 'DataFlow Inc', revenue: 28000, percentage: 22 },
          { client: 'GlobalTech', revenue: 25000, percentage: 20 },
          { client: 'StartupX', revenue: 10000, percentage: 8 }
        ],
        byIndustry: [
          { industry: 'Technology', revenue: 90000, percentage: 72 },
          { industry: 'Finance', revenue: 20000, percentage: 16 },
          { industry: 'Healthcare', revenue: 15000, percentage: 12 }
        ],
        byJobType: [
          { type: 'Contract', revenue: 85000, percentage: 68 },
          { type: 'Permanent', revenue: 40000, percentage: 32 }
        ]
      }
    };
  }

  // Similar functions for other report types: generateRecruiterPerformanceReport, 
  // generateClientReport, generatePipelineReport, generateTimeToFillReport, generateConversionReport

  function generateRecruiterPerformanceReport() {
    return {
      title: 'Recruiter Performance Report',
      description: `Performance metrics from ${formatDate(dateRange.from)} to ${formatDate(dateRange.to)}`,
      summary: {
        totalSubmissions: 45,
        totalPlacements: 23,
        avgTimeToFill: 21,
        overallConversionRate: 51
      },
      chartData: {
        labels: ['Lisa Chen', 'Sarah Johnson', 'Tom Wilson', 'Mike Thompson'],
        datasets: [
          {
            label: 'Placements',
            data: [8, 6, 5, 4],
            backgroundColor: ['#10b981', '#3b82f6', '#8b5cf6', '#f59e0b']
          }
        ]
      },
      details: [
        { id: '1', recruiter: 'Lisa Chen', submissions: 15, interviews: 10, placements: 8, revenue: 45000, avgTimeToFill: 18 },
        { id: '2', recruiter: 'Sarah Johnson', submissions: 12, interviews: 8, placements: 6, revenue: 32000, avgTimeToFill: 20 },
        { id: '3', recruiter: 'Tom Wilson', submissions: 10, interviews: 6, placements: 5, revenue: 28000, avgTimeToFill: 22 },
        { id: '4', recruiter: 'Mike Thompson', submissions: 8, interviews: 5, placements: 4, revenue: 20000, avgTimeToFill: 24 }
      ],
      metrics: {
        byRecruiter: [
          { recruiter: 'Lisa Chen', submissions: 15, placements: 8, conversionRate: 53, avgTimeToFill: 18 },
          { recruiter: 'Sarah Johnson', submissions: 12, placements: 6, conversionRate: 50, avgTimeToFill: 20 },
          { recruiter: 'Tom Wilson', submissions: 10, placements: 5, conversionRate: 50, avgTimeToFill: 22 },
          { recruiter: 'Mike Thompson', submissions: 8, placements: 4, conversionRate: 50, avgTimeToFill: 24 }
        ],
        topPerformers: [
          { metric: 'Most Placements', recruiter: 'Lisa Chen', value: '8 placements' },
          { metric: 'Fastest Time to Fill', recruiter: 'Lisa Chen', value: '18 days' },
          { metric: 'Highest Conversion', recruiter: 'Lisa Chen', value: '53%' },
          { metric: 'Highest Revenue', recruiter: 'Lisa Chen', value: '$45,000' }
        ]
      }
    };
  }

  function exportReport(format) {
    if (!reportData) return;
    
    if (format === 'pdf') {
      // In production, this would generate a PDF
      alert('PDF export would be generated here');
    } else if (format === 'csv') {
      // In production, this would generate a CSV
      alert('CSV export would be generated here');
    } else if (format === 'email') {
      setShowModal(true);
    }
  }

  return (
    <>
      <Header
        title="Reports"
        subtitle="Generate and view performance reports"
      />
      <PageContainer maxWidth="xl">
        {error && (
          <Alert variant="danger" className="mb-6">
            {error}
          </Alert>
        )}

        {/* Report Configuration */}
        <Card className="mb-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {/* Report Type */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Report Type
              </label>
              <Select
                value={selectedReport}
                onChange={(e) => setSelectedReport(e.target.value)}
                options={REPORT_TYPES}
              />
            </div>

            {/* Date Range */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Date Range
              </label>
              <DateRangePicker
                value={dateRange}
                onChange={setDateRange}
                presets={[
                  { label: 'Today', value: { from: new Date(), to: new Date() } },
                  { label: 'Last 7 Days', value: { from: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), to: new Date() } },
                  { label: 'Last 30 Days', value: { from: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), to: new Date() } },
                  { label: 'This Month', value: { from: new Date(new Date().getFullYear(), new Date().getMonth(), 1), to: new Date() } },
                  { label: 'Last Month', value: { from: new Date(new Date().getFullYear(), new Date().getMonth() - 1, 1), to: new Date(new Date().getFullYear(), new Date().getMonth(), 0) } }
                ]}
              />
            </div>

            {/* Client Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Client
              </label>
              <Select
                value={clientFilter}
                onChange={(e) => setClientFilter(e.target.value)}
                options={clients.map(client => ({ value: client.id, label: client.name }))}
              />
            </div>

            {/* Recruiter Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Recruiter
              </label>
              <Select
                value={recruiterFilter}
                onChange={(e) => setRecruiterFilter(e.target.value)}
                options={recruiters.map(recruiter => ({ value: recruiter.id, label: recruiter.name }))}
              />
            </div>

            {/* Job Type Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Job Type
              </label>
              <Select
                value={jobTypeFilter}
                onChange={(e) => setJobTypeFilter(e.target.value)}
                options={jobTypes.map(type => ({ value: type.id, label: type.name }))}
              />
            </div>
          </div>

          <div className="mt-4 flex justify-end">
            <Button onClick={loadReportData} disabled={loading}>
              {loading ? 'Generating Report...' : 'Generate Report'}
            </Button>
          </div>
        </Card>

        {/* Report Content */}
        {reportData ? (
          <>
            {/* Report Header */}
            <div className="flex items-start justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">{reportData.title}</h1>
                <p className="text-gray-600 mt-1">{reportData.description}</p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" leftIcon={<Download className="w-4 h-4" />} onClick={() => exportReport('pdf')}>
                  PDF
                </Button>
                <Button variant="outline" leftIcon={<Download className="w-4 h-4" />} onClick={() => exportReport('csv')}>
                  CSV
                </Button>
                <Button variant="outline" leftIcon={<Mail className="w-4 h-4" />} onClick={() => exportReport('email')}>
                  Email
                </Button>
              </div>
            </div>

            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              {Object.entries(reportData.summary).map(([key, value]) => (
                <SummaryCard key={key} title={key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())} value={value} />
              ))}
            </div>

            {/* Charts and Data Section */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
              {/* Chart Section */}
              <Card>
                <h3 className="text-lg font-semibold mb-4">{reportData.title} Trend</h3>
                <div className="h-80">
                  {/* In production, this would use a charting library */}
                  <div className="w-full h-full bg-gray-50 border-2 border-dashed rounded-lg flex items-center justify-center">
                    <div className="text-center">
                      <BarChart3 className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-600">Chart visualization would appear here</p>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Details Section */}
              <Card>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">{reportData.title} Details</h3>
                  <Button variant="outline" size="sm">
                    Export Details
                  </Button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50 text-left">
                      <tr>
                        <th className="py-2 px-3 font-semibold text-gray-600">Candidate/Client</th>
                        <th className="py-2 px-3 font-semibold text-gray-600">Job/Role</th>
                        <th className="py-2 px-3 font-semibold text-gray-600">Date</th>
                        <th className="py-2 px-3 font-semibold text-gray-600">Revenue</th>
                        <th className="py-2 px-3 font-semibold text-gray-600">Metrics</th>
                      </tr>
                    </thead>
                    <tbody>
                      {reportData.details.map((item, index) => (
                        <tr key={index} className="border-b border-gray-200 hover:bg-gray-50">
                          <td className="py-2 px-3 font-medium">{item.candidate || item.client}</td>
                          <td className="py-2 px-3">{item.job || item.role}</td>
                          <td className="py-2 px-3">{item.placementDate || item.date}</td>
                          <td className="py-2 px-3 font-medium text-green-600">
                            {item.revenue ? `$${formatCurrency(item.revenue)}` : '-'}
                          </td>
                          <td className="py-2 px-3">
                            {item.rate && <Badge variant="gray">{item.rate}</Badge>}
                            {item.commission && <Badge variant="blue">${formatCurrency(item.commission)} comm</Badge>}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>
            </div>

            {/* Additional Metrics */}
            {reportData.metrics && (
              <div className="space-y-6 mb-6">
                {Object.entries(reportData.metrics).map(([key, value]) => (
                  <Card key={key}>
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold">
                        {key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                      </h3>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead className="bg-gray-50 text-left">
                          <tr>
                            {key === 'byClient' && (
                              <>
                                <th className="py-2 px-3 font-semibold text-gray-600">Client</th>
                                <th className="py-2 px-3 font-semibold text-gray-600">Placements</th>
                                <th className="py-2 px-3 font-semibold text-gray-600">Revenue</th>
                              </>
                            )}
                            {key === 'byRole' && (
                              <>
                                <th className="py-2 px-3 font-semibold text-gray-600">Role</th>
                                <th className="py-2 px-3 font-semibold text-gray-600">Placements</th>
                                <th className="py-2 px-3 font-semibold text-gray-600">Revenue</th>
                              </>
                            )}
                            {key === 'byRecruiter' && (
                              <>
                                <th className="py-2 px-3 font-semibold text-gray-600">Recruiter</th>
                                <th className="py-2 px-3 font-semibold text-gray-600">Placements</th>
                                <th className="py-2 px-3 font-semibold text-gray-600">Revenue</th>
                                <th className="py-2 px-3 font-semibold text-gray-600">Avg. Time to Fill</th>
                              </>
                            )}
                          </tr>
                        </thead>
                        <tbody>
                          {value.map((item, index) => (
                            <tr key={index} className="border-b border-gray-200 hover:bg-gray-50">
                              {key === 'byClient' && (
                                <>
                                  <td className="py-2 px-3 font-medium">{item.client}</td>
                                  <td className="py-2 px-3">{item.placements}</td>
                                  <td className="py-2 px-3 font-medium text-green-600">${formatCurrency(item.revenue)}</td>
                                </>
                              )}
                              {key === 'byRole' && (
                                <>
                                  <td className="py-2 px-3 font-medium">{item.role}</td>
                                  <td className="py-2 px-3">{item.placements}</td>
                                  <td className="py-2 px-3 font-medium text-green-600">${formatCurrency(item.revenue)}</td>
                                </>
                              )}
                              {key === 'byRecruiter' && (
                                <>
                                  <td className="py-2 px-3 font-medium">{item.recruiter}</td>
                                  <td className="py-2 px-3">{item.placements}</td>
                                  <td className="py-2 px-3 font-medium text-green-600">${formatCurrency(item.revenue)}</td>
                                  <td className="py-2 px-3">{item.avgTimeToFill} days</td>
                                </>
                              )}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </Card>
                ))}
              </div>
            )}

            {/* Report Footer */}
            <Card className="text-sm text-gray-500 p-4">
              Report generated on {new Date().toLocaleString()} • Based on data from {formatDate(dateRange.from)} to {formatDate(dateRange.to)} • 
              Filters: Client: {clientFilter === 'all' ? 'All' : clients.find(c => c.id === clientFilter)?.name}, 
              Recruiter: {recruiterFilter === 'all' ? 'All' : recruiters.find(r => r.id === recruiterFilter)?.name}, 
              Job Type: {jobTypeFilter === 'all' ? 'All' : jobTypes.find(t => t.id === jobTypeFilter)?.name}
            </Card>
          </>
        ) : (
          <div className="bg-white rounded-xl border-2 border-dashed border-gray-300 p-12 text-center">
            <FileText className="w-12 h-12 text-gray-400 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-gray-900 mb-1">No Report Generated</h3>
            <p className="text-gray-600 mb-4">Select a report type and filters, then click "Generate Report" to create your report</p>
            <Button onClick={loadReportData} disabled={loading}>
              Generate Report
            </Button>
          </div>
        )}

        {/* Export Email Modal */}
        <Modal
          isOpen={showModal}
          onClose={() => setShowModal(false)}
          title="Email Report"
          footer={
            <>
              <Button variant="outline" onClick={() => setShowModal(false)}>
                Cancel
              </Button>
              <Button onClick={() => {
                alert('Report would be emailed to recipients');
                setShowModal(false);
              }}>
                Send Report
              </Button>
            </>
          }
        >
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Recipients
              </label>
              <Input
                placeholder="Enter email addresses (comma separated)"
                value="client@example.com, manager@example.com"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Subject
              </label>
              <Input
                placeholder="Report subject line"
                value={`Placement Report: ${formatDate(dateRange.from)} to ${formatDate(dateRange.to)}`}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Message
              </label>
              <textarea
                className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                rows={4}
                placeholder="Add a message to include with your report..."
                value="Dear Client,

Please find attached the requested performance report for the period specified. This report includes details on placements, revenue generated, and key performance metrics.

Please let me know if you have any questions or need additional information.

Best regards,
Your Recruitment Team"
              />
            </div>
          </div>
        </Modal>
      </PageContainer>
    </>
  );
}

function SummaryCard({ title, value }) {
  // Determine the appropriate icon based on the title
  const getIcon = (title) => {
    if (title.toLowerCase().includes('placement')) return <Award className="w-6 h-6 text-green-600" />;
    if (title.toLowerCase().includes('revenue')) return <DollarSign className="w-6 h-6 text-purple-600" />;
    if (title.toLowerCase().includes('time') || title.toLowerCase().includes('fill')) return <Clock className="w-6 h-6 text-blue-600" />;
    if (title.toLowerCase().includes('rate') || title.toLowerCase().includes('conversion')) return <TrendingUp className="w-6 h-6 text-orange-600" />;
    return <BarChart3 className="w-6 h-6 text-gray-600" />;
  };

  // Format the value appropriately
  const formatValue = (value) => {
    if (typeof value === 'number') {
      if (value >= 1000 && title.toLowerCase().includes('revenue')) {
        return `$${formatCurrency(value)}`;
      } else if (title.toLowerCase().includes('time') || title.toLowerCase().includes('fill')) {
        return `${value} days`;
      } else if (title.toLowerCase().includes('rate') || title.toLowerCase().includes('conversion')) {
        return `${value}%`;
      }
      return value.toLocaleString();
    }
    return value;
  };

  return (
    <Card className="p-4">
      <div className="flex items-center mb-2">
        {getIcon(title)}
        <span className="ml-2 text-sm font-medium text-gray-600">{title}</span>
      </div>
      <div className="text-2xl font-bold text-gray-900">{formatValue(value)}</div>
    </Card>
  );
}