import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase/client';

/**
 * GET /api/jobs/[id]
 * Fetch a single job by ID
 */
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { data, error } = await supabase
      .from('jobs')
      .select(`
        *,
        client:clients(*)
      `)
      .eq('id', params.id)
      .single();
    
    if (error) {
      return NextResponse.json(
        { success: false, error: 'Job not found' },
        { status: 404 }
      );
    }
    
    return NextResponse.json({
      success: true,
      data,
    });
  } catch (error: any) {
    console.error('Job fetch error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}

/**
 * PUT /api/jobs/[id]
 * Update a job
 */
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json();
    
    const { data, error } = await supabase
      .from('jobs')
      .update({
        title: body.title,
        description: body.description,
        requirements: body.requirements,
        skills_required: body.skills_required,
        location: body.location,
        employment_type: body.employment_type,
        experience_level: body.experience_level,
        salary_min: body.salary_min,
        salary_max: body.salary_max,
        salary_currency: body.salary_currency,
        status: body.status,
        client_id: body.client_id,
      })
      .eq('id', params.id)
      .select(`
        *,
        client:clients(*)
      `)
      .single();
    
    if (error) {
      return NextResponse.json(
        { success: false, error: error.message },
        { status: 500 }
      );
    }
    
    // Log activity
    if (body.updated_by) {
      await supabase.from('activities').insert([{
        user_id: body.updated_by,
        action: 'updated',
        entity_type: 'job',
        entity_id: params.id,
        metadata: { title: data.title },
      }]);
    }
    
    return NextResponse.json({
      success: true,
      data,
    });
  } catch (error: any) {
    console.error('Job update error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/jobs/[id]
 * Delete a job
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    
    const { error } = await supabase
      .from('jobs')
      .delete()
      .eq('id', params.id);
    
    if (error) {
      return NextResponse.json(
        { success: false, error: error.message },
        { status: 500 }
      );
    }
    
    // Log activity
    if (userId) {
      await supabase.from('activities').insert([{
        user_id: userId,
        action: 'deleted',
        entity_type: 'job',
        entity_id: params.id,
        metadata: {},
      }]);
    }
    
    return NextResponse.json({
      success: true,
      message: 'Job deleted successfully',
    });
  } catch (error: any) {
    console.error('Job deletion error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}