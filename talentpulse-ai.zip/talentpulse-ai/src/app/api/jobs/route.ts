import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase/client';
import { Job } from '@/lib/types';

export const dynamic = 'force-dynamic';

/**
 * GET /api/jobs
 * Fetch all jobs with optional filters
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    
    // Pagination
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = (page - 1) * limit;
    
    // Filters
    const status = searchParams.get('status');
    const clientId = searchParams.get('clientId');
    const search = searchParams.get('search');
    const location = searchParams.get('location');
    const employmentType = searchParams.get('employmentType');
    const experienceLevel = searchParams.get('experienceLevel');
    
    // Build query
    let query = supabase
      .from('jobs')
      .select(`
        *,
        client:clients(*)
      `, { count: 'exact' });
    
    // Apply filters
    if (status) {
      query = query.eq('status', status);
    }
    
    if (clientId) {
      query = query.eq('client_id', clientId);
    }
    
    if (location) {
      query = query.ilike('location', `%${location}%`);
    }
    
    if (employmentType) {
      query = query.eq('employment_type', employmentType);
    }
    
    if (experienceLevel) {
      query = query.eq('experience_level', experienceLevel);
    }
    
    if (search) {
      query = query.or(`title.ilike.%${search}%,description.ilike.%${search}%`);
    }
    
    // Order and paginate
    query = query
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);
    
    const { data, error, count } = await query;
    
    if (error) {
      console.error('Jobs fetch error:', error);
      return NextResponse.json(
        { success: false, error: error.message },
        { status: 500 }
      );
    }
    
    return NextResponse.json({
      success: true,
      data,
      pagination: {
        page,
        limit,
        total: count || 0,
        totalPages: Math.ceil((count || 0) / limit),
      },
    });
  } catch (error: any) {
    console.error('Jobs API error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/jobs
 * Create a new job
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // Validate required fields
    const required = ['title', 'description', 'location', 'employment_type', 'experience_level', 'client_id', 'created_by'];
    for (const field of required) {
      if (!body[field]) {
        return NextResponse.json(
          { success: false, error: `${field} is required` },
          { status: 400 }
        );
      }
    }
    
    // Insert job
    const { data, error } = await supabase
      .from('jobs')
      .insert([{
        title: body.title,
        description: body.description,
        requirements: body.requirements || [],
        skills_required: body.skills_required || [],
        location: body.location,
        employment_type: body.employment_type,
        experience_level: body.experience_level,
        salary_min: body.salary_min || null,
        salary_max: body.salary_max || null,
        salary_currency: body.salary_currency || 'USD',
        status: body.status || 'draft',
        client_id: body.client_id,
        created_by: body.created_by,
      }])
      .select(`
        *,
        client:clients(*)
      `)
      .single();
    
    if (error) {
      console.error('Job creation error:', error);
      return NextResponse.json(
        { success: false, error: error.message },
        { status: 500 }
      );
    }
    
    // Log activity
    await supabase.from('activities').insert([{
      user_id: body.created_by,
      action: 'created',
      entity_type: 'job',
      entity_id: data.id,
      metadata: { title: data.title },
    }]);
    
    return NextResponse.json({
      success: true,
      data,
    }, { status: 201 });
  } catch (error: any) {
    console.error('Job creation error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}