'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Header from '@/components/layout/Header';
import PageContainer from '@/components/layout/PageContainer';
import { Card, Badge, Button } from '@/components/ui';
import {
  Briefcase,
  Users,
  Send,
  TrendingUp,
  Building2,
  CheckCircle,
  Clock,
  AlertCircle,
  ArrowUp,
  ArrowDown,
  Eye,
  Plus,
} from 'lucide-react';

// Mock data for dashboard
const dashboardData = {
  metrics: {
    activeJobs: { value: 12, change: +2, trend: 'up' as const },
    totalCandidates: { value: 248, change: +15, trend: 'up' as const },
    activeSubmissions: { value: 34, change: -3, trend: 'down' as const },
    placementRate: { value: 68, change: +5, trend: 'up' as const },
  },
  recentJobs: [
    {
      id: '1',
      title: 'Senior Full Stack Developer',
      client: 'Tech Innovations Inc',
      status: 'open',
      submissions: 12,
      matches: 45,
      created_at: '2024-11-20T10:00:00Z',
    },
    {
      id: '2',
      title: 'Product Designer',
      client: 'Design Studio Co',
      status: 'open',
      submissions: 8,
      matches: 32,
      created_at: '2024-11-25T14:30:00Z',
    },
    {
      id: '3',
      title: 'DevOps Engineer',
      client: 'Tech Innovations Inc',
      status: 'open',
      submissions: 5,
      matches: 28,
      created_at: '2024-11-28T09:15:00Z',
    },
  ],
  recentSubmissions: [
    {
      id: '1',
      candidate: 'Alice Johnson',
      job: 'Senior Full Stack Developer',
      status: 'interview_scheduled',
      match_score: 92,
      updated_at: '2024-11-28T14:30:00Z',
    },
    {
      id: '2',
      candidate: 'Bob Martinez',
      job: 'DevOps Engineer',
      status: 'client_reviewing',
      match_score: 88,
      updated_at: '2024-11-28T10:15:00Z',
    },
    {
      id: '3',
      candidate: 'Carol Chen',
      job: 'Product Designer',
      status: 'submitted',
      match_score: 85,
      updated_at: '2024-11-27T16:45:00Z',
    },
  ],
  submissionsByStatus: [
    { status: 'submitted', count: 8 },
    { status: 'client_reviewing', count: 6 },
    { status: 'interview_scheduled', count: 5 },
    { status: 'interview_completed', count: 4 },
    { status: 'offer_extended', count: 3 },
    { status: 'offer_accepted', count: 8 },
  ],
  topPerformingJobs: [
    { id: '1', title: 'Senior Full Stack Developer', submissions: 12, successRate: 75 },
    { id: '2', title: 'DevOps Engineer', submissions: 10, successRate: 70 },
    { id: '3', title: 'Product Designer', submissions: 8, successRate: 65 },
  ],
};

export default function DashboardPage() {
  const router = useRouter();

  const getTrendIcon = (trend: 'up' | 'down') => {
    return trend === 'up' ? (
      <ArrowUp className="w-4 h-4 text-success-600" />
    ) : (
      <ArrowDown className="w-4 h-4 text-danger-600" />
    );
  };

  const getTrendColor = (trend: 'up' | 'down') => {
    return trend === 'up' ? 'text-success-600' : 'text-danger-600';
  };

  return (
    <>
      <Header
        title="Dashboard"
        subtitle="Overview of your recruitment activities"
        actions={
          <div className="flex gap-3">
            <Button
              variant="outline"
              leftIcon={<Plus className="w-4 h-4" />}
              onClick={() => router.push('/library')}
            >
              Add Candidate
            </Button>
            <Button
              leftIcon={<Plus className="w-4 h-4" />}
              onClick={() => router.push('/jobs/new')}
            >
              Create Job
            </Button>
          </div>
        }
      />

      <PageContainer>
        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <Card>
            <div className="flex items-center justify-between mb-2">
              <div className="p-3 bg-primary-100 rounded-lg">
                <Briefcase className="w-6 h-6 text-primary-600" />
              </div>
              <div className="flex items-center gap-1">
                {getTrendIcon(dashboardData.metrics.activeJobs.trend)}
                <span className={`text-sm font-semibold ${getTrendColor(dashboardData.metrics.activeJobs.trend)}`}>
                  {dashboardData.metrics.activeJobs.change > 0 ? '+' : ''}
                  {dashboardData.metrics.activeJobs.change}
                </span>
              </div>
            </div>
            <p className="text-3xl font-bold text-gray-900 mb-1">
              {dashboardData.metrics.activeJobs.value}
            </p>
            <p className="text-sm text-gray-600">Active Jobs</p>
          </Card>

          <Card>
            <div className="flex items-center justify-between mb-2">
              <div className="p-3 bg-purple-100 rounded-lg">
                <Users className="w-6 h-6 text-purple-600" />
              </div>
              <div className="flex items-center gap-1">
                {getTrendIcon(dashboardData.metrics.totalCandidates.trend)}
                <span className={`text-sm font-semibold ${getTrendColor(dashboardData.metrics.totalCandidates.trend)}`}>
                  {dashboardData.metrics.totalCandidates.change > 0 ? '+' : ''}
                  {dashboardData.metrics.totalCandidates.change}
                </span>
              </div>
            </div>
            <p className="text-3xl font-bold text-gray-900 mb-1">
              {dashboardData.metrics.totalCandidates.value}
            </p>
            <p className="text-sm text-gray-600">Total Candidates</p>
          </Card>

          <Card>
            <div className="flex items-center justify-between mb-2">
              <div className="p-3 bg-blue-100 rounded-lg">
                <Send className="w-6 h-6 text-blue-600" />
              </div>
              <div className="flex items-center gap-1">
                {getTrendIcon(dashboardData.metrics.activeSubmissions.trend)}
                <span className={`text-sm font-semibold ${getTrendColor(dashboardData.metrics.activeSubmissions.trend)}`}>
                  {dashboardData.metrics.activeSubmissions.change > 0 ? '+' : ''}
                  {dashboardData.metrics.activeSubmissions.change}
                </span>
              </div>
            </div>
            <p className="text-3xl font-bold text-gray-900 mb-1">
              {dashboardData.metrics.activeSubmissions.value}
            </p>
            <p className="text-sm text-gray-600">Active Submissions</p>
          </Card>

          <Card>
            <div className="flex items-center justify-between mb-2">
              <div className="p-3 bg-success-100 rounded-lg">
                <TrendingUp className="w-6 h-6 text-success-600" />
              </div>
              <div className="flex items-center gap-1">
                {getTrendIcon(dashboardData.metrics.placementRate.trend)}
                <span className={`text-sm font-semibold ${getTrendColor(dashboardData.metrics.placementRate.trend)}`}>
                  {dashboardData.metrics.placementRate.change > 0 ? '+' : ''}
                  {dashboardData.metrics.placementRate.change}%
                </span>
              </div>
            </div>
            <p className="text-3xl font-bold text-gray-900 mb-1">
              {dashboardData.metrics.placementRate.value}%
            </p>
            <p className="text-sm text-gray-600">Placement Rate</p>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Recent Jobs */}
          <Card>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-900">Recent Jobs</h3>
              <Button
                variant="outline"
                size="sm"
                onClick={() => router.push('/jobs')}
              >
                View All
              </Button>
            </div>

            <div className="space-y-4">
              {dashboardData.recentJobs.map((job) => (
                <div
                  key={job.id}
                  className="p-4 border border-gray-200 rounded-lg hover:border-primary-300 transition-colors cursor-pointer"
                  onClick={() => router.push(`/jobs/${job.id}`)}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900">{job.title}</h4>
                      <div className="flex items-center text-sm text-gray-600 mt-1">
                        <Building2 className="w-3 h-3 mr-1" />
                        {job.client}
                      </div>
                    </div>
                    <Badge variant="success">{job.status}</Badge>
                  </div>

                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <div className="flex items-center">
                      <Send className="w-4 h-4 mr-1" />
                      {job.submissions} submissions
                    </div>
                    <div className="flex items-center">
                      <TrendingUp className="w-4 h-4 mr-1" />
                      {job.matches} matches
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Recent Submissions */}
          <Card>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-900">Recent Submissions</h3>
              <Button
                variant="outline"
                size="sm"
                onClick={() => router.push('/submissions')}
              >
                View All
              </Button>
            </div>

            <div className="space-y-4">
              {dashboardData.recentSubmissions.map((submission) => (
                <div
                  key={submission.id}
                  className="p-4 border border-gray-200 rounded-lg hover:border-primary-300 transition-colors cursor-pointer"
                  onClick={() => router.push(`/submissions/${submission.id}`)}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900">{submission.candidate}</h4>
                      <p className="text-sm text-gray-600">{submission.job}</p>
                    </div>
                    <Badge variant="primary" size="sm">
                      {submission.match_score}%
                    </Badge>
                  </div>

                  <Badge
                    variant={
                      submission.status.includes('offer') || submission.status.includes('interview')
                        ? 'success'
                        : 'warning'
                    }
                    size="sm"
                  >
                    {submission.status.replace('_', ' ')}
                  </Badge>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Submissions by Status */}
          <Card>
            <h3 className="text-lg font-semibold text-gray-900 mb-6">Submissions by Status</h3>

            <div className="space-y-4">
              {dashboardData.submissionsByStatus.map((item) => (
                <div key={item.status}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-gray-700 capitalize">
                      {item.status.replace('_', ' ')}
                    </span>
                    <span className="text-sm font-bold text-gray-900">{item.count}</span>
                  </div>
                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary-500"
                      style={{
                        width: `${(item.count / dashboardData.submissionsByStatus.reduce((sum, s) => sum + s.count, 0)) * 100}%`,
                      }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Top Performing Jobs */}
          <Card>
            <h3 className="text-lg font-semibold text-gray-900 mb-6">Top Performing Jobs</h3>

            <div className="space-y-4">
              {dashboardData.topPerformingJobs.map((job, index) => (
                <div
                  key={job.id}
                  className="p-4 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors"
                  onClick={() => router.push(`/jobs/${job.id}`)}
                >
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-8 h-8 bg-primary-500 rounded-full flex items-center justify-center text-white font-bold">
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900">{job.title}</h4>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">{job.submissions} submissions</span>
                    <div className="flex items-center gap-2">
                      <div className="w-24 h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-success-500"
                          style={{ width: `${job.successRate}%` }}
                        ></div>
                      </div>
                      <span className="font-semibold text-success-600">{job.successRate}%</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </PageContainer>
    </>
  );
}