-- talentplus_schema.sql 
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Core Tables
CREATE TABLE public.users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT NOT NULL,
  avatar_url TEXT,
  role TEXT NOT NULL CHECK (role IN ('admin', 'team_lead', 'recruiter', 'owner')),
  team_id UUID REFERENCES teams(id),
  department TEXT,
  is_active BOOLEAN DEFAULT true,
  notifications_enabled BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE public.teams (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  description TEXT,
  team_lead_id UUID REFERENCES users(id),
  max_recruiters INTEGER DEFAULT 10,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE public.clients (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_name TEXT NOT NULL,
  industry TEXT,
  website TEXT,
  primary_contact_name TEXT NOT NULL,
  primary_contact_email TEXT NOT NULL,
  primary_contact_phone TEXT,
  primary_contact_title TEXT,
  address TEXT,
  city TEXT,
  state TEXT,
  zip_code TEXT,
  country TEXT DEFAULT 'USA',
  company_size TEXT CHECK (company_size IN ('1-10', '11-50', '51-200', '201-500', '501+')),
  type TEXT NOT NULL DEFAULT 'direct' CHECK (type IN ('direct', 'agency')),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'prospect', 'archived')),
  notes TEXT,
  relationship_score INTEGER DEFAULT 50 CHECK (relationship_score BETWEEN 0 AND 100),
  contact_frequency TEXT DEFAULT 'monthly' CHECK (contact_frequency IN ('weekly', 'bi-weekly', 'monthly', 'quarterly')),
  tags TEXT[] DEFAULT '{}',
  last_contact TIMESTAMP WITH TIME ZONE,
  created_by UUID NOT NULL REFERENCES users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE public.jobs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  requirements TEXT[] DEFAULT '{}',
  skills_required TEXT[] DEFAULT '{}',
  location TEXT NOT NULL,
  employment_type TEXT NOT NULL CHECK (employment_type IN ('full-time', 'part-time', 'contract', 'temporary', 'internship')),
  experience_level TEXT NOT NULL CHECK (experience_level IN ('entry', 'mid', 'senior', 'lead', 'executive')),
  salary_min NUMERIC,
  salary_max NUMERIC,
  salary_currency TEXT DEFAULT 'USD',
  bill_rate NUMERIC,
  pay_rate NUMERIC,
  margin NUMERIC GENERATED ALWAYS AS (
    CASE 
      WHEN bill_rate IS NOT NULL AND pay_rate IS NOT NULL AND bill_rate > 0 
      THEN ((bill_rate - pay_rate) / bill_rate) * 100 
      ELSE NULL 
    END
  ) STORED,
  client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  assigned_to UUID[] DEFAULT '{}',
  assigned_team_id UUID REFERENCES teams(id),
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'open', 'assigned', 'on_hold', 'filled', 'closed', 'cancelled')),
  priority TEXT DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
  deadline DATE,
  filled_date DATE,
  created_by UUID NOT NULL REFERENCES users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Candidate management with full parsing support
CREATE TABLE public.candidates (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  location TEXT,
  title TEXT,
  summary TEXT,
  skills TEXT[] DEFAULT '{}',
  years_of_experience INTEGER DEFAULT 0,
  experience JSONB DEFAULT '[]',
  education JSONB DEFAULT '[]',
  certifications JSONB DEFAULT '[]',
  languages TEXT[] DEFAULT '{}',
  resume_url TEXT,
  resume_text TEXT,
  parse_confidence INTEGER CHECK (parse_confidence >= 0 AND parse_confidence <= 100),
  authenticity_score INTEGER CHECK (authenticity_score >= 0 AND authenticity_score <= 100),
  authenticity_risk TEXT CHECK (authenticity_risk IN ('LOW', 'MEDIUM', 'HIGH')),
  source TEXT NOT NULL DEFAULT 'upload' CHECK (source IN ('upload', 'linkedin', 'indeed', 'dice', 'apollo', 'referral', 'manual')),
  source_url TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'placed', 'inactive', 'do_not_contact')),
  linkedin_url TEXT,
  github_url TEXT,
  portfolio_url TEXT,
  rtr_status TEXT CHECK (rtr_status IN ('none', 'confirmed', 'expired', 'declined')),
  rtr_expiry_date DATE,
  availability TEXT,
  visa_status TEXT,
  last_contacted TIMESTAMP WITH TIME ZONE,
  last_viewed_at TIMESTAMP WITH TIME ZONE,
  created_by UUID NOT NULL REFERENCES users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  deleted_at TIMESTAMP WITH TIME ZONE
);

-- Full submission workflow with review stages
CREATE TABLE public.submissions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  job_id UUID NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  candidate_id UUID NOT NULL REFERENCES candidates(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN (
    'draft', 'internal_review', 'approved_for_submission', 'submitted_to_client',
    'client_reviewing', 'shortlisted', 'interview_scheduled', 'interview_completed', 
    'offer_extended', 'offer_accepted', 'offer_rejected', 'rejected', 'withdrawn', 'placed'
  )),
  submitted_rate NUMERIC,
  internal_review_notes TEXT,
  client_feedback TEXT,
  notes TEXT,
  timeline JSONB DEFAULT '[]',
  screening_checklist JSONB,
  match_score INTEGER,
  internal_reviewer_id UUID REFERENCES users(id),
  internal_reviewed_at TIMESTAMP WITH TIME ZONE,
  submitted_to_client_at TIMESTAMP WITH TIME ZONE,
  created_by UUID NOT NULL REFERENCES users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Interview tracking
CREATE TABLE public.interviews (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  submission_id UUID NOT NULL REFERENCES submissions(id) ON DELETE CASCADE,
  round_number INTEGER NOT NULL DEFAULT 1,
  interview_type TEXT NOT NULL CHECK (interview_type IN ('phone_screen', 'technical', 'behavioral', 'panel', 'final', 'other')),
  scheduled_at TIMESTAMP WITH TIME ZONE NOT NULL,
  duration_minutes INTEGER DEFAULT 60,
  interviewer_name TEXT,
  interviewer_email TEXT,
  interviewer_phone TEXT,
  location TEXT,
  meeting_link TEXT,
  status TEXT DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'completed', 'cancelled', 'rescheduled', 'no_show')),
  feedback TEXT,
  rating INTEGER CHECK (rating BETWEEN 1 AND 5),
  outcome TEXT CHECK (outcome IN ('pass', 'fail', 'hold', 'pending')),
  prep_notes TEXT,
  follow_up_notes TEXT,
  created_by UUID NOT NULL REFERENCES users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Full activity tracking
CREATE TABLE public.activities (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id),
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id UUID,
  metadata JSONB DEFAULT '{}',
  ip_address TEXT,
  user_agent TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- System settings
CREATE TABLE public.user_settings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id),
  settings JSONB NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Match history
CREATE TABLE public.match_history (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  job_title TEXT NOT NULL,
  job_description TEXT NOT NULL,
  match_count INTEGER NOT NULL DEFAULT 0,
  top_matches UUID[],
  filters JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Row Level Security Policies
-- (Implementation details omitted for brevity - full RLS policies required in production)

-- Indexes for performance
CREATE INDEX idx_jobs_client ON public.jobs(client_id);
CREATE INDEX idx_submissions_job_candidate ON public.submissions(job_id, candidate_id);
CREATE INDEX idx_candidates_skills ON public.candidates USING gin(skills);
CREATE INDEX idx_activities_user_created ON public.activities(user_id, created_at);