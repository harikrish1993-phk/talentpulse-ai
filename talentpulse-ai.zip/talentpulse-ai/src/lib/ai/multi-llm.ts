/**
 * Multi-LLM Service with Automatic Fallbacks
 * Supports: OpenAI GPT-4, Claude, Gemini
 * Ensures AI features ALWAYS work with multiple fallback layers
 */

import OpenAI from 'openai';

// LLM Configuration
interface LLMConfig {
  provider: 'openai' | 'claude' | 'gemini';
  model: string;
  apiKey: string;
  priority: number; // Lower = higher priority
}

// Get LLM configurations from environment
function getLLMConfigs(): LLMConfig[] {
  const configs: LLMConfig[] = [];

  // OpenAI (Primary)
  if (process.env.OPENAI_API_KEY) {
    configs.push({
      provider: 'openai',
      model: 'gpt-4-turbo-preview',
      apiKey: process.env.OPENAI_API_KEY,
      priority: 1,
    });
  }

  // Claude (Secondary - via OpenAI-compatible endpoint)
  if (process.env.ANTHROPIC_API_KEY) {
    configs.push({
      provider: 'claude',
      model: 'claude-3-opus-20240229',
      apiKey: process.env.ANTHROPIC_API_KEY,
      priority: 2,
    });
  }

  // Gemini (Tertiary - via OpenAI-compatible endpoint)
  if (process.env.GEMINI_API_KEY) {
    configs.push({
      provider: 'gemini',
      model: 'gemini-2.5-flash',
      apiKey: process.env.GEMINI_API_KEY,
      priority: 3,
    });
  }

  return configs.sort((a, b) => a.priority - b.priority);
}

/**
 * Call LLM with automatic fallback
 */
export async function callLLMWithFallback(
  prompt: string,
  systemPrompt: string,
  options: {
    temperature?: number;
    maxTokens?: number;
    responseFormat?: 'json' | 'text';
  } = {}
): Promise<{ success: boolean; content: string; provider: string; error?: string }> {
  const configs = getLLMConfigs();

  if (configs.length === 0) {
    return {
      success: false,
      content: '',
      provider: 'none',
      error: 'No LLM API keys configured. Please add OPENAI_API_KEY, ANTHROPIC_API_KEY, or GEMINI_API_KEY to environment variables.',
    };
  }

  // Try each LLM in priority order
  for (const config of configs) {
    try {
      console.log(`Attempting ${config.provider}...`);
      
      const client = new OpenAI({
        apiKey: config.apiKey,
        baseURL: getBaseURL(config.provider),
      });

      const response = await client.chat.completions.create({
        model: config.model,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: prompt },
        ],
        temperature: options.temperature ?? 0.3,
        max_tokens: options.maxTokens ?? 2000,
        ...(options.responseFormat === 'json' && { response_format: { type: 'json_object' } }),
      });

      const content = response.choices[0]?.message?.content;
      
      if (content) {
        console.log(`✅ Success with ${config.provider}`);
        return {
          success: true,
          content,
          provider: config.provider,
        };
      }
    } catch (error: any) {
      console.error(`❌ ${config.provider} failed:`, error.message);
      // Continue to next provider
    }
  }

  // All providers failed
  return {
    success: false,
    content: '',
    provider: 'all_failed',
    error: 'All LLM providers failed. Please check your API keys and try again.',
  };
}

function getBaseURL(provider: string): string | undefined {
  switch (provider) {
    case 'openai':
      return undefined; // Use default OpenAI endpoint
    case 'claude':
      return 'https://api.anthropic.com/v1'; // Anthropic endpoint
    case 'gemini':
      return 'https://generativelanguage.googleapis.com/v1beta'; // Gemini endpoint
    default:
      return undefined;
  }
}

/**
 * Parse resume with fallback support
 */
export async function parseResumeWithFallback(
  resumeText: string
): Promise<{
  success: boolean;
  data?: any;
  confidence?: number;
  provider?: string;
  error?: string;
}> {
  if (!resumeText || resumeText.trim().length < 50) {
    return {
      success: false,
      error: 'Resume text is too short or empty',
    };
  }

  const prompt = `Extract structured information from this resume and return ONLY valid JSON.

Resume Text:
${resumeText}

Return this exact JSON structure:
{
  "name": "Full Name",
  "email": "email@example.com",
  "phone": "+1234567890",
  "location": "City, State",
  "title": "Current Job Title",
  "summary": "Professional summary",
  "skills": ["skill1", "skill2"],
  "years_of_experience": 5,
  "experience": [
    {
      "title": "Job Title",
      "company": "Company",
      "location": "City, State",
      "start_date": "2020-01",
      "end_date": "2023-12",
      "description": "Description",
      "achievements": ["achievement1"]
    }
  ],
  "education": [
    {
      "degree": "Bachelor of Science",
      "institution": "University",
      "graduation_date": "2018-05"
    }
  ],
  "linkedin_url": "https://linkedin.com/in/username"
}`;

  const systemPrompt = 'You are an expert resume parser. Extract structured data and return valid JSON only.';

  const result = await callLLMWithFallback(prompt, systemPrompt, {
    temperature: 0.1,
    maxTokens: 3000,
    responseFormat: 'json',
  });

  if (!result.success) {
    return {
      success: false,
      error: result.error,
    };
  }

  try {
    const parsed = JSON.parse(result.content);
    const confidence = calculateConfidence(parsed);

    return {
      success: true,
      data: parsed,
      confidence,
      provider: result.provider,
    };
  } catch (error: any) {
    return {
      success: false,
      error: 'Failed to parse AI response as JSON',
    };
  }
}

/**
 * Generate match summary with fallback
 */
export async function generateMatchSummaryWithFallback(
  jobTitle: string,
  jobSkills: string[],
  candidateName: string,
  candidateSkills: string[],
  matchScore: number,
  matchingSkills: string[],
  missingSkills: string[]
): Promise<string> {
  const prompt = `Generate a concise 2-3 sentence professional summary of this candidate-job match.

Job: ${jobTitle}
Required Skills: ${jobSkills.join(', ')}

Candidate: ${candidateName}
Skills: ${candidateSkills.join(', ')}

Match Score: ${matchScore}%
Matching Skills: ${matchingSkills.join(', ')}
Missing Skills: ${missingSkills.join(', ')}

Provide a professional summary highlighting strengths and gaps.`;

  const systemPrompt = 'You are a recruitment expert providing match analysis.';

  const result = await callLLMWithFallback(prompt, systemPrompt, {
    temperature: 0.3,
    maxTokens: 200,
  });

  if (!result.success) {
    // Fallback to template-based summary
    return generateTemplateSummary(matchScore, matchingSkills.length, missingSkills.length);
  }

  return result.content;
}

/**
 * Analyze resume authenticity with fallback
 */
export async function analyzeAuthenticityWithFallback(
  resumeText: string,
  candidateName: string,
  yearsOfExperience: number
): Promise<{
  score: number;
  flags: string[];
  analysis: string;
}> {
  const prompt = `Analyze this resume for authenticity and potential red flags.

Resume Text:
${resumeText}

Candidate: ${candidateName}
Experience: ${yearsOfExperience} years

Analyze for:
1. Consistency in dates and timeline
2. Realistic progression
3. Appropriate skill levels
4. Grammar and professionalism
5. Potential exaggerations

Return JSON:
{
  "score": 85,
  "flags": ["flag1", "flag2"],
  "analysis": "Detailed analysis"
}

Score: 0-100 (100 = highly authentic, 0 = likely fraudulent)`;

  const systemPrompt = 'You are an expert at detecting resume fraud and inconsistencies.';

  const result = await callLLMWithFallback(prompt, systemPrompt, {
    temperature: 0.2,
    maxTokens: 1000,
    responseFormat: 'json',
  });

  if (!result.success) {
    // Fallback to basic analysis
    return {
      score: 70,
      flags: ['Unable to perform AI analysis'],
      analysis: 'Authenticity check unavailable. Manual review recommended.',
    };
  }

  try {
    return JSON.parse(result.content);
  } catch {
    return {
      score: 70,
      flags: ['Analysis parsing error'],
      analysis: 'Authenticity check incomplete. Manual review recommended.',
    };
  }
}

// Helper functions

function calculateConfidence(parsed: any): number {
  let score = 0;
  const weights = {
    name: 15,
    email: 15,
    phone: 5,
    location: 5,
    title: 10,
    summary: 5,
    skills: 15,
    experience: 20,
    education: 10,
  };

  if (parsed.name && parsed.name.trim().length > 0) score += weights.name;
  if (parsed.email && parsed.email.includes('@')) score += weights.email;
  if (parsed.phone) score += weights.phone;
  if (parsed.location) score += weights.location;
  if (parsed.title) score += weights.title;
  if (parsed.summary && parsed.summary.length > 20) score += weights.summary;
  if (parsed.skills && parsed.skills.length >= 3) score += weights.skills;
  if (parsed.experience && parsed.experience.length > 0) score += weights.experience;
  if (parsed.education && parsed.education.length > 0) score += weights.education;

  return Math.min(100, score);
}

function generateTemplateSummary(
  matchScore: number,
  matchingCount: number,
  missingCount: number
): string {
  if (matchScore >= 80) {
    return `Strong match with ${matchingCount} matching skills. ${missingCount > 0 ? `Missing ${missingCount} skills but overall highly qualified.` : 'Meets all requirements.'}`;
  } else if (matchScore >= 60) {
    return `Good match with ${matchingCount} matching skills. ${missingCount} skills need development or training.`;
  } else {
    return `Fair match with ${matchingCount} matching skills. Significant skill gaps (${missingCount} missing skills) may require extensive training.`;
  }
}


