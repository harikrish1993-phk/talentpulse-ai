// Create centralized config management
// src/lib/config.ts
export const APP_CONFIG = {
  // Environment-specific settings
  environment: process.env.NODE_ENV || 'development',
  
  // AI provider configuration with fallbacks
  ai: {
    providers: {
      openai: {
        apiKey: process.env.OPENAI_API_KEY,
        models: {
          parsing: 'gpt-4-turbo-preview',
          matching: 'gpt-3.5-turbo-0125'
        }
      },
      anthropic: {
        apiKey: process.env.ANTHROPIC_API_KEY,
        models: {
          fallback: 'claude-3-opus-20240229'
        }
      }
    },
    strategy: {
      resumeParsing: ['openai', 'anthropic', 'regex'],
      jobAnalysis: ['openai', 'regex'],
      matching: ['openai']
    }
  },
  
  // Database connection settings
  database: {
    url: process.env.DATABASE_URL,
    maxConnections: 10,
    timeout: 5000
  },
  
  // Limits and constraints
  limits: {
    maxFileSizeMB: 10,
    bulkUploadLimit: 50,
    dailyMatchLimit: 1000,
    aiTokenBudget: 10000
  }
};