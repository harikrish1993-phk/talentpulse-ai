'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard, Briefcase, Users, GitCompare, Send, 
  Building2, FileText, Settings, HelpCircle
} from 'lucide-react';

interface NavItem {
  label: string;
  href: string;
  icon: React.ReactNode;
  roles?: ('admin' | 'team_lead' | 'recruiter')[];
}

const mainNavItems: NavItem[] = [
  {
    label: 'Dashboard',
    href: '/dashboard',
    icon: <LayoutDashboard className="w-5 h-5" />,
    roles: ['admin', 'team_lead', 'recruiter']
  },
  {
    label: 'Jobs',
    href: '/jobs',
    icon: <Briefcase className="w-5 h-5" />,
    roles: ['admin', 'team_lead', 'recruiter']
  },
  {
    label: 'Clients',
    href: '/clients',
    icon: <Building2 className="w-5 h-5" />,
    roles: ['admin', 'team_lead', 'recruiter']
  },
  {
    label: 'Library',
    href: '/library',
    icon: <Users className="w-5 h-5" />,
    roles: ['admin', 'team_lead', 'recruiter']
  },
  {
    label: 'Match',
    href: '/match',
    icon: <GitCompare className="w-5 h-5" />,
    roles: ['admin', 'team_lead', 'recruiter']
  },
  {
    label: 'Submissions',
    href: '/submissions',
    icon: <Send className="w-5 h-5" />,
    roles: ['admin', 'team_lead', 'recruiter']
  },
  {
    label: 'Reports',
    href: '/reports',
    icon: <FileText className="w-5 h-5" />,
    roles: ['admin', 'team_lead']
  }
];

const bottomNavItems: NavItem[] = [
  {
    label: 'Settings',
    href: '/settings',
    icon: <Settings className="w-5 h-5" />,
    roles: ['admin']
  },
  {
    label: 'Help',
    href: '/help',
    icon: <HelpCircle className="w-5 h-5" />,
    roles: ['admin', 'team_lead', 'recruiter']
  }
];

export default function Navigation() {
  const pathname = usePathname();
  const userRole = 'admin'; // In a real app, this would come from auth context
  
  const isActive = (href: string) => {
    if (href === '/dashboard') {
      return pathname === href;
    }
    return pathname?.startsWith(href);
  };

  return (
    <nav className="fixed left-0 top-0 h-screen w-64 bg-white border-r border-gray-200 flex flex-col z-40">
      {/* Logo */}
      <div className="p-6 border-b border-gray-200">
        <Link href="/dashboard" className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
            <span className="text-white font-bold text-xl">T+</span>
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900">TalentPlus</h1>
            <p className="text-xs text-gray-500">Recruitment System</p>
          </div>
        </Link>
      </div>

      {/* Main Navigation */}
      <div className="flex-1 overflow-y-auto py-4">
        <div className="space-y-1 px-3">
          {mainNavItems
            .filter(item => !item.roles || item.roles.includes(userRole as any))
            .map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  'flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200',
                  isActive(item.href)
                    ? 'bg-blue-50 text-blue-700'
                    : 'text-gray-700 hover:bg-gray-100'
                )}
              >
                <span
                  className={cn(
                    isActive(item.href) ? 'text-blue-600' : 'text-gray-400'
                  )}
                >
                  {item.icon}
                </span>
                <span className="flex-1">{item.label}</span>
              </Link>
            ))}
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="border-t border-gray-200 p-3 space-y-1">
        {bottomNavItems
          .filter(item => !item.roles || item.roles.includes(userRole as any))
          .map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200',
                isActive(item.href)
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-gray-700 hover:bg-gray-100'
              )}
            >
              <span
                className={cn(
                  isActive(item.href) ? 'text-blue-600' : 'text-gray-400'
                )}
              >
                {item.icon}
              </span>
              <span className="flex-1">{item.label}</span>
            </Link>
          ))}
      </div>
    </nav>
  );
}