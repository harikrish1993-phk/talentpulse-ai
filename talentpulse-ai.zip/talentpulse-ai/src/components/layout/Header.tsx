import { Bell, Search, User } from 'lucide-react';
import { Input } from '@/components/ui';
import { cn } from '@/lib/utils';

export interface HeaderProps {
  title?: string;
  subtitle?: string;
  actions?: React.ReactNode;
}

export default function Header({ title, subtitle, actions }: HeaderProps) {
  return (
    <header className="sticky top-0 z-40 bg-white border-b border-gray-200">
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Title Section */}
          <div className="flex-1 min-w-0">
            {title && (
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900 truncate">{title}</h1>
                  {subtitle && (
                    <p className="text-sm text-gray-500 mt-1 sm:mt-0">{subtitle}</p>
                  )}
                </div>
                {actions && (
                  <div className="mt-3 sm:mt-0 sm:ml-4">{actions}</div>
                )}
              </div>
            )}
          </div>

          {/* Right Section - Actions, Search, Notifications, Profile */}
          <div className="flex items-center gap-4">
            {/* Search (hidden on mobile) */}
            <div className="hidden md:block w-72">
              <Input
                type="search"
                placeholder="Search..."
                leftIcon={<Search className="w-4 h-4 text-gray-400" />}
                size="sm"
              />
            </div>

            {/* Notifications */}
            <button 
              className="p-2 text-gray-400 hover:text-gray-500 rounded-full bg-gray-50 hover:bg-gray-100 transition-colors relative"
              aria-label="Notifications"
            >
              <Bell className="w-5 h-5" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>

            {/* Profile */}
            <button 
              className="flex items-center gap-2 p-1 hover:bg-gray-50 rounded-lg transition-colors"
              aria-label="User profile"
            >
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                <User className="w-5 h-5 text-blue-600" />
              </div>
              <span className="hidden lg:block text-sm font-medium text-gray-700">Admin</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}