// src/components/JobBoard.tsx - EXTERNAL JOB BOARD INTEGRATION
'use client';
import { useState, useEffect } from 'react';
import { 
  Search, Filter, ExternalLink, Copy, Check, AlertCircle, 
  Briefcase, MapPin, DollarSign, Calendar, Users, ArrowRight,
  Plus, RefreshCw, Loader2
} from 'lucide-react';
import { Button, Input, Select, Card, Badge, Alert, Modal } from '@/components/ui';

export default function JobBoard() {
  const [activeTab, setActiveTab] = useState<'internal' | 'linkedin' | 'indeed' | 'dice'>('internal');
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({
    location: '',
    experience: '',
    salaryMin: '',
    jobType: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [jobs, setJobs] = useState<any[]>([]);
  const [selectedJob, setSelectedJob] = useState<any>(null);
  const [showImportModal, setShowImportModal] = useState(false);
  const [importSuccess, setImportSuccess] = useState(false);
  
  useEffect(() => {
    loadJobs();
  }, [activeTab, searchTerm, filters]);
  
  async function loadJobs() {
    try {
      setLoading(true);
      setError(null);
      
      let apiUrl = '';
      switch (activeTab) {
        case 'internal':
          apiUrl = '/api/jobs?status=open';
          break;
        case 'linkedin':
          apiUrl = '/api/external-search/linkedin?keywords=developer';
          break;
        case 'indeed':
          apiUrl = '/api/external-search/indeed?keywords=developer';
          break;
        case 'dice':
          apiUrl = '/api/external-search/dice?keywords=developer';
          break;
      }
      
      const response = await fetch(apiUrl);
      if (!response.ok) throw new Error('Failed to fetch jobs');
      
      const data = await response.json();
      setJobs(data.jobs || data.data || []);
      
    } catch (err: any) {
      setError(err.message || 'Failed to load jobs');
      setJobs([]);
    } finally {
      setLoading(false);
    }
  }
  
  async function importJob(job: any) {
    try {
      const response = await fetch('/api/jobs/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          externalJobId: job.id || job.jobId,
          source: activeTab,
          jobData: job
        })
      });
      
      if (!response.ok) throw new Error('Failed to import job');
      
      setImportSuccess(true);
      setTimeout(() => {
        setImportSuccess(false);
        setShowImportModal(false);
        setSelectedJob(null);
        loadJobs();
      }, 2000);
      
    } catch (err: any) {
      setError(err.message || 'Failed to import job');
    }
  }
  
  const tabs = [
    { id: 'internal', label: 'Internal Jobs', icon: Briefcase },
    { id: 'linkedin', label: 'LinkedIn', icon: ExternalLink },
    { id: 'indeed', label: 'Indeed', icon: ExternalLink },
    { id: 'dice', label: 'Dice', icon: ExternalLink }
  ];
  
  const experienceLevels = [
    'Internship', 'Entry Level', 'Associate', 'Mid-Senior Level', 'Director', 'Executive'
  ];
  
  const jobTypes = [
    'Full-time', 'Part-time', 'Contract', 'Temporary', 'Internship'
  ];
  
  return (
    <div className="space-y-6">
      {/* Tabs Navigation */}
      <div className="flex border-b border-gray-200">
        {tabs.map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2 font-medium text-sm border-b-2 ${
                activeTab === tab.id
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>
      
      {/* Search and Filters */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="md:col-span-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              placeholder={`Search ${activeTab === 'internal' ? 'internal' : 'external'} jobs...`}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
        <div>
          <Button 
            variant="outline" 
            className="w-full"
            onClick={() => loadJobs()}
            disabled={loading}
          >
            {loading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <RefreshCw className="w-4 h-4 mr-2" />
            )}
            Refresh
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Filter Sidebar */}
        <div className="md:col-span-1">
          <Card className="p-4">
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <Filter className="w-5 h-5 text-gray-600" />
              Filter Results
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-700 mb-1">Location</label>
                <Input
                  placeholder="e.g., Remote, New York"
                  value={filters.location}
                  onChange={(e) => setFilters({...filters, location: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-sm text-gray-700 mb-1">Experience Level</label>
                <Select
                  value={filters.experience}
                  onChange={(e) => setFilters({...filters, experience: e.target.value})}
                  options={[
                    { value: '', label: 'All Levels' },
                    ...experienceLevels.map(level => ({ value: level.toLowerCase().replace(' ', '_'), label: level }))
                  ]}
                />
              </div>
              <div>
                <label className="block text-sm text-gray-700 mb-1">Minimum Salary</label>
                <Input
                  type="number"
                  placeholder="e.g., 80000"
                  value={filters.salaryMin}
                  onChange={(e) => setFilters({...filters, salaryMin: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-sm text-gray-700 mb-1">Job Type</label>
                <Select
                  value={filters.jobType}
                  onChange={(e) => setFilters({...filters, jobType: e.target.value})}
                  options={[
                    { value: '', label: 'All Types' },
                    ...jobTypes.map(type => ({ value: type.toLowerCase().replace(' ', '_'), label: type }))
                  ]}
                />
              </div>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => setFilters({ location: '', experience: '', salaryMin: '', jobType: '' })}
              >
                Clear Filters
              </Button>
            </div>
          </Card>
        </div>
        
        {/* Job Results */}
        <div className="md:col-span-3">
          {error && (
            <Alert variant="danger" className="mb-4" onClose={() => setError(null)}>
              {error}
            </Alert>
          )}
          
          {jobs.length === 0 && !loading ? (
            <div className="text-center py-12 bg-white border border-dashed rounded-xl">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Briefcase className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                {activeTab === 'internal' ? 'No active jobs found' : 'No jobs found'}
              </h3>
              <p className="text-gray-600 mb-4">
                {activeTab === 'internal' 
                  ? 'Create your first job to get started'
                  : 'Try adjusting your search criteria or filters'}
              </p>
              {activeTab === 'internal' && (
                <Button onClick={() => window.location.href = '/jobs/new'}>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Job
                </Button>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              {jobs.slice(0, 10).map((job, index) => (
                <JobCard 
                  key={index} 
                  job={job} 
                  source={activeTab} 
                  onImport={() => {
                    setSelectedJob(job);
                    setShowImportModal(true);
                  }}
                />
              ))}
            </div>
          )}
          
          {loading && (
            <div className="text-center py-8">
              <Loader2 className="w-8 h-8 animate-spin text-blue-600 mx-auto mb-2" />
              <p className="text-gray-600">Loading jobs...</p>
            </div>
          )}
        </div>
      </div>
      
      {/* Import Modal */}
      <Modal
        isOpen={showImportModal}
        onClose={() => {
          setShowImportModal(false);
          setSelectedJob(null);
          setImportSuccess(false);
        }}
        title="Import Job"
        description={selectedJob ? `Import "${selectedJob.title || selectedJob.jobtitle}" from ${activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}` : ''}
      >
        {selectedJob && (
          <div className="space-y-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-2">Job Details Preview</h4>
              <div className="space-y-2 text-sm">
                <p><span className="font-medium">Title:</span> {selectedJob.title || selectedJob.jobtitle}</p>
                <p><span className="font-medium">Company:</span> {selectedJob.company || selectedJob.organization}</p>
                <p><span className="font-medium">Location:</span> {selectedJob.location || 'Remote'}</p>
                {selectedJob.salary && (
                  <p><span className="font-medium">Salary:</span> {selectedJob.salary}</p>
                )}
                <p className="mt-2 text-gray-600 text-xs max-h-32 overflow-y-auto">
                  <span className="font-medium">Description:</span> {selectedJob.description || selectedJob.snippet || 'No description available'}
                </p>
              </div>
            </div>
            
            <Alert variant="info" className="text-sm">
              This job will be imported to your internal job board and can be assigned to recruiters or matched with candidates.
            </Alert>
            
            {importSuccess && (
              <Alert variant="success">
                <Check className="w-5 h-5 text-green-600 mr-2" />
                <span>Job imported successfully!</span>
              </Alert>
            )}
            
            <div className="flex gap-3 pt-4 border-t border-gray-200">
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={() => {
                  setShowImportModal(false);
                  setSelectedJob(null);
                  setImportSuccess(false);
                }}
                disabled={importSuccess}
              >
                Cancel
              </Button>
              <Button 
                className="flex-1"
                onClick={() => importJob(selectedJob)}
                disabled={importSuccess}
              >
                {importSuccess ? (
                  <>
                    <Check className="w-4 h-4 mr-2" />
                    Imported
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4 mr-2" />
                    Import Job
                  </>
                )}
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

function JobCard({ job, source, onImport }: any) {
  const isInternal = source === 'internal';
  
  return (
    <div className="bg-white rounded-xl border p-5 hover:shadow-md transition-shadow">
      <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between mb-2">
            <div className="flex-1">
              <h3 className="font-semibold text-gray-900 text-lg line-clamp-1">
                {job.title || job.jobtitle}
              </h3>
              <div className="flex flex-wrap gap-2 mt-1">
                <div className="flex items-center text-sm text-gray-600">
                  <Briefcase className="w-4 h-4 mr-1" />
                  <span>{job.company || job.organization || 'Unknown Company'}</span>
                </div>
                {job.location && (
                  <div className="flex items-center text-sm text-gray-600">
                    <MapPin className="w-4 h-4 mr-1" />
                    <span>{job.location}</span>
                  </div>
                )}
              </div>
            </div>
            {!isInternal && (
              <div className="flex-shrink-0">
                <Badge variant={source === 'linkedin' ? 'blue' : source === 'indeed' ? 'green' : 'purple'} size="sm">
                  {source.charAt(0).toUpperCase() + source.slice(1)}
                </Badge>
              </div>
            )}
          </div>
          
          <p className="text-gray-600 text-sm line-clamp-2 mb-3 mt-1">
            {job.description || job.snippet || 'No description available'}
          </p>
          
          <div className="flex flex-wrap gap-2 mb-3">
            {(job.skills || job.keySkills)?.slice(0, 5).map((skill: string, i: number) => (
              <Badge key={i} size="sm" variant="gray">
                {skill}
              </Badge>
            ))}
          </div>
          
          <div className="flex flex-wrap items-center gap-3 text-sm text-gray-600">
            {job.salary && (
              <div className="flex items-center">
                <DollarSign className="w-4 h-4 mr-1" />
                <span>{job.salary}</span>
              </div>
            )}
            {job.experienceLevel && (
              <div className="flex items-center">
                <Users className="w-4 h-4 mr-1" />
                <span>{job.experienceLevel}</span>
              </div>
            )}
            {job.datePosted && (
              <div className="flex items-center">
                <Calendar className="w-4 h-4 mr-1" />
                <span>Posted {getDateAgo(job.datePosted)}</span>
              </div>
            )}
          </div>
        </div>
        
        <div className="flex-shrink-0 flex flex-col items-end gap-2">
          {isInternal && (
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => window.location.href = `/jobs/${job.id}`}>
                View Details
              </Button>
              <Button size="sm" onClick={() => window.location.href = `/match?job=${job.id}`}>
                Match Candidates
              </Button>
            </div>
          )}
          
          {!isInternal && (
            <>
              <Button 
                variant="outline" 
                size="sm" 
                className="w-full md:w-auto"
                onClick={() => window.open(job.url || job.linkedInUrl || job.indeedUrl, '_blank')}
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                View on {source.charAt(0).toUpperCase() + source.slice(1)}
              </Button>
              
              <Button 
                size="sm" 
                className="w-full md:w-auto"
                onClick={onImport}
              >
                <Plus className="w-4 h-4 mr-2" />
                Import to TalentPlus
              </Button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function getDateAgo(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const diffTime = Math.abs(now.getTime() - date.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  if (diffDays === 0) return 'today';
  if (diffDays === 1) return 'yesterday';
  if (diffDays < 7) return `${diffDays} days ago`;
  if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
  
  const months = Math.floor(diffDays / 30);
  if (months < 12) return `${months} months ago`;
  
  return `${Math.floor(months / 12)} years ago`;
}