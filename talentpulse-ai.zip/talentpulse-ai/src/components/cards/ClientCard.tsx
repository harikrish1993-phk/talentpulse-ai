// src/app/clients/components/ClientCard.tsx - COMPLETE VERSION
import { useState } from 'react';
import { 
  Building2, Users, Mail, Phone, MapPin, Calendar, Briefcase,
  CheckCircle, TrendingUp, Activity, ExternalLink, Star, Link2
} from 'lucide-react';
import type { Client } from '@/lib/types';
import { formatCurrency } from '@/lib/utils';

interface ClientCardProps {
  client: Client;
  onEdit?: (client: Client) => void;
  onDelete?: (client: Client) => void;
  onView?: (client: Client) => void;
}

const ClientCard = ({ client, onEdit, onDelete, onView }: ClientCardProps) => {
  const [showActions, setShowActions] = useState(false);
  const statusColors = {
    active: 'bg-green-100 text-green-700 border-green-200',
    inactive: 'bg-gray-100 text-gray-700 border-gray-200',
    prospect: 'bg-blue-100 text-blue-700 border-blue-200'
  };
  
  const typeIcons = {
    direct: Building2,
    agency: Users
  };
  
  const TypeIcon = client.type ? typeIcons[client.type] : Building2;
  
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-shadow overflow-hidden">
      {/* Header with Actions */}
      <div className="px-5 py-4 border-b border-gray-100 flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-blue-50 rounded-lg">
            <TypeIcon className="w-5 h-5 text-blue-600" />
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-semibold text-gray-900">{client.name}</h3>
              <span className={`px-2 py-0.5 rounded-full text-xs font-medium border ${statusColors[client.status]}`}>
                {client.status}
              </span>
              {client.is_favorite && (
                <Star className="w-4 h-4 text-yellow-500 fill-yellow-200" />
              )}
            </div>
            <p className="text-sm text-gray-500 mt-0.5">
              {client.primary_contact_name} • {client.primary_contact_email}
            </p>
          </div>
        </div>
        <div className="relative">
          <button
            onClick={() => setShowActions(!showActions)}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            aria-label="More actions"
          >
            <MoreVertical className="w-5 h-5 text-gray-600" />
          </button>
          {showActions && (
            <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-1 z-10">
              <button
                onClick={() => onView?.(client)}
                className="w-full flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                View Details
              </button>
              <button
                onClick={() => onEdit?.(client)}
                className="w-full flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50"
              >
                <Edit2 className="w-4 h-4 mr-2" />
                Edit Client
              </button>
              <button
                onClick={() => onDelete?.(client)}
                className="w-full flex items-center px-4 py-2 text-sm text-red-600 hover:bg-gray-50"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Delete
              </button>
            </div>
          )}
        </div>
      </div>
      
      {/* Main Content */}
      <div className="p-5">
        {/* Contact Info */}
        <div className="mb-4">
          {client.website && (
            <div className="flex items-center text-sm text-blue-600 mb-2">
              <Link2 className="w-4 h-4 mr-2" />
              <a href={client.website} target="_blank" rel="noopener noreferrer" 
                 className="hover:underline break-all">
                {client.website.replace(/^https?:\/\//, '')}
              </a>
            </div>
          )}
          {client.address && (
            <div className="flex items-center text-sm text-gray-600 mb-2">
              <MapPin className="w-4 h-4 mr-2" />
              <span className="break-all">{client.address}</span>
              {client.city && (
                <span className="ml-1">• {client.city}, {client.country}</span>
              )}
            </div>
          )}
        </div>
        
        {/* Metrics Row */}
        <div className="grid grid-cols-3 gap-3 mb-4 pt-3 border-t border-gray-100">
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Briefcase className="w-4 h-4 text-gray-400" />
              <span className="font-semibold text-gray-900">{client.active_jobs}</span>
            </div>
            <span className="text-xs text-gray-500">Active Jobs</span>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <CheckCircle className="w-4 h-4 text-gray-400" />
              <span className="font-semibold text-gray-900">{client.total_placements}</span>
            </div>
            <span className="text-xs text-gray-500">Placements</span>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <TrendingUp className="w-4 h-4 text-gray-400" />
              <span className="font-semibold text-gray-900">€{formatCurrency(client.total_revenue || 0)}</span>
            </div>
            <span className="text-xs text-gray-500">Revenue</span>
          </div>
        </div>
        
        {/* Tags */}
        {client.tags && client.tags.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mt-3">
            {client.tags.slice(0, 3).map((tag, idx) => (
              <span key={idx} className="px-2 py-1 bg-gray-100 text-gray-700 rounded-full text-xs">
                {tag}
              </span>
            ))}
            {client.tags.length > 3 && (
              <span className="px-2 py-1 bg-gray-100 text-gray-500 rounded-full text-xs">
                +{client.tags.length - 3}
              </span>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ClientCard;