import Link from 'next/link';
import { Job } from '@/lib/types';
import { Card, Badge } from '@/components/ui';
import {
  MapPin,
  DollarSign,
  Briefcase,
  Calendar,
  Building2,
  Users,
} from 'lucide-react';
import { formatSalaryRange, formatRelativeDate, getStatusColor } from '@/lib/utils';

export interface JobCardProps {
  job: Job;
}

export default function JobCard({ job }: JobCardProps) {
  return (
    <Link href={`/jobs/${job.id}`}>
      <Card hoverable className="h-full">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-gray-900 mb-1 hover:text-primary-600 transition-colors">
              {job.title}
            </h3>
            {job.client && (
              <div className="flex items-center text-sm text-gray-600">
                <Building2 className="w-4 h-4 mr-1" />
                {job.client.company_name}
              </div>
            )}
          </div>
          <Badge variant={job.status === 'open' ? 'success' : job.status === 'closed' ? 'danger' : 'warning'}>
            {job.status.replace('_', ' ')}
          </Badge>
        </div>

        {/* Description */}
        <p className="text-sm text-gray-600 mb-4 line-clamp-2">
          {job.description}
        </p>

        {/* Details */}
        <div className="space-y-2 mb-4">
          <div className="flex items-center text-sm text-gray-700">
            <MapPin className="w-4 h-4 mr-2 text-gray-400" />
            {job.location}
          </div>
          <div className="flex items-center text-sm text-gray-700">
            <DollarSign className="w-4 h-4 mr-2 text-gray-400" />
            {formatSalaryRange(job.salary_min, job.salary_max, job.salary_currency)}
          </div>
          <div className="flex items-center text-sm text-gray-700">
            <Briefcase className="w-4 h-4 mr-2 text-gray-400" />
            {job.employment_type.replace('-', ' ')} • {job.experience_level}
          </div>
        </div>

        {/* Skills */}
        {job.skills_required && job.skills_required.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mb-4">
            {job.skills_required.slice(0, 5).map((skill, index) => (
              <Badge key={index} size="sm" variant="gray">
                {skill}
              </Badge>
            ))}
            {job.skills_required.length > 5 && (
              <Badge size="sm" variant="gray">
                +{job.skills_required.length - 5}
              </Badge>
            )}
          </div>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between pt-4 border-t border-gray-200">
          <div className="flex items-center gap-4 text-sm text-gray-500">
            {job.submissions_count !== undefined && (
              <div className="flex items-center">
                <Users className="w-4 h-4 mr-1" />
                {job.submissions_count} submissions
              </div>
            )}
            <div className="flex items-center">
              <Calendar className="w-4 h-4 mr-1" />
              {formatRelativeDate(job.created_at)}
            </div>
          </div>
        </div>
      </Card>
    </Link>
  );
}
