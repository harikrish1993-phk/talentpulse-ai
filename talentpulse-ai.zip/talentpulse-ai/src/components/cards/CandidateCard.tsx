import Link from 'next/link';
import { Candidate } from '@/lib/types';
import { Card, Badge } from '@/components/ui';
import {
  MapPin,
  Briefcase,
  Calendar,
  Mail,
  Phone,
  Shield,
  Star,
  Download,
} from 'lucide-react';
import { formatRelativeDate, getInitials } from '@/lib/utils';

export interface CandidateCardProps {
  candidate: Candidate;
}

export default function CandidateCard({ candidate }: CandidateCardProps) {
  const getAuthenticityColor = (score?: number) => {
    if (!score) return 'gray';
    if (score >= 75) return 'success';
    if (score >= 50) return 'warning';
    return 'danger';
  };

  const getParseQualityColor = (confidence: number) => {
    if (confidence >= 80) return 'success';
    if (confidence >= 60) return 'warning';
    return 'danger';
  };

  return (
    <Link href={`/candidate/${candidate.id}`}>
      <Card hoverable className="h-full">
        {/* Header with Avatar */}
        <div className="flex items-start gap-4 mb-4">
          <div className="w-14 h-14 bg-gradient-to-br from-primary-500 to-primary-700 rounded-full flex items-center justify-center flex-shrink-0">
            <span className="text-white font-bold text-lg">
              {getInitials(candidate.name)}
            </span>
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-lg font-semibold text-gray-900 mb-1 hover:text-primary-600 transition-colors truncate">
              {candidate.name}
            </h3>
            {candidate.title && (
              <p className="text-sm text-gray-600 mb-2">{candidate.title}</p>
            )}
            <div className="flex flex-wrap gap-2">
              <Badge
                variant={getParseQualityColor(candidate.parse_confidence)}
                size="sm"
              >
                Parse: {candidate.parse_confidence}%
              </Badge>
              {candidate.authenticity_score && (
                <Badge
                  variant={getAuthenticityColor(candidate.authenticity_score)}
                  size="sm"
                >
                  <Shield className="w-3 h-3 mr-1" />
                  Auth: {candidate.authenticity_score}%
                </Badge>
              )}
              <Badge variant="gray" size="sm">
                {candidate.source}
              </Badge>
            </div>
          </div>
        </div>

        {/* Contact Info */}
        <div className="space-y-2 mb-4">
          {candidate.email && (
            <div className="flex items-center text-sm text-gray-700">
              <Mail className="w-4 h-4 mr-2 text-gray-400" />
              <span className="truncate">{candidate.email}</span>
            </div>
          )}
          {candidate.phone && (
            <div className="flex items-center text-sm text-gray-700">
              <Phone className="w-4 h-4 mr-2 text-gray-400" />
              {candidate.phone}
            </div>
          )}
          {candidate.location && (
            <div className="flex items-center text-sm text-gray-700">
              <MapPin className="w-4 h-4 mr-2 text-gray-400" />
              {candidate.location}
            </div>
          )}
          <div className="flex items-center text-sm text-gray-700">
            <Briefcase className="w-4 h-4 mr-2 text-gray-400" />
            {candidate.years_of_experience} years experience
          </div>
        </div>

        {/* Summary */}
        {candidate.summary && (
          <p className="text-sm text-gray-600 mb-4 line-clamp-2">
            {candidate.summary}
          </p>
        )}

        {/* Skills */}
        {candidate.skills && candidate.skills.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mb-4">
            {candidate.skills.slice(0, 6).map((skill, index) => (
              <Badge key={index} size="sm" variant="primary">
                {skill}
              </Badge>
            ))}
            {candidate.skills.length > 6 && (
              <Badge size="sm" variant="gray">
                +{candidate.skills.length - 6}
              </Badge>
            )}
          </div>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between pt-4 border-t border-gray-200">
          <div className="flex items-center text-sm text-gray-500">
            <Calendar className="w-4 h-4 mr-1" />
            {formatRelativeDate(candidate.created_at)}
          </div>
          {candidate.resume_url && (
            <button
              onClick={(e) => {
                e.preventDefault();
                window.open(candidate.resume_url, '_blank');
              }}
              className="flex items-center text-sm text-primary-600 hover:text-primary-700"
            >
              <Download className="w-4 h-4 mr-1" />
              Resume
            </button>
          )}
        </div>
      </Card>
    </Link>
  );
}
