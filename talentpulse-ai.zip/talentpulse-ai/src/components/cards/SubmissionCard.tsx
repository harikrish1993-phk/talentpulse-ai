import Link from 'next/link';
import { Submission } from '@/lib/types';
import { Card, Badge } from '@/components/ui';
import {
  User,
  Briefcase,
  Building2,
  Calendar,
  Clock,
  TrendingUp,
  MessageSquare,
} from 'lucide-react';
import { formatRelativeDate, formatStatusLabel, getStatusColor } from '@/lib/utils';

export interface SubmissionCardProps {
  submission: Submission;
}

export default function SubmissionCard({ submission }: SubmissionCardProps) {
  const { candidate, job, status, submitted_at, updated_at } = submission;

  const statusSteps = [
    'submitted',
    'client_reviewing',
    'interview_scheduled',
    'interview_completed',
    'offer_extended',
    'offer_accepted',
  ];

  const currentStepIndex = statusSteps.indexOf(status);
  const progress = ((currentStepIndex + 1) / statusSteps.length) * 100;

  return (
    <Link href={`/submissions/${submission.id}`}>
      <Card hoverable className="h-full">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Badge variant={getStatusColor(status).includes('green') ? 'success' : getStatusColor(status).includes('red') ? 'danger' : getStatusColor(status).includes('yellow') ? 'warning' : 'primary'}>
                {formatStatusLabel(status)}
              </Badge>
              {submission.match_score && (
                <Badge variant="gray" size="sm">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  {submission.match_score}% match
                </Badge>
              )}
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mb-4">
          <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-primary-500 transition-all duration-300"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </div>

        {/* Candidate Info */}
        <div className="mb-3 pb-3 border-b border-gray-200">
          <div className="flex items-center text-gray-700 mb-1">
            <User className="w-4 h-4 mr-2 text-gray-400" />
            <span className="font-semibold">{candidate.name}</span>
          </div>
          {candidate.title && (
            <p className="text-sm text-gray-600 ml-6">{candidate.title}</p>
          )}
        </div>

        {/* Job Info */}
        <div className="mb-4">
          <div className="flex items-center text-gray-700 mb-1">
            <Briefcase className="w-4 h-4 mr-2 text-gray-400" />
            <span className="font-semibold">{job.title}</span>
          </div>
          {job.client && (
            <div className="flex items-center text-sm text-gray-600 ml-6">
              <Building2 className="w-3 h-3 mr-1" />
              {job.client.company_name}
            </div>
          )}
        </div>

        {/* Timeline */}
        <div className="flex items-center justify-between text-sm text-gray-500">
          <div className="flex items-center">
            <Calendar className="w-4 h-4 mr-1" />
            Submitted {formatRelativeDate(submitted_at)}
          </div>
          {updated_at !== submitted_at && (
            <div className="flex items-center">
              <Clock className="w-4 h-4 mr-1" />
              Updated {formatRelativeDate(updated_at)}
            </div>
          )}
        </div>

        {/* Notes indicator */}
        {submission.notes && (
          <div className="mt-3 pt-3 border-t border-gray-200">
            <div className="flex items-center text-sm text-gray-600">
              <MessageSquare className="w-4 h-4 mr-1" />
              Has notes
            </div>
          </div>
        )}
      </Card>
    </Link>
  );
}
